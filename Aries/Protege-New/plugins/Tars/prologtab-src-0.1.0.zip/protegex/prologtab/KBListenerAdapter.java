package protegex.prologtab;

import edu.stanford.smi.protege.model.*;
import java.util.*;
/**
 * Adapts KBListener calls to TripleDB.
 * Creation date: (3/22/2002 9:50:55 AM)
 * @author: 
 */
public class KBListenerAdapter {
	protected TripleDBAdapter _dbAdapter;
/**
 * EventDBAdapter constructor comment.
 */
public KBListenerAdapter(TripleDBAdapter dbAdapter) {
	_dbAdapter = dbAdapter;
}
/**
 * 
 * @param cls edu.stanford.smi.protege.model.Cls
 */
public void clsCreated(Cls cls) {
	Cls metaCls = cls.getDirectType();
	directInstanceCreated(metaCls,cls);
}
/**
 * 
 * @param cls edu.stanford.smi.protege.model.Cls
 */
public void clsDeleted(Cls cls) {
	Cls metaCls = cls.getDirectType();
	directInstanceDeleted(metaCls,cls);
}
/**
 * 
 * @param cls edu.stanford.smi.protege.model.Cls
 * @param instance edu.stanford.smi.protege.model.Instance
 */
public void directInstanceCreated(Cls cls, Instance instance) {
	_dbAdapter.updateSlotValues(cls,Model.Slot.DIRECT_INSTANCES,cls.getDirectInstances());
	_dbAdapter.updateSlotValue(instance,TripleDBAdapter.DIRECT_TYPE_SLOT_NAME,instance.getDirectType());
}
/**
 * 
 * @param cls edu.stanford.smi.protege.model.Cls
 * @param instance edu.stanford.smi.protege.model.Instance
 */
public void directInstanceDeleted(Cls cls, Instance instance) {
	if (cls != null)
		_dbAdapter.updateSlotValues(cls,Model.Slot.DIRECT_INSTANCES,cls.getDirectInstances());
	if (instance != null)
		_dbAdapter.removeSlotValue(instance,TripleDBAdapter.DIRECT_TYPE_SLOT_NAME);
	if ((cls != null) && (instance != null)) {
		Iterator slotIterator = cls.getTemplateSlots().iterator();
		while (slotIterator.hasNext()) {
			Slot slot = (Slot) slotIterator.next();
			_dbAdapter.removeSlotValue(instance,slot.getName());
		}
	}
}
/**
 * 
 * @param cls edu.stanford.smi.protege.model.Cls
 */
public void directSubclassUpdated(Cls cls) {
	_dbAdapter.updateSlotValues(cls,Model.Slot.DIRECT_SUBCLASSES,cls.getDirectSubclasses());
}
/**
 * 
 * @param cls edu.stanford.smi.protege.model.Cls
 */
public void directSuperclassUpdated(Cls cls) {
	_dbAdapter.updateSlotValues(cls,Model.Slot.DIRECT_SUPERCLASSES,cls.getDirectSuperclasses());
}
/**
 * 
 * @param frame edu.stanford.smi.protege.model.Frame
 */
public void frameNameChanged(Frame frame,String oldName) {
	_dbAdapter.updateSlotValue(frame,TripleDBAdapter.NAME_SLOT_NAME,frame.getName());
	if (frame instanceof Slot)
		_dbAdapter.renameSlot(oldName,frame.getName());
}
/**
 * 
 * @param instance edu.stanford.smi.protege.model.Frame
 */
public void instanceCreated(Frame frame) {
	_dbAdapter.updateSlotValue(frame,TripleDBAdapter.NAME_SLOT_NAME,frame.getName());
	if (frame instanceof Instance) {
		Cls directType = ((Instance) frame).getDirectType();
		_dbAdapter.updateSlotValue(frame,TripleDBAdapter.DIRECT_TYPE_SLOT_NAME,directType);
		Iterator slotIterator = directType.getTemplateSlots().iterator();
		while (slotIterator.hasNext()) {
			Slot slot = (Slot) slotIterator.next();
			if (frame.getOwnSlotAllowsMultipleValues(slot)) {
				Collection values = frame.getOwnSlotValues(slot);
				_dbAdapter.addSlotValues(frame,slot.getName(),values);
			} else {
				Object value = frame.getOwnSlotValue(slot);
				_dbAdapter.addSlotValue(frame,slot.getName(),value);
			}
		}
	}
}
/**
 * 
 * @param frame edu.stanford.smi.protege.model.Frame
 */
public void instanceDeleted(Frame frame, String oldName) {
	_dbAdapter.removeSlotValue(frame,TripleDBAdapter.NAME_SLOT_NAME);
	_dbAdapter.removeSlotValue(frame,TripleDBAdapter.DIRECT_TYPE_SLOT_NAME);
	//Slot values are cleaned up in directInstanceDeleted
}
/**
 * 
 * @param frame edu.stanford.smi.protege.model.Frame
 * @param slot edu.stanford.smi.protege.model.Slot
 */
public void ownSlotValueChanged(Frame frame, Slot slot) {
	if (frame.getOwnSlotAllowsMultipleValues(slot)) {
		Collection values = frame.getOwnSlotValues(slot);
		_dbAdapter.updateSlotValues(frame,slot.getName(),values);
	} else {
		Object value = frame.getOwnSlotValue(slot);
		_dbAdapter.updateSlotValue(frame,slot.getName(),value);
	}
}
/**
 * 
 * @param slot edu.stanford.smi.protege.model.Slot
 */
public void slotCreated(Slot slot) {
	Cls cls = slot.getDirectType();
	directInstanceCreated(cls,slot);
}
/**
 * 
 * @param slot edu.stanford.smi.protege.model.Slot
 */
public void slotDeleted(Slot slot) {
	Cls cls = slot.getDirectType();
	directInstanceDeleted(cls,slot);
	_dbAdapter.removeSlot(slot.getName());
}
}
