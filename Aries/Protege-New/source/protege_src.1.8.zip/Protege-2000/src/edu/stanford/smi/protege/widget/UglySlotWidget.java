/*
 * The contents of this file are subject to the Mozilla Public License
 * Version 1.1 (the "License");  you may not use this file except in compliance
 * with the License.  You may obtain a copy of the License at
 * http://www.mozilla.org/MPL/
 *
 * Software distributed under the License is distributed on an "AS IS" basis,
 * WITHOUT WARRANTY OF ANY KIND, either express or implied. See the License for
 * the specific language governing rights and limitations under the License.
 *
 * The Original Code is Protege-2000.
 *
 * The Initial Developer of the Original Code is Stanford University. Portions
 * created by Stanford University are Copyright (C) 2001.  All Rights Reserved.
 *
 * Protege-2000 was developed by Stanford Medical Informatics
 * (http://www.smi.stanford.edu) at the Stanford University School of Medicine
 * with support from the National Library of Medicine, the National Science
 * Foundation, and the Defense Advanced Research Projects Agency.  Current
 * information about Protege can be obtained at http://protege.stanford.edu
 *
 * Contributor(s):
 */

package edu.stanford.smi.protege.widget;

import java.awt.*;

import javax.swing.*;

/**
 * Slot widget that is displayed when another slot widget fails to load (either the constructor or the initialize method
 * throw an exception.  This is a fairly common occurance when slot widgets are being developed.  Placing a "dead" 
 * widget on the form instead causes problems whose source is unclear.  When this widget appears it is perfectly clear
 * that something has gone wrong and users know where to look.
 *
 * @author    Ray Fergerson <fergerson@smi.stanford.edu>
 */
public class UglySlotWidget extends AbstractSlotWidget {

    public String getLabel() {
        return "Ugly Slot Widget (tm)";
    }

    public void initialize() {
        JComponent c1 = new JLabel("The Ugly Widget (tm)", JLabel.CENTER);
        JComponent c2 = new JLabel("Slot: " + getSlot().getName(), JLabel.CENTER);
        JPanel panel = new JPanel(new BorderLayout());
        panel.setOpaque(true);
        panel.setBackground(Color.red);
        panel.setForeground(Color.black);
        panel.setBorder(BorderFactory.createMatteBorder(5, 5, 5, 5, Color.green));
        panel.add(c1, BorderLayout.CENTER);
        panel.add(c2, BorderLayout.SOUTH);
        add(panel);
        setPreferredColumns(2);
        setPreferredRows(2);
    }
}
