package protegex.prologtab;

import edu.stanford.smi.protege.model.*;
import java.util.*;
/**
 * Slot triple database interface.
 * Creation date: (4/11/2002 9:46:01 AM)
 * @author: 
 */
public interface TripleDB {
/**
 * Assert a new Frame-slot-value triple in the database.
 * @param frame edu.stanford.smi.protege.model.Frame
 * @param slot edu.stanford.smi.protege.model.Slot
 * @param value java.lang.Object
 */
void assertSlotValueClause(Frame frame, String slotName, Object value);
/**
 * Rename a slot predicate.
 * Creation date: (4/10/2002 9:55:27 AM)
 * @param oldName java.lang.String
 * @param newName java.lang.String
 */
void renameSlotPredicate(String oldName, String newName);
/**
 * Retract all slot values triple from the database.
 * Creation date: (4/9/2002 10:13:13 AM)
 * @param slotName java.lang.String
 */
void retractSlotPredicate(String slotName);
/**
 * Retract a frame-slot-value from the database.
 * @param frame edu.stanford.smi.protege.model.Frame
 * @param slot edu.stanford.smi.protege.model.Slot
 */
void retractSlotValueClause(Frame frame, String slotName);
}
