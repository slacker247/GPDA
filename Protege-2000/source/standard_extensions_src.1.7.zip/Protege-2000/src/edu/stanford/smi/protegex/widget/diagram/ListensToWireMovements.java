/*
 * The contents of this file are subject to the Mozilla Public License
 * Version 1.1 (the "License");  you may not use this file except in compliance
 * with the License.  You may obtain a copy of the License at
 * http://www.mozilla.org/MPL/
 *
 * Software distributed under the License is distributed on an "AS IS" basis,
 * WITHOUT WARRANTY OF ANY KIND, either express or implied. See the License for
 * the specific language governing rights and limitations under the License.
 *
 * The Original Code is Protege-2000.
 *
 * The Initial Developer of the Original Code is Stanford University. Portions
 * created by Stanford University are Copyright (C) 2001.  All Rights Reserved.
 *
 * Protege-2000 was developed by Stanford Medical Informatics
 * (http://www.smi.stanford.edu) at the Stanford University School of Medicine
 * with support from the National Library of Medicine, the National Science
 * Foundation, and the Defense Advanced Research Projects Agency.  Current
 * information about Protege can be obtained at http://protege.stanford.edu
 *
 * Contributor(s):
 */

package edu.stanford.smi.protegex.widget.diagram;

import edu.stanford.smi.protegex.layout.*;

import edu.stanford.smi.protege.model.*;
import edu.stanford.smi.protege.widget.*;
import edu.stanford.smi.protege.util.*;

import javax.swing.*;
import java.awt.Point;
import java.util.*;

/**
 *  Description of the Class
 *
 * @author    William Grosso <grosso@smi.stanford.edu>
 */
public class ListensToWireMovements extends ActorAdapter implements Constants {
    private StandardWireActor _actor;
    private Instance _underlyingConnectionInstance;
    private KnowledgeBase _kb;
    private Project _project;
    private Cls _underlyingConnectionInstanceType;
    private Slot _firstObjectSlot;
    private Slot _secondObjectSlot;
    private Collection _firstObjectSlotAllowedTypes;
    private Collection _secondObjectSlotAllowedTypes;
    private AttachWireAction _attachWireAction;
    private Instance _networkInstance;

    private class AttachWireAction implements ActorAction {
        private boolean _startingAttachmentFound;
        private boolean _endingAttachmentFound;
        public Point _basePoint;
        public Point _endPoint;

        public void performMethod(Actor a) {
            _startingAttachmentFound = false;
            _endingAttachmentFound = false;

            if (a == _actor) {
                return;
            }
            if (((AbstractActor) a).isWire()) {
                return;
            }

            ActorLocation nodeLocation = a.getLocation();
            Cls actorClass = ((ActorInstance) a).getInstance().getDirectType();
            if ((!_startingAttachmentFound) && (nodeLocation.contains(_basePoint))) {
                if (checkForSlotTypeMatch(actorClass, _firstObjectSlotAllowedTypes)) {
                    ActorAttachment firstAttachment = new ActorAttachment(a, ControlPoints.BEGINNING, ControlPoints.MIDDLE);
                    ((StandardWireActor) _actor).setStartingAttachment(firstAttachment);
                    _startingAttachmentFound = true;
                }
            }

            if ((!_endingAttachmentFound) && (nodeLocation.contains(_endPoint))) {
                if (checkForSlotTypeMatch(actorClass, _secondObjectSlotAllowedTypes)) {
                    ActorAttachment secondAttachment = new ActorAttachment(a, ControlPoints.END, ControlPoints.MIDDLE);
                    ((StandardWireActor) _actor).setEndingAttachment(secondAttachment);
                    _endingAttachmentFound = true;
                }
            }
        }

        private boolean checkForSlotTypeMatch(Cls actorClass, Collection allowedTypes) {
            Iterator iterator = allowedTypes.iterator();
            while (iterator.hasNext()) {
                Cls allowedType = (Cls) iterator.next();
                if ((actorClass == allowedType) || (actorClass.hasSuperclass(allowedType))) {
                    return true;
                }
            }
            return false;
        }
    }

    public ListensToWireMovements(
        Project project,
        Actor actor,
        Instance underlyingConnectionInstance,
        Instance networkInstance) {
        _actor = (StandardWireActor) actor;
        _project = project;
        _networkInstance = networkInstance;
        _underlyingConnectionInstance = underlyingConnectionInstance;
        _underlyingConnectionInstanceType = _underlyingConnectionInstance.getDirectType();
        _kb = underlyingConnectionInstance.getKnowledgeBase();
        _firstObjectSlot = _kb.getSlot(FIRST_OBJECT_SLOT_NAME);
        _firstObjectSlotAllowedTypes = _underlyingConnectionInstanceType.getTemplateSlotAllowedClses(_firstObjectSlot);
        _secondObjectSlot = _kb.getSlot(SECOND_OBJECT_SLOT_NAME);
        _secondObjectSlotAllowedTypes = _underlyingConnectionInstanceType.getTemplateSlotAllowedClses(_secondObjectSlot);
        _attachWireAction = new AttachWireAction();
        _actor.addActorListener(this);
    }

    public void actorDoubleClicked(ActorEvent e) {
        _project.show(_underlyingConnectionInstance);
    }

    public void actorResized(ActorEvent e) {
        setWireAttachments();
        DiagramUtilities.updateConnectorLocation(_networkInstance, _actor);
        updateConnections();
    }

    public void actorStartedMoving(ActorEvent e) {
        DiagramUtilities.unbindAlongConnection(_underlyingConnectionInstance);
    }

    public void actorStoppedMoving(ActorEvent e) {
        setWireAttachments();
        DiagramUtilities.updateConnectorLocation(_networkInstance, _actor);
        updateConnections();
    }

    private void setWireAttachments() {
        ZOrder _zOrder = _actor.getAnimationContext().getZOrder();
        _attachWireAction._basePoint = _actor.getBeginningPoint();
        _attachWireAction._endPoint = _actor.getEndingPoint();
        _zOrder.performAction(0, _attachWireAction);
    }

    private void updateConnections() {
        ActorAttachment firstAttachment = ((StandardWireActor) _actor).getStartingAttachment();
        ActorAttachment secondAttachment = ((StandardWireActor) _actor).getEndingAttachment();

        if (null != firstAttachment) {
            _underlyingConnectionInstance.setOwnSlotValue(
                _firstObjectSlot,
                ((ActorInstance) (firstAttachment.getActor())).getInstance());
        }
        if (null != secondAttachment) {
            _underlyingConnectionInstance.setOwnSlotValue(
                _secondObjectSlot,
                ((ActorInstance) (secondAttachment.getActor())).getInstance());
        }
        if ((null != firstAttachment) && (null != secondAttachment)) {
            DiagramUtilities.bindAlongConnection(_underlyingConnectionInstance);
        }
    }
}
