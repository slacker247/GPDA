package protegex.prologtab.gnuprolog;

/**
 * Insert the type's description here.
 * Creation date: (5/3/2002 10:21:58 AM)
 * @author: 
 */
public class GNUPrologJavaTab extends protegex.prologtab.PrologTab {
/**
 * GNUPrologJavaTab constructor comment.
 */
public GNUPrologJavaTab() {
	super();
}
/**
 * Insert the method's description here.
 * Creation date: (5/3/2002 10:23:48 AM)
 * @return protegex.prologtab.PrologShell
 * @param console protegex.prologtab.PrologConsole
 */
public protegex.prologtab.PrologShell createPrologShell(protegex.prologtab.PrologConsole console) {
	return new GNUPrologShell(console, this);
}
}
