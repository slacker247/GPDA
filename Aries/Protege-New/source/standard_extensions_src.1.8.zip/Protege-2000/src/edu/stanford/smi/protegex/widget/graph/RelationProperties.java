/*
 * The contents of this file are subject to the Mozilla Public License
 * Version 1.1 (the "License");  you may not use this file except in compliance
 * with the License.  You may obtain a copy of the License at
 * http://www.mozilla.org/MPL/
 *
 * Software distributed under the License is distributed on an "AS IS" basis,
 * WITHOUT WARRANTY OF ANY KIND, either express or implied. See the License for
 * the specific language governing rights and limitations under the License.
 *
 * The Original Code is Protege-2000.
 *
 * The Initial Developer of the Original Code is Stanford University. Portions
 * created by Stanford University are Copyright (C) 2001.  All Rights Reserved.
 *
 * Protege-2000 was developed by Stanford Medical Informatics
 * (http://www.smi.stanford.edu) at the Stanford University School of Medicine
 * with support from the National Library of Medicine, the National Science
 * Foundation, and the Defense Advanced Research Projects Agency.  Current
 * information about Protege can be obtained at http://protege.stanford.edu
 *
 * Contributor(s):
 */

package edu.stanford.smi.protegex.widget.graph;

// java
import java.awt.Color;

// stanford
import edu.stanford.smi.protege.util.PropertyList;

public class RelationProperties extends GraphObjectProperties {
    private String lineType;
    private String arrowheadType;

    private Color lineColor;

    private boolean displayText;

    public RelationProperties(String clsName, PropertyList propertyList) {
        super(clsName, propertyList);
        initialize();
    }

    private void initialize() {
        int red, green, blue;
        String prefix = getPrefix();

        // Get the line's color.  Default to black.
        red = getIntProperty(prefix + "lineColorRed", new Integer(0));
        green = getIntProperty(prefix + "lineColorGreen", new Integer(0));
        blue = getIntProperty(prefix + "lineColorBlue", new Integer(0));
        lineColor = new Color(red, green, blue);

        lineType = getStringProperty(prefix + "lineType", "Solid");
        arrowheadType = getStringProperty(prefix + "arrowheadType", "Arrowhead");
        displayText = getBooleanProperty(prefix + "displayText", new Boolean(true));
    }

    public void save() {
        String prefix = getPrefix();
        PropertyList propertyList = getPropertyList();

        propertyList.setInteger(prefix + "lineColorRed", this.lineColor.getRed());
        propertyList.setInteger(prefix + "lineColorGreen", this.lineColor.getGreen());
        propertyList.setInteger(prefix + "lineColorBlue", this.lineColor.getBlue());
        propertyList.setString(prefix + "lineType", this.lineType);
        propertyList.setString(prefix + "arrowheadType", this.arrowheadType);
        propertyList.setBoolean(prefix + "displayText", this.displayText);
    }

    public String getLineType() {
        return lineType;
    }

    public void setLineType(String lineType) {
        this.lineType = lineType;
    }

    public String getArrowheadType() {
        return arrowheadType;
    }

    public void setArrowheadType(String arrowheadType) {
        this.arrowheadType = arrowheadType;
    }

    public Color getLineColor() {
        return lineColor;
    }

    public void setLineColor(Color lineColor) {
        this.lineColor = lineColor;
    }

    public boolean isTextDisplayed() {
        return displayText;
    }

    public void setDisplayText(boolean displayText) {
        this.displayText = displayText;
    }
}