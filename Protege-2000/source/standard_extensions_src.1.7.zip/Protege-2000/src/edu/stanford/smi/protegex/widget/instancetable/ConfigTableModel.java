/*
 * The contents of this file are subject to the Mozilla Public License
 * Version 1.1 (the "License");  you may not use this file except in compliance
 * with the License.  You may obtain a copy of the License at
 * http://www.mozilla.org/MPL/
 *
 * Software distributed under the License is distributed on an "AS IS" basis,
 * WITHOUT WARRANTY OF ANY KIND, either express or implied. See the License for
 * the specific language governing rights and limitations under the License.
 *
 * The Original Code is Protege-2000.
 *
 * The Initial Developer of the Original Code is Stanford University. Portions
 * created by Stanford University are Copyright (C) 2001.  All Rights Reserved.
 *
 * Protege-2000 was developed by Stanford Medical Informatics
 * (http://www.smi.stanford.edu) at the Stanford University School of Medicine
 * with support from the National Library of Medicine, the National Science
 * Foundation, and the Defense Advanced Research Projects Agency.  Current
 * information about Protege can be obtained at http://protege.stanford.edu
 *
 * Contributor(s):
 */

package edu.stanford.smi.protegex.widget.instancetable;

import java.util.*;
import javax.swing.*;
import javax.swing.event.*;
import javax.swing.table.*;

/**
 *  Basically an adapter-- takes the state and makes it palatable to a Table.
 *
 * @author    William Grosso <grosso@smi.stanford.edu>
 */
public class ConfigTableModel extends AbstractTableModel implements Observer {
    private InstanceTableWidgetState _state;

    public ConfigTableModel(InstanceTableWidgetState state) {
        _state = state;
        _state.addObserver(this);
    }

    public int getColumnCount() {
        return (_state.getVisibleSlots()).size() + 1;
    }

    public String getColumnName(int column) {
        if (column != 0) {
            VisibleSlotDescription vsd = _state.getDescriptionForIndex(column - 1);
            return vsd.columnName;
        }
        return "";
    }

    private String getFirstColumnValue(int row) {
        switch (row) {
            case 0 :
                return "Slot Name";
            case 1 :
                return "Column Name";
            case 2 :
                return "Text Color";
        }
        return null;
    }

    private Object getRealValues(int row, int column) {
        VisibleSlotDescription vsd = _state.getDescriptionForIndex(column);
        switch (row) {
            case 0 :
                return vsd.slot;
            case 1 :
                return vsd.columnName;
            case 2 :
                return vsd.color;
        }
        return null;
    }

    public int getRowCount() {
        return 3;
    }

    public Object getValueAt(int row, int column) {
        if (0 == column) {
            return getFirstColumnValue(row);
        }
        return getRealValues(row, column - 1);
    }

    public void update(Observable o, Object arg) {
        fireTableStructureChanged();
    }
}
