/*
 * The contents of this file are subject to the Mozilla Public License
 * Version 1.1 (the "License");  you may not use this file except in compliance
 * with the License.  You may obtain a copy of the License at
 * http://www.mozilla.org/MPL/
 *
 * Software distributed under the License is distributed on an "AS IS" basis,
 * WITHOUT WARRANTY OF ANY KIND, either express or implied. See the License for
 * the specific language governing rights and limitations under the License.
 *
 * The Original Code is Protege-2000.
 *
 * The Initial Developer of the Original Code is Stanford University. Portions
 * created by Stanford University are Copyright (C) 2001.  All Rights Reserved.
 *
 * Protege-2000 was developed by Stanford Medical Informatics
 * (http://www.smi.stanford.edu) at the Stanford University School of Medicine
 * with support from the National Library of Medicine, the National Science
 * Foundation, and the Defense Advanced Research Projects Agency.  Current
 * information about Protege can be obtained at http://protege.stanford.edu
 *
 * Contributor(s):
 */

package edu.stanford.smi.protegex.layout;

import java.awt.*;
import java.awt.event.*;

/**
 *  Control point handler for icons and images.
 *
 * @author    William Grosso <grosso@smi.stanford.edu>
 */
public class ImageControlPointHandler extends ActorControlPointHandlerImpl {

    public ImageControlPointHandler(int precision, int minimumSize, Actor actor) {
        super(precision, minimumSize, actor);
    }

    // The Copyable Interface
    public Object copy() {
        return new ImageControlPointHandler(_precision, _minimumSize, _actor);
    }

    public void getControlPoint(int controlPoint, Point returnValue) {
        switch (controlPoint) {
            case ControlPoints.UPPER_LEFT :
                returnValue.x = _location.getBaseX();
                returnValue.y = _location.getBaseY();
                break;
            case ControlPoints.UPPER_MIDDLE :
                returnValue.x = _location.getCenterX();
                returnValue.y = _location.getBaseY();
                break;
            case ControlPoints.UPPER_RIGHT :
                returnValue.x = _location.getExtensionX();
                returnValue.y = _location.getBaseY();
                break;
            case ControlPoints.MIDDLE_LEFT :
                returnValue.x = _location.getBaseX();
                returnValue.y = _location.getCenterY();
                break;
            case ControlPoints.MIDDLE :
                returnValue.x = _location.getCenterX();
                returnValue.y = _location.getCenterY();
                break;
            case ControlPoints.MIDDLE_RIGHT :
                returnValue.x = _location.getExtensionX();
                returnValue.y = _location.getCenterY();
                break;
            case ControlPoints.LOWER_LEFT :
                returnValue.x = _location.getBaseX();
                returnValue.y = _location.getExtensionY();
                break;
            case ControlPoints.LOWER_MIDDLE :
                returnValue.x = _location.getCenterX();
                returnValue.y = _location.getExtensionY();
                break;
            case ControlPoints.LOWER_RIGHT :
                returnValue.x = _location.getExtensionX();
                returnValue.y = _location.getExtensionY();
                break;
        }
        return;
    }

    public int getControlPointForPoint(Point inputLocation) {
        // only possible control point
        int controlPoint =
            4 + fuzzyCompare(inputLocation.x, _location.getCenterX()) + 3 * fuzzyCompare(inputLocation.y, _location.getCenterY());
        getControlPoint(controlPoint, _scratchPoint);
        // see if only possible control point is, in fact, a match
        if (0 == fuzzyCompare(inputLocation.x, _scratchPoint.x)) {
            if (0 == fuzzyCompare(inputLocation.y, _scratchPoint.y)) {
                return controlPoint;
            }
        }
        return ControlPoints.NOT_A_VALID_CONTROL_POINT;
    }

    public void moveControlPoint(int controlPoint, Point destinationPoint) {
        getControlPoint(controlPoint, _scratchPoint);
        int deltaX = destinationPoint.x - _scratchPoint.x;
        int deltaY = destinationPoint.y - _scratchPoint.y;
        translateControlPoint(controlPoint, deltaX, deltaY);
    }

    public void translateControlPoint(int controlPoint, int deltaX, int deltaY) {
        _location.getBasePoint(_scratchPoint);
        int newHeight = _location.getHeight();
        int newWidth = _location.getWidth();
        switch (controlPoint) {
            case ControlPoints.UPPER_LEFT :
                _scratchPoint.x += deltaX;
                _scratchPoint.y += deltaY;
                newWidth -= deltaX;
                newHeight -= deltaY;
                break;
            case ControlPoints.UPPER_MIDDLE :
                _scratchPoint.y += deltaY;
                newHeight -= deltaY;
                break;
            case ControlPoints.UPPER_RIGHT :
                _scratchPoint.y += deltaY;
                newWidth += deltaX;
                newHeight -= deltaY;
                break;
            case ControlPoints.MIDDLE_LEFT :
                _scratchPoint.x += deltaX;
                newWidth -= deltaX;
                break;
            case ControlPoints.MIDDLE_RIGHT :
                newWidth += deltaX;
                break;
            case ControlPoints.LOWER_LEFT :
                _scratchPoint.x += deltaX;
                newWidth -= deltaX;
                newHeight += deltaY;
                break;
            case ControlPoints.LOWER_MIDDLE :
                newHeight += deltaY;
                break;
            case ControlPoints.LOWER_RIGHT :
                newWidth += deltaX;
                newHeight += deltaY;
                break;
        }
        if ((_minimumSize < newHeight) && (_minimumSize < newWidth)) {
            _location.move(_scratchPoint.x, _scratchPoint.y);
            _location.setHeight(newHeight);
            _location.setWidth(newWidth);
        }
    }

    public boolean wantEvent(MouseEvent e) {
        if (null == e) {
            (new Throwable()).printStackTrace();
        }
        return (_location.contains(e.getPoint()));
    }
}
