/*
 * The contents of this file are subject to the Mozilla Public License
 * Version 1.1 (the "License");  you may not use this file except in compliance
 * with the License.  You may obtain a copy of the License at
 * http://www.mozilla.org/MPL/
 *
 * Software distributed under the License is distributed on an "AS IS" basis,
 * WITHOUT WARRANTY OF ANY KIND, either express or implied. See the License for
 * the specific language governing rights and limitations under the License.
 *
 * The Original Code is Protege-2000.
 *
 * The Initial Developer of the Original Code is Stanford University. Portions
 * created by Stanford University are Copyright (C) 2001.  All Rights Reserved.
 *
 * Protege-2000 was developed by Stanford Medical Informatics
 * (http://www.smi.stanford.edu) at the Stanford University School of Medicine
 * with support from the National Library of Medicine, the National Science
 * Foundation, and the Defense Advanced Research Projects Agency.  Current
 * information about Protege can be obtained at http://protege.stanford.edu
 *
 * Contributor(s):
 */

package edu.stanford.smi.protegex.widget.diagram;

import edu.stanford.smi.protegex.layout.*;

import edu.stanford.smi.protege.model.*;

import javax.swing.*;
import java.awt.*;
import java.awt.event.*;
import java.util.*;

/**
 *  Description of the class
 *
 * @author    William Grosso <grosso@smi.stanford.edu>
 */
public class PreviewFlowchartPanel extends JComponent implements Constants, Scrollable {

    private JScrollPane _scroller;
    private DiagramWidget _widget;
    private FlowchartGraph _graph;
    private String _text;
    private UnreachableNodesExistException _unee;
    private RootListModel _rootListModel;
    private boolean _isLandscape;
    private int _nodeX, _nodeY;
    private int _spaceX, _spaceY;
    private int _zoom;
    private Dimension _sizeNeeded;

    public final static String DEFAULT_DISPLAY_TEXT = "Preview not available.";
    public final static int DEFAULT_ZOOM = 4;

    public PreviewFlowchartPanel(DiagramWidget widget, JScrollPane scroller) {
        super();
        _scroller = scroller;
        _widget = widget;
        _graph = null;
        _unee = null;
        _rootListModel = null;
        _text = DEFAULT_DISPLAY_TEXT;
        _isLandscape = false;
        _zoom = DEFAULT_ZOOM;
        setScales(true);
        _sizeNeeded =
            new Dimension(_widget.getLogicalDrawingAreaWidth() / _zoom, _widget.getLogicalDrawingAreaHeight() / _zoom);
        setSize(_sizeNeeded);
    }

    private void drawErrors(Graphics g) {
        int[] errors = _unee.getUnreachableNodes();
        FontMetrics metrics = g.getFontMetrics();
        for (int i = 0; i < errors.length; i++) {
            String name = _rootListModel.getTextAt(errors[i] - 1);
            g.drawString(name, 20, 20 + metrics.getHeight() * (i + 1));
        }
    }

    private void drawNodes(Graphics g) {
        Point[] nodes = getNodeLocations(_zoom);
        for (int i = 0; i < nodes.length; i++) {
            g.fillRect(nodes[i].x, nodes[i].y, _nodeX / _zoom, _nodeY / _zoom);
            for (int j = 0; j < i; j++) {
                if (_graph.hasEdgeBetween(i + 1, j + 1)) {
                    g.drawLine(
                        _nodeX / (_zoom * 2) + nodes[i].x,
                        _nodeY / (_zoom * 2) + nodes[i].y,
                        _nodeX / (_zoom * 2) + nodes[j].x,
                        _nodeY / (_zoom * 2) + nodes[j].y);
                }
            }
        }
    }

    public FlowchartGraph getFlowchart() {
        return _graph;
    }

    private Dimension getMaxNodeDimensions() {
        int height = 0;
        int width = 0;
        Collection nodes = _widget.getNodes();
        Iterator itr = nodes.iterator();
        DiagramsAnimationContext context = (DiagramsAnimationContext) (_widget.getMainDrawingArea());
        while (itr.hasNext()) {
            Instance ins = (Instance) (itr.next());
            Actor actor = context.getActorForInstance(ins);
            ActorLocation loc = actor.getLocation();
            if (loc.getWidth() > width) {
                width = loc.getWidth();
            }
            if (loc.getHeight() > height) {
                height = loc.getHeight();
            }
        }
        return new Dimension(width, height);
    }

    public Point[] getNodeLocations(int scale) {
        Point[] result;
        if (_isLandscape) {
            result = _graph.getPositions(getYScale() / scale, getXScale() / scale);
            reversePositions(result);
        } else {
            result = _graph.getPositions(getXScale() / scale, getYScale() / scale);
        }
        return result;
    }

    public Dimension getPreferredScrollableViewportSize() {
        return getPreferredSize();
    }

    public Dimension getPreferredSize() {
        return _sizeNeeded;
    }

    public int getScrollableBlockIncrement(Rectangle visibleRect, int orientation, int direction) {
        if (orientation == SwingConstants.VERTICAL) {
            return visibleRect.height;
        }
        if (orientation == SwingConstants.HORIZONTAL) {
            return visibleRect.width;
        } else {
            return 1;
        }
    }

    public boolean getScrollableTracksViewportHeight() {
        return false;
    }

    public boolean getScrollableTracksViewportWidth() {
        return false;
    }

    public int getScrollableUnitIncrement(Rectangle visibleRect, int orientation, int direction) {
        return 1;
    }

    public JScrollPane getScroller() {
        return _scroller;
    }

    public int getXNode() {
        return _nodeX;
    }

    public int getXScale() {
        return (_nodeX + _spaceX);
    }

    public int getXSpace() {
        return _spaceX;
    }

    public int getYNode() {
        return _nodeY;
    }

    public int getYScale() {
        return (_nodeY + _spaceY);
    }

    public int getYSpace() {
        return _spaceY;
    }

    public int getZoom() {
        return _zoom;
    }

    public void paint(Graphics g) {
        g.setColor(Color.white);
        g.fillRect(0, 0, _widget.getLogicalDrawingAreaWidth() / _zoom, _widget.getLogicalDrawingAreaHeight() / _zoom);
        g.setColor(Color.black);
        if (_graph == null) {
            g.setFont((new JLabel()).getFont());
            g.drawString(_text, 20, 20);
            if (_unee != null) {
                drawErrors(g);
            }
        } else {
            drawNodes(g);
        }
    }

    public void refreshSize() {

        /*
         * This test shouldn't be necessary-- if we're not showing, then the
         * frame listener ought to have been disconnected from the KB.
         * if (false == isShowing())
         * {
         * return;
         * }
         */
        _sizeNeeded.width = _widget.getLogicalDrawingAreaWidth() / _zoom;
        _sizeNeeded.height = _widget.getLogicalDrawingAreaHeight() / _zoom;
        if (_graph != null) {
            double graphHeight = _isLandscape ? _graph.getMaxWidth() : _graph.getDepth() - 1;
            double graphWidth = _isLandscape ? _graph.getDepth() - 1 : _graph.getMaxWidth();
            int previewHeight = (int) (graphHeight * getYScale() / _zoom) + getYNode() / _zoom;
            int previewWidth = (int) (graphWidth * getXScale() / _zoom) + getXNode() / _zoom;
            if (previewHeight > _sizeNeeded.height) {
                _sizeNeeded.height = previewHeight;
            }
            if (previewWidth > _sizeNeeded.width) {
                _sizeNeeded.width = previewWidth;
            }
        } else if (_unee != null) {
            int[] errors = _unee.getUnreachableNodes();
            FontMetrics metrics = getGraphics().getFontMetrics();
            for (int i = 0; i < errors.length; i++) {
                String name = _rootListModel.getTextAt(errors[i] - 1);
                int width = metrics.stringWidth(name) + 40;
                if (width > _sizeNeeded.width) {
                    _sizeNeeded.width = width;
                }
            }
            int height = errors.length * metrics.getHeight() + 40;
            if (height > _sizeNeeded.height) {
                _sizeNeeded.height = height;
            }
        }
        if (_graph == null) {
            FontMetrics metrics = getGraphics().getFontMetrics();
            int width = metrics.stringWidth(_text) + 40;
            if (width > _sizeNeeded.width) {
                _sizeNeeded.width = width;
            }
            int height = metrics.getHeight() + 40;
            if (height > _sizeNeeded.height) {
                _sizeNeeded.height = height;
            }
        }
        setSize(_sizeNeeded);
        _scroller.repaint();
        repaint();
    }

    public static void reversePositions(Point[] nodes) {
        for (int i = 0; i < nodes.length; i++) {
            int temp = nodes[i].x;
            nodes[i].x = nodes[i].y;
            nodes[i].y = temp;
        }
    }

    public void setError(UnreachableNodesExistException unee, RootListModel root) {
        _graph = null;
        _text = unee.getMessage();
        _unee = unee;
        _rootListModel = root;
        refreshSize();
    }

    public void setGraph(FlowchartGraph graph) {
        _graph = graph;
        _text = DEFAULT_DISPLAY_TEXT;
        _unee = null;
        refreshSize();
    }

    public void setLandscape(boolean landscape) {
        _isLandscape = landscape;
        if (_graph != null) {
            refreshSize();
        }
    }

    public void setScales() {
        setScales(false);
    }

    private void setScales(boolean initSpace) {
        Dimension maxDim = getMaxNodeDimensions();
        _nodeX = maxDim.width;
        _nodeY = maxDim.height;
        if (initSpace) {
            _spaceX = _nodeX;
            _spaceY = _nodeY;
        }
    }

    public void setText(String text) {
        _graph = null;
        _text = text;
        _unee = null;
        refreshSize();
    }

    public void setXSpace(int x) {
        _spaceX = x;
        if (_graph != null) {
            refreshSize();
        }
    }

    public void setYSpace(int y) {
        _spaceY = y;
        if (_graph != null) {
            refreshSize();
        }
    }

    public void setZoom(int z) {
        _zoom = z;
        refreshSize();
    }
}
