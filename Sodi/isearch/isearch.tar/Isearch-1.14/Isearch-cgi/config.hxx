#ifndef _config_
#define _config_

#define VERSION "1.05"

#endif

