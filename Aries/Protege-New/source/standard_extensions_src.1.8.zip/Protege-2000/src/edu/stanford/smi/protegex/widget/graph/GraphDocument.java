/*
 * The contents of this file are subject to the Mozilla Public License
 * Version 1.1 (the "License");  you may not use this file except in compliance
 * with the License.  You may obtain a copy of the License at
 * http://www.mozilla.org/MPL/
 *
 * Software distributed under the License is distributed on an "AS IS" basis,
 * WITHOUT WARRANTY OF ANY KIND, either express or implied. See the License for
 * the specific language governing rights and limitations under the License.
 *
 * The Original Code is Protege-2000.
 *
 * The Initial Developer of the Original Code is Stanford University. Portions
 * created by Stanford University are Copyright (C) 2001.  All Rights Reserved.
 *
 * Protege-2000 was developed by Stanford Medical Informatics
 * (http://www.smi.stanford.edu) at the Stanford University School of Medicine
 * with support from the National Library of Medicine, the National Science
 * Foundation, and the Defense Advanced Research Projects Agency.  Current
 * information about Protege can be obtained at http://protege.stanford.edu
 *
 * Contributor(s):
 */

package edu.stanford.smi.protegex.widget.graph;

import java.awt.Point;
import java.awt.Rectangle;
import java.util.Collection;
import java.util.HashMap;
import java.util.Iterator;

import com.nwoods.jgo.JGoBrush;
import com.nwoods.jgo.JGoDocument;
import com.nwoods.jgo.JGoLink;
import com.nwoods.jgo.JGoListPosition;
import com.nwoods.jgo.JGoObject;
import com.nwoods.jgo.layout.JGoLayeredDigraphAutoLayout;

import edu.stanford.smi.protege.model.Cls;
import edu.stanford.smi.protege.model.Instance;
import edu.stanford.smi.protege.model.KnowledgeBase;
import edu.stanford.smi.protege.model.Slot;
import edu.stanford.smi.protege.util.PropertyList;

public class GraphDocument extends JGoDocument {
    private KnowledgeBase kb = null;
    private PropertyList pList = null;
    private Instance instance = null;
    private Slot slot = null;
    private HashMap instanceMap = new HashMap();
    private HashMap positionMap;
    private String key = null;

    public GraphDocument(KnowledgeBase kb, PropertyList pList, Instance instance, Slot slot) {
        super();
        this.kb = kb;
        this.pList = pList;
        this.instance = instance;
        this.slot = slot;

        key = "InstanceGraphWidget." + instance.getName() + "." + slot.getName();
        positionMap = (HashMap) kb.getProject().getClientInformation(key);
        if (positionMap == null) {
            positionMap = new HashMap();
        }
    }

    public KnowledgeBase getKB() {
        return kb;
    }

    public PropertyList getPropertyList() {
        return pList;
    }

    public void initNodes(Collection instances) {
        setSuspendUpdates(true);

        if (instances != null) {
            Iterator i = instances.iterator();
            while (i.hasNext()) {
                Instance instance = (Instance) i.next();
                Cls cls = instance.getDirectType();

                NodeProperties props = new NodeProperties(cls.getName(), pList);
                String shape = props.getShape();

                Node node = new Node();
                node.initialize(new Point(), shape, instance.getBrowserText());

                // Set the node's color.
                node.setBrush(JGoBrush.makeStockBrush(props.getShapeColor()));

                // Set the node's size.
                node.setSize(GraphTypes.NODE_WIDTH, GraphTypes.NODE_HEIGHT);

                // Set the node's text properties.
                node.getLabel().setTextColor(props.getTextColor());
                node.getLabel().setBold(props.isBold());
                node.getLabel().setItalic(props.isItalic());

                // Set the node's connector slot.
                String connectorSlot = props.getConnectorSlot();
                if (connectorSlot != null) {
                    node.setConnectorSlot(connectorSlot);
                }

                // Set the node's instance.
                node.setInstance(instance);

                instanceMap.put(instance, node);
                addObjectAtTail(node);
            }

            if (instances.size() >= 1) {
                initSimpleLinks(instances);
                initComplexLinks();
                layoutNodesAndLinks();
            }
        }

        setSuspendUpdates(false);
    }

    private void initSimpleLinks(Collection instances) {
        Iterator i = instances.iterator();
        while (i.hasNext()) {
            Instance instance = (Instance) i.next();
            Node node = (Node) instanceMap.get(instance);
            Slot connectorSlot = node.getConnectorSlot();
            if (connectorSlot != null) {
                Collection values = instance.getDirectOwnSlotValues(connectorSlot);
                Iterator j = values.iterator();
                while (j.hasNext()) {
                    Instance destInstance = (Instance) j.next();
                    Node destNode = (Node) instanceMap.get(destInstance);
                    if (destNode != null) {
                        LinkUtilities lu = new LinkUtilities(kb, pList, node.getPort(), destNode.getPort());
                        if (lu.hasValidConnectorSlot()) {
                            SimpleLink sLink = lu.restoreSimpleLink();
                            addObjectAtTail(sLink);
                        }
                    }
                }
            }
        }
    }

    private void initComplexLinks() {
        // Get the slot that the user designated to hold reified relations.
        // (This is done on the widget configuration panel).
        String relationSlotName = pList.getString(GraphTypes.RELATION_SLOT);
        Slot relationSlot = kb.getSlot(relationSlotName);

        if (relationSlot != null) {
            Slot fromSlot = kb.getSlot(GraphTypes.FROM_SLOT);
            Slot toSlot = kb.getSlot(GraphTypes.TO_SLOT);

            Collection c = instance.getDirectOwnSlotValues(relationSlot);
            Iterator i = c.iterator();
            while (i.hasNext()) {
                Instance instance = (Instance) i.next();
                Instance fromInstance = (Instance) instance.getOwnSlotValue(fromSlot);
                Instance toInstance = (Instance) instance.getOwnSlotValue(toSlot);

                if ((fromInstance != null) && (toInstance != null)) {
                    Node fromNode = (Node) instanceMap.get(fromInstance);
                    Node toNode = (Node) instanceMap.get(toInstance);

                    if ((fromNode != null) && (toNode != null)) {
                        LinkUtilities lu = new LinkUtilities(kb, pList, fromNode.getPort(), toNode.getPort());
                        ComplexLink cLink = lu.restoreComplexLink(instance);
                        addObjectAtTail(cLink);
                    }
                }
            }
        }
    }

    private void layoutNodesAndLinks() {
        if (positionMap.isEmpty()) {
            // Default to downward directed layout.
            performAutomaticLayout(JGoLayeredDigraphAutoLayout.LD_DIRECTION_DOWN);
        } else {
            JGoListPosition pos = getFirstObjectPos();
            while (pos != null) {
                JGoObject obj = getObjectAtPos(pos);
                if (obj instanceof Node) {
                    Node node = (Node) obj;
                    Instance instance = node.getInstance();
                    Rectangle rect = (Rectangle) positionMap.get(instance.getName());
                    if (rect != null) {
                        node.setBoundingRect(rect);
                    }
                } else if (obj instanceof SimpleLink) {
                    SimpleLink sLink = (SimpleLink) obj;
                    Node fromNode = (Node) sLink.getFromPort().getParent();
                    Node toNode = (Node) sLink.getToPort().getParent();
                    String key = fromNode.getInstance().getName() + "+" + toNode.getInstance().getName();
                    HashMap pointMap = (HashMap) positionMap.get(key);
                    insertPointsIntoLink(pointMap, sLink);
                } else if (obj instanceof ComplexLink) {
                    ComplexLink cLink = (ComplexLink) obj;
                    String key = cLink.getInstance().getName();
                    HashMap pointMap = (HashMap) positionMap.get(key);
                    insertPointsIntoLink(pointMap, cLink);
                }
                pos = getNextObjectPosAtTop(pos);
            }
        }
    }

    public void performAutomaticLayout(int direction) {
        JGoLayeredDigraphAutoLayout layout = new JGoLayeredDigraphAutoLayout(this);
        layout.setDirectionOption(direction);
        layout.performLayout();
        savePositionInfo();
    }

    public void savePositionInfo() {
        positionMap.clear();

        JGoListPosition pos = getFirstObjectPos();
        while (pos != null) {
            JGoObject obj = getObjectAtPos(pos);
            if (obj instanceof Node) {
                Node node = (Node) obj;
                Instance instance = node.getInstance();
                positionMap.put(instance.getName(), obj.getBoundingRect());
            } else if (obj instanceof JGoLink) {
                JGoLink link = (JGoLink) obj;
                int numPoints = link.getNumPoints();
                if (numPoints > 2) {
                    HashMap pointMap = new HashMap();
                    for (int i = 1; i < (numPoints - 1); i++) {
                        Point point = link.getPoint(i);

                        // Need to do this extra work because the
                        // setClientInformation call on the project object
                        // has restrictions on the sort of data it will
                        // accept.
                        Integer xInt = new Integer(point.x);
                        Integer yInt = new Integer(point.y);
                        String s = xInt.toString() + "," + yInt.toString();
                        GraphPoint gp = new GraphPoint(s);
                        Integer count = new Integer(i);
                        pointMap.put(count.toString(), gp);
                    }

                    String key = null;
                    if (link instanceof SimpleLink) {
                        Node fromNode = (Node) link.getFromPort().getParent();
                        Node toNode = (Node) link.getToPort().getParent();
                        key = fromNode.getInstance().getName() + "+" + toNode.getInstance().getName();
                    } else if (link instanceof ComplexLink) {
                        ComplexLink cLink = (ComplexLink) link;
                        Instance instance = cLink.getInstance();
                        key = instance.getName();
                    }

                    positionMap.put(key, pointMap);
                }
            }

            // Increment.
            pos = getNextObjectPosAtTop(pos);
        }

        kb.getProject().setClientInformation(key, positionMap);
    }

    private void insertPointsIntoLink(HashMap pointMap, JGoLink link) {
        if (pointMap != null) {
            for (int i = 0; i < pointMap.size(); i++) {
                // Add one to 'i' here because we are adding a series of points
                // to the middle of a JGoLink.  In other words, we are doing
                // insertions - don't want to overwrite the first or last point
                // in the link.
                Integer count = new Integer(i + 1);
                GraphPoint gp = (GraphPoint) pointMap.get(count.toString());
                link.insertPoint(count.intValue(), gp.getXInt(), gp.getYInt());
            }
        }
    }

    public static HashMap getPositionInfo(Instance instance, Slot slot) {
        HashMap positionMap = new HashMap();
        if ((instance != null) && (slot != null)) {
            String key = "InstanceGraphWidget." + instance.getName() + "." + slot.getName();
            KnowledgeBase kb = instance.getKnowledgeBase();
            positionMap = (HashMap) kb.getProject().getClientInformation(key);
        }
        return positionMap;
    }
}