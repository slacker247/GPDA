package protegex.prologtab;

/**
 * Interface for handlers of TextReader idle loops.
 * Creation date: (4/26/2002 2:40:26 PM)
 * @author: 
 */
public interface IdleHandler {
/**
 * Reader loop is idle.
 * Creation date: (4/26/2002 2:40:37 PM)
 */
void idle();
}
