/*
 * The contents of this file are subject to the Mozilla Public License
 * Version 1.1 (the "License");  you may not use this file except in compliance
 * with the License.  You may obtain a copy of the License at
 * http://www.mozilla.org/MPL/
 *
 * Software distributed under the License is distributed on an "AS IS" basis,
 * WITHOUT WARRANTY OF ANY KIND, either express or implied. See the License for
 * the specific language governing rights and limitations under the License.
 *
 * The Original Code is Protege-2000.
 *
 * The Initial Developer of the Original Code is Stanford University. Portions
 * created by Stanford University are Copyright (C) 2001.  All Rights Reserved.
 *
 * Protege-2000 was developed by Stanford Medical Informatics
 * (http://www.smi.stanford.edu) at the Stanford University School of Medicine
 * with support from the National Library of Medicine, the National Science
 * Foundation, and the Defense Advanced Research Projects Agency.  Current
 * information about Protege can be obtained at http://protege.stanford.edu
 *
 * Contributor(s):
 */

package edu.stanford.smi.protegex.widget.diagram;

import java.awt.event.*;
import java.util.*;

import javax.swing.*;

import edu.stanford.smi.protege.model.*;
import edu.stanford.smi.protegex.layout.*;

/**
 *  Description of the class
 *
 * @author    William Grosso <grosso@smi.stanford.edu>
 */
public abstract class Diagrams_RemovalSuperclass extends Diagrams_Action {
    private InstanceCollector _instanceCollector;
    private ReferenceCollector _referenceCollector;
    private EventPoster _eventPoster;
    private ZOrder _zOrder;
    private ArrayList _nodesToRemove;
    private ArrayList _wiresToRemove;

    private class InstanceCollector implements ActorAction {
        public void performMethod(final Actor actor) {
            if (actor.getIsSelected()) {
                Instance instance = ((ActorInstance) actor).getInstance();
                DiagramUtilities.removeLayoutInformation(_widget.getNetworkInstance(), instance);
                if (actor instanceof WireActorInstance) {
                    _wiresToRemove.add(actor);
                } else {
                    _nodesToRemove.add(actor);
                }
            }
        }
    }

    private class ReferenceCollector implements ActorAction {
        public void performMethod(Actor actor) {
            if (actor.isWire()) {
                final WireActorInstance wireActor = (WireActorInstance) actor;
                Iterator i = _nodesToRemove.iterator();
                while (i.hasNext()) {
                    ActorInstance nextNode = (ActorInstance) i.next();
                    if (attached(wireActor, nextNode) &&
                            (!_wiresToRemove.contains(wireActor))) {
                        _wiresToRemove.add(wireActor);
                    }
                }
            }
        }
    }

    private class EventPoster implements Runnable {
        public void run() {
            Iterator i = _nodesToRemove.iterator();
            while (i.hasNext()) {
                Actor nodeActor = (Actor) i.next();
                performNodeAction(nodeActor);
                _zOrder.removeActor(nodeActor);

                // this seems to be necessary to clear this actor out of a cache (rwf)
                nodeActor.getAnimationContext().unselectActor(nodeActor);
            }
            _nodesToRemove.clear();
            i = _wiresToRemove.iterator();
            while (i.hasNext()) {
                WireActorInstance wireActor = (WireActorInstance) i.next();
                performWireAction(wireActor);
                _zOrder.removeActor(wireActor);

                // this seems to be necessary to clear this actor out of a cache (rwf)
                wireActor.getAnimationContext().unselectActor(wireActor);
            }
            _wiresToRemove.clear();
            _mainDrawingArea.getOwner().repaint();
        }
    }

    public Diagrams_RemovalSuperclass(DiagramWidget widget, AnimationContext mainDrawingArea, String tooltip, Icon icon) {
        super(widget, mainDrawingArea, tooltip, icon);
        _nodesToRemove = new ArrayList();
        _wiresToRemove = new ArrayList();
        _eventPoster = new EventPoster();
        _instanceCollector = new InstanceCollector();
        _referenceCollector = new ReferenceCollector();
    }

    public void actionPerformed(ActionEvent event) {
        _zOrder = _mainDrawingArea.getZOrder();
        _zOrder.performAction(0, _instanceCollector);
        _zOrder.performAction(0, _referenceCollector);
        SwingUtilities.invokeLater(_eventPoster);
    }

    private boolean attached(ActorAttachment attachment, ActorInstance node) {
        if (null == attachment) {
            return false;
        }
        Actor target = attachment.getActor();
        return (node == target);
    }

    private boolean attached(WireActorInstance wireActor, ActorInstance node) {
        ActorAttachment startingAttachment = wireActor.getStartingAttachment();
        if (attached(startingAttachment, node)) {
            return true;
        }
        ActorAttachment endingAttachment = wireActor.getEndingAttachment();
        if (attached(endingAttachment, node)) {
            return true;
        }
        return false;
    }

    protected abstract void performNodeAction(Actor actor);

    protected abstract void performWireAction(WireActorInstance actor);
}
