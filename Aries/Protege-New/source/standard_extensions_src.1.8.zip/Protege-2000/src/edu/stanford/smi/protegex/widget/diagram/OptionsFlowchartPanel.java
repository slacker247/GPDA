/*
 * The contents of this file are subject to the Mozilla Public License
 * Version 1.1 (the "License");  you may not use this file except in compliance
 * with the License.  You may obtain a copy of the License at
 * http://www.mozilla.org/MPL/
 *
 * Software distributed under the License is distributed on an "AS IS" basis,
 * WITHOUT WARRANTY OF ANY KIND, either express or implied. See the License for
 * the specific language governing rights and limitations under the License.
 *
 * The Original Code is Protege-2000.
 *
 * The Initial Developer of the Original Code is Stanford University. Portions
 * created by Stanford University are Copyright (C) 2001.  All Rights Reserved.
 *
 * Protege-2000 was developed by Stanford Medical Informatics
 * (http://www.smi.stanford.edu) at the Stanford University School of Medicine
 * with support from the National Library of Medicine, the National Science
 * Foundation, and the Defense Advanced Research Projects Agency.  Current
 * information about Protege can be obtained at http://protege.stanford.edu
 *
 * Contributor(s):
 */

package edu.stanford.smi.protegex.widget.diagram;

import java.awt.*;
import java.awt.event.*;
import java.util.*;

import javax.swing.*;

import edu.stanford.smi.protege.model.*;
import edu.stanford.smi.protegex.layout.*;

/**
 *  Description of the class
 *
 * @author    William Grosso <grosso@smi.stanford.edu>
 */
public class OptionsFlowchartPanel extends JSplitPane implements Constants {
    private JTextField _iterationField, _heightScale, _widthScale, _zoomScale;
    private ConnectorChooser _connectorsDisplayer;
    private TypeBasedVisibilityChecker _typeChecker;
    private JList _rootList;
    private RootListModel _rootListModel;
    private DiagramWidget _widget;
    private JButton _layoutButton;
    private JButton _applyButton;
    private PreviewFlowchartPanel _previewPanel;
    private FlowchartAdapter _eventAdapter;
    private JSplitPane _optionSplitter;
    private JRadioButton _topDown, _leftRight;
    private ButtonGroup _orientation;
    private boolean _currentlyListeningToKB;

    private class ScaleListener implements FocusListener {
        public void focusGained(FocusEvent e) {
        }

        public void focusLost(FocusEvent e) {
            JTextField source = (JTextField) (e.getSource());
            String str = source.getText();
            if ((str == null) || (str.equals(""))) {
                return;
            }
            int value = Integer.parseInt(source.getText());
            if (value <= 0) {
                return;
            }
            if (source == _widthScale) {
                _previewPanel.setXSpace(value);
            } else if (source == _heightScale) {
                _previewPanel.setYSpace(value);
            } else if (source == _zoomScale) {
                _previewPanel.setZoom(value);
            }
        }
    }

    public OptionsFlowchartPanel(DiagramWidget widget, PreviewFlowchartPanel preview) {
        super(JSplitPane.HORIZONTAL_SPLIT, false);
        _widget = widget;
        _previewPanel = preview;
        _widget.setFlowchartPanel(this);
        buildGUI();
        _eventAdapter = new FlowchartAdapter(this, _previewPanel);
        addEventAdapter();
    }

    private void addConnectorOptions(JSplitPane split) {
        _typeChecker = (TypeBasedVisibilityChecker) _widget.getVisibilityChecker(CONFIGURATION_BASED_VISIBILITY_CHECKER);
        Collection connectorClses = _widget.getConnectorClses();
        _connectorsDisplayer =
            new ConnectorChooser(connectorClses, _typeChecker, _widget, "Connectors to be included...", _eventAdapter);
        split.setBottomComponent(_connectorsDisplayer);
    }

    private void addEdgesToGraph(FlowchartGraph g) {
        Object[] allConnectors = _widget.getConnectors().toArray();
        for (int i = 0; i < allConnectors.length; i++) {
            Instance connector = (Instance) (allConnectors[i]);
            if (_connectorsDisplayer.isChecked(connector.getDirectType())) {
                Instance head = (Instance) ModelUtilities.getOwnSlotValue(connector, FIRST_OBJECT_SLOT_NAME);
                Instance tail = (Instance) ModelUtilities.getOwnSlotValue(connector, SECOND_OBJECT_SLOT_NAME);
                int headIndex = _rootListModel.getIndexOfInstance(head);
                int tailIndex = _rootListModel.getIndexOfInstance(tail);
                g.addEdge(1 + headIndex, 1 + tailIndex);
            }
        }
    }

    private void addEventAdapter() {
        if (_currentlyListeningToKB) {
            return;
        }
        _widget.getNetworkInstance().addFrameListener(_eventAdapter);
        Collection connectors = _widget.getConnectors();
        Iterator itr = connectors.iterator();
        while (itr.hasNext()) {
            Instance ctr = (Instance) (itr.next());
            ctr.addFrameListener(_eventAdapter);
        }
        Collection ctrClasses = _widget.getConnectorClses();
        itr = ctrClasses.iterator();
        while (itr.hasNext()) {
            Cls cls = (Cls) (itr.next());
            cls.addClsListener(_eventAdapter);
        }
        _currentlyListeningToKB = true;
    }

    private void addGeneralOptions(JSplitPane split) {
        JPanel panel = new JPanel(new GridLayout(0, 2));
        panel.add(new JLabel("Iterations", SwingConstants.RIGHT));
        _iterationField = new JTextField("1");
        panel.add(_iterationField);

        _orientation = new ButtonGroup();
        ActionListener orientListener = new ActionListener() {
            public void actionPerformed(ActionEvent e) {
                _previewPanel.setLandscape(isLandscape());
            }
        };

        _topDown = new JRadioButton("Portrait", true);
        _topDown.addActionListener(orientListener);
        _orientation.add(_topDown);
        panel.add(_topDown);

        _leftRight = new JRadioButton("Landscape", false);
        _leftRight.addActionListener(orientListener);
        _orientation.add(_leftRight);
        panel.add(_leftRight);

        ScaleListener scaleListener = new ScaleListener();

        panel.add(new JLabel("Zoom factor", SwingConstants.RIGHT));
        String strZoom = Integer.toString(_previewPanel.getZoom());
        _zoomScale = new JTextField(strZoom);
        _zoomScale.addFocusListener(scaleListener);
        panel.add(_zoomScale);

        panel.add(new JLabel("Horizontal spacing", SwingConstants.RIGHT));
        String strWidth = Integer.toString(_previewPanel.getXSpace());
        _widthScale = new JTextField(strWidth);
        _widthScale.addFocusListener(scaleListener);
        panel.add(_widthScale);

        panel.add(new JLabel("Vertical spacing", SwingConstants.RIGHT));
        String strHeight = Integer.toString(_previewPanel.getYSpace());
        _heightScale = new JTextField(strHeight);
        _heightScale.addFocusListener(scaleListener);
        panel.add(_heightScale);

        _layoutButton = new JButton("Preview");
        _layoutButton.addActionListener(new ActionListener() {
            public void actionPerformed(ActionEvent e) {
                doLayoutNow();
            }
        });
        panel.add(_layoutButton);

        _applyButton = new JButton("Apply");
        _applyButton.addActionListener(new ActionListener() {
            public void actionPerformed(ActionEvent e) {
                applyLayoutNow();
            }
        });
        panel.add(_applyButton);

        split.setTopComponent(panel);
    }

    private void addOptions() {
        _optionSplitter = new JSplitPane(JSplitPane.VERTICAL_SPLIT, false);
        addGeneralOptions(_optionSplitter);
        addConnectorOptions(_optionSplitter);
        setLeftComponent(_optionSplitter);
    }

    private void addRootList() {
        JPanel rootPanel = new JPanel(new BorderLayout());
        _rootListModel = new RootListModel(_widget);
        _rootList = new JList(_rootListModel);
        setRootListDefaults();
        _rootList.addListSelectionListener(_eventAdapter);

        rootPanel.add(new JLabel("Root(s)"), BorderLayout.NORTH);
        rootPanel.add(new JScrollPane(_rootList), BorderLayout.CENTER);
        setRightComponent(rootPanel);
    }

    private void addRootsToGraph(FlowchartGraph g) {
        int[] selectedRoots = _rootList.getSelectedIndices();
        for (int i = 0; i < selectedRoots.length; i++) {
            g.addRoot(1 + selectedRoots[i]);
        }
    }

    private void applyLayoutNow() {
        FlowchartGraph g = _previewPanel.getFlowchart();
        if (g == null) {
            return;
        }
        Point[] locations = _previewPanel.getNodeLocations(1);
        DiagramsAnimationContext context = (DiagramsAnimationContext) (_widget.getMainDrawingArea());
        for (int i = 0; i < locations.length; i++) {
            Instance node = _rootListModel.getInstanceAt(i);
            Actor actor = context.getActorForInstance(node);
            actor.move(locations[i].x, locations[i].y);
            DiagramUtilities.updateNodeLocation(_widget.getNetworkInstance(), actor);
        }
        updateCanvas(g);
        //  _widget.repaint();
    }

    private void buildGUI() {
        addRootList();
        addOptions();
    }

    private static int[] convertVectorToArray(Vector v) {
        int[] result = new int[v.size()];
        for (int i = 0; i < result.length; i++) {
            result[i] = ((Integer) (v.elementAt(i))).intValue();
        }
        return result;
    }

    private FlowchartGraph createNewGraph() {
        int numNodes = _widget.getNodes().size();
        FlowchartGraph result = new FlowchartGraph(numNodes);
        addRootsToGraph(result);
        addEdgesToGraph(result);
        return result;
    }

    public void dispose() {
        removeEventAdapter();
    }

    private void doLayoutNow() {
        boolean isNewLayout = (_previewPanel.getFlowchart() == null);
        FlowchartGraph g = isNewLayout ? createNewGraph() : _previewPanel.getFlowchart();
        int numIterations = Integer.parseInt(_iterationField.getText());
        if (isNewLayout) {
            try {
                g.doLayout(numIterations);
                _previewPanel.setGraph(g);
            } catch (UnreachableNodesExistException unee) {
                _previewPanel.setError(unee, _rootListModel);
            }
        } else {
            g.reLayout(numIterations);
            _previewPanel.setScales();
            _previewPanel.refreshSize();
        }
    }

    private Vector getAllIndices() {
        Vector result = new Vector();
        for (int i = 0; i < _rootListModel.getSize(); i++) {
            result.add(new Integer(i));
        }
        return result;
    }

    public int getNumConnectors() {
        return _widget.getConnectors().size();
    }

    public boolean isLandscape() {
        return _leftRight.isSelected();
    }

    public void rebuild() {
        if (_currentlyListeningToKB) {
            removeEventAdapter();
            addEventAdapter();
        }
    }

    private void removeEventAdapter() {
        if (_currentlyListeningToKB) {
            Collection ctrClasses = _widget.getConnectorClses();
            Iterator itr = ctrClasses.iterator();
            while (itr.hasNext()) {
                Cls cls = (Cls) (itr.next());
                cls.removeClsListener(_eventAdapter);
            }
            Collection connectors = _widget.getConnectors();
            itr = connectors.iterator();
            while (itr.hasNext()) {
                Instance ctr = (Instance) (itr.next());
                ctr.removeFrameListener(_eventAdapter);
            }
            _widget.getNetworkInstance().removeFrameListener(_eventAdapter);
            _currentlyListeningToKB = false;
        }
    }

    public void resetConnectors() {
        addConnectorOptions(_optionSplitter);
        _previewPanel.setGraph(null);
    }

    public void resetRoots() {
        addRootList();
        _previewPanel.setGraph(null);
    }

    public void setCurrentlyBeingDisplayed(boolean currentlyBeingDisplayed) {
        if (currentlyBeingDisplayed) {
            addEventAdapter();
        } else {
            removeEventAdapter();
        }
    }

    private void setRootListDefaults() {
        Vector selectedIndices = getAllIndices();
        Collection connectors = _widget.getConnectors();
        Iterator itr = connectors.iterator();
        while (itr.hasNext()) {
            Instance connector = (Instance) (itr.next());
            Instance tail = (Instance) ModelUtilities.getOwnSlotValue(connector, SECOND_OBJECT_SLOT_NAME);
            int tailLoc = _rootListModel.getIndexOfInstance(tail);
            selectedIndices.remove(new Integer(tailLoc));
        }
        _rootList.setSelectedIndices(convertVectorToArray(selectedIndices));
    }

    private void updateCanvas(FlowchartGraph g) {
        double graphHeight = (isLandscape()) ? g.getMaxWidth() : g.getDepth() - 1;
        double graphWidth = (isLandscape()) ? g.getDepth() - 1 : g.getMaxWidth();
        int canvasHeight = (int) (graphHeight * _previewPanel.getYScale()) + _previewPanel.getYNode();
        int canvasWidth = (int) (graphWidth * _previewPanel.getXScale()) + _previewPanel.getXNode();
        DiagramsAnimationContext context = (DiagramsAnimationContext) (_widget.getMainDrawingArea());
        context.enlargeToHeight(canvasHeight);
        context.enlargeToWidth(canvasWidth);
        _widget.repaint();
    }
}
