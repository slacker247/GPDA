/*
 * The contents of this file are subject to the Mozilla Public License
 * Version 1.1 (the "License");  you may not use this file except in compliance
 * with the License.  You may obtain a copy of the License at
 * http://www.mozilla.org/MPL/
 *
 * Software distributed under the License is distributed on an "AS IS" basis,
 * WITHOUT WARRANTY OF ANY KIND, either express or implied. See the License for
 * the specific language governing rights and limitations under the License.
 *
 * The Original Code is Protege-2000.
 *
 * The Initial Developer of the Original Code is Stanford University. Portions
 * created by Stanford University are Copyright (C) 2001.  All Rights Reserved.
 *
 * Protege-2000 was developed by Stanford Medical Informatics
 * (http://www.smi.stanford.edu) at the Stanford University School of Medicine
 * with support from the National Library of Medicine, the National Science
 * Foundation, and the Defense Advanced Research Projects Agency.  Current
 * information about Protege can be obtained at http://protege.stanford.edu
 *
 * Contributor(s):
 */

package edu.stanford.smi.protegex.widget.diagram;

import edu.stanford.smi.protege.model.*;
import edu.stanford.smi.protege.widget.*;
import edu.stanford.smi.protege.ui.*;
import edu.stanford.smi.protege.util.*;

import java.awt.*;

/**
 *  Description of the class
 *
 * @author    William Grosso <grosso@smi.stanford.edu>
 */
public class WireState extends DiagramObjectState {
    protected String _wireType;
    protected String _startingArrow;
    protected String _endingArrow;
    protected boolean _anchorTextAtUpperLeftCorner;

    protected final static String WIRE_THICKNESS = ":WIRE:THICKNESS";
    protected final static String WIRE_TYPE = ":WIRE:TYPE";
    protected final static String STARTING_ARROW = ":STARTING:ARROW";
    protected final static String ENDING_ARROW = ":ENDING:ARROW";
    protected final static String ANCHOR_TEXT_AT_UPPER_LEFT_CORNER = ":ANCHOR:TEXT:AT:UPPER:LEFT:CORNER";

    public WireState(PropertyList pList) {
        super(pList);
        _objectColor =
            readColor(pList, OBJECT_COLOR_RGB_DESCRIPTOR, edu.stanford.smi.protegex.layout.WireUtilities.DEFAULT_WIRE_COLOR);
        _textColor =
            readColor(pList, TEXT_COLOR_RGB_DESCRIPTOR, edu.stanford.smi.protegex.layout.WireUtilities.DEFAULT_TEXT_COLOR);
        _displayText = readBoolean(pList, DISPLAY_TEXT, edu.stanford.smi.protegex.layout.WireUtilities.DEFAULT_DISPLAY_TEXT);
        _wireType = readString(pList, WIRE_TYPE, edu.stanford.smi.protegex.layout.WireUtilities.DEFAULT_WIRE_TYPE);
        _startingArrow =
            readString(pList, STARTING_ARROW, edu.stanford.smi.protegex.layout.WireUtilities.DEFAULT_WIRE_STARTING_ARROW);
        _endingArrow =
            readString(pList, ENDING_ARROW, edu.stanford.smi.protegex.layout.WireUtilities.DEFAULT_WIRE_ENDING_ARROW);
        _anchorTextAtUpperLeftCorner =
            readBoolean(
                pList,
                ANCHOR_TEXT_AT_UPPER_LEFT_CORNER,
                edu.stanford.smi.protegex.layout.WireUtilities.DEFAULT_ANCHOR_TEXT_AT_UPPER_LEFT_CORNER);
    }

    public boolean getAnchorTextAtUpperLeftCorner() {
        return _anchorTextAtUpperLeftCorner;
    }

    public String getEndingArrow() {
        return _endingArrow;
    }

    public String getStartingArrow() {
        return _startingArrow;
    }

    public String getWireType() {
        return _wireType;
    }

    public boolean isAnchorTextAtUpperLeftCorner() {
        return _anchorTextAtUpperLeftCorner;
    }

    public void setAnchorTextAtUpperLeftCorner(boolean anchorTextAtUpperLeftCorner) {
        _anchorTextAtUpperLeftCorner = anchorTextAtUpperLeftCorner;
    }

    public void setEndingArrow(String endingArrow) {
        _endingArrow = endingArrow;
    }

    public void setStartingArrow(String startingArrow) {
        _startingArrow = startingArrow;
    }

    public void setWireType(String wireType) {
        _wireType = wireType;
    }

    public void writeToPropertyList(PropertyList pList) {
        super.writeToPropertyList(pList);
        pList.setString(WIRE_TYPE, _wireType);
        pList.setString(STARTING_ARROW, _startingArrow);
        pList.setString(ENDING_ARROW, _endingArrow);
        pList.setBoolean(ANCHOR_TEXT_AT_UPPER_LEFT_CORNER, _anchorTextAtUpperLeftCorner);
    }
}
