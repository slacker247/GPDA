/*
 * The contents of this file are subject to the Mozilla Public License
 * Version 1.1 (the "License");  you may not use this file except in compliance
 * with the License.  You may obtain a copy of the License at
 * http://www.mozilla.org/MPL/
 *
 * Software distributed under the License is distributed on an "AS IS" basis,
 * WITHOUT WARRANTY OF ANY KIND, either express or implied. See the License for
 * the specific language governing rights and limitations under the License.
 *
 * The Original Code is Protege-2000.
 *
 * The Initial Developer of the Original Code is Stanford University. Portions
 * created by Stanford University are Copyright (C) 2001.  All Rights Reserved.
 *
 * Protege-2000 was developed by Stanford Medical Informatics
 * (http://www.smi.stanford.edu) at the Stanford University School of Medicine
 * with support from the National Library of Medicine, the National Science
 * Foundation, and the Defense Advanced Research Projects Agency.  Current
 * information about Protege can be obtained at http://protege.stanford.edu
 *
 * Contributor(s):
 */

package edu.stanford.smi.protegex.widget.contains;

import edu.stanford.smi.protege.event.*;
import edu.stanford.smi.protege.model.*;
import edu.stanford.smi.protege.widget.*;
import edu.stanford.smi.protege.util.*;
import javax.swing.event.*;
import javax.swing.*;
import java.util.*;
import java.awt.*;

/**
 *  Description of the Class
 *
 * @author    William Grosso <grosso@smi.stanford.edu>
 */
public class NumberOfSlotValuesComponent extends JLabel {
    private Instance _instance;
    private Slot _slot;
    private CountChangeChecker _listener;

    private class CountChangeChecker implements FrameListener {
        public void ownSlotValueChanged(FrameEvent event) {
            resetLabel();
        }

        public void browserTextChanged(FrameEvent event) {
        }

        public void deleted(FrameEvent event) {
        }

        public void editabilityChanged(FrameEvent event) {
        }

        public void nameChanged(FrameEvent event) {
        }

        public void ownFacetAdded(FrameEvent event) {
        }

        public void ownFacetRemoved(FrameEvent event) {
        }

        public void ownFacetValueChanged(FrameEvent event) {
        }

        public void ownSlotAdded(FrameEvent event) {
        }

        public void ownSlotRemoved(FrameEvent event) {
        }

        public void visibilityChanged(FrameEvent event) {
        }
    }

    public NumberOfSlotValuesComponent(Instance instance, Slot slot) {
        _slot = slot;
        _listener = new CountChangeChecker();
        setInstance(instance);
    }

    public void dispose() {
        if (_instance != null) {
            _instance.removeFrameListener(_listener);
        }
    }

    private void resetLabel() {
        int numberOfValues = (_instance.getOwnSlotValues(_slot)).size();
        switch (numberOfValues) {
            case 0 :
                setText("     This slot has no values.");
                break;
            case 1 :
                setText("     This slot currently has 1 value.");
                break;
            default :
                setText("     This slot currently has " + numberOfValues + " values.");
                break;
        }
    }

    public void setInstance(Instance newInstance) {
        dispose();
        _instance = newInstance;
        if (_instance != null) {
            _instance.addFrameListener(_listener);
            resetLabel();
        }
    }
}
