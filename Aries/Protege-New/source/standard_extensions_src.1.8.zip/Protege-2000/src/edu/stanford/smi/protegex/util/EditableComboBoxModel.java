/*
 * The contents of this file are subject to the Mozilla Public License
 * Version 1.1 (the "License");  you may not use this file except in compliance
 * with the License.  You may obtain a copy of the License at
 * http://www.mozilla.org/MPL/
 *
 * Software distributed under the License is distributed on an "AS IS" basis,
 * WITHOUT WARRANTY OF ANY KIND, either express or implied. See the License for
 * the specific language governing rights and limitations under the License.
 *
 * The Original Code is Protege-2000.
 *
 * The Initial Developer of the Original Code is Stanford University. Portions
 * created by Stanford University are Copyright (C) 2001.  All Rights Reserved.
 *
 * Protege-2000 was developed by Stanford Medical Informatics
 * (http://www.smi.stanford.edu) at the Stanford University School of Medicine
 * with support from the National Library of Medicine, the National Science
 * Foundation, and the Defense Advanced Research Projects Agency.  Current
 * information about Protege can be obtained at http://protege.stanford.edu
 *
 * Contributor(s):
 */

package edu.stanford.smi.protegex.util;

import java.util.*;

import javax.swing.*;

/**
 *  Description of the class
 *
 * @author    William Grosso <grosso@smi.stanford.edu>
 */
public class EditableComboBoxModel extends AbstractListModel implements ComboBoxModel {
    private ArrayList _contents;
    private Object _selectedItem;
    private int _oldSize;

    public EditableComboBoxModel() {
        _oldSize = 0;
        setContents(new ArrayList());
    }

    public EditableComboBoxModel(Collection contents) {
        _oldSize = 0;
        setContents(contents);
    }

    public void add(Object item) {
        _contents.add(item);
        fireContentsChanged(this, 0, _oldSize);
        _oldSize = _contents.size();
    }

    public void fireContentsChanged() {
        this.fireContentsChanged(this, 0, getSize());
    }

    public Object getElementAt(int index) {
        return _contents.get(index);
    }

    public Object getSelectedItem() {
        return _selectedItem;
    }

    public int getSize() {
        return _contents.size();
    }

    public void insertItemAt(int index, Object item) {
        if (index < _contents.size()) {
            _contents.add(index, item);
        } else {
            _contents.add(item);
        }
        fireContentsChanged(this, 0, _oldSize);
        _oldSize = _contents.size();
    }

    public void setContents(Collection newContents) {
        _contents = new ArrayList(newContents);
        fireContentsChanged(this, 0, _oldSize);
        _oldSize = _contents.size();
    }

    public void setSelectedItem(Object anItem) {
        _selectedItem = anItem;
        fireContentsChanged(this, -1, -1);
    }
}
