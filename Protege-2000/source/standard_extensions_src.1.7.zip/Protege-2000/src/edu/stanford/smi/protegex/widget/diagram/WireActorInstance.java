/*
 * The contents of this file are subject to the Mozilla Public License
 * Version 1.1 (the "License");  you may not use this file except in compliance
 * with the License.  You may obtain a copy of the License at
 * http://www.mozilla.org/MPL/
 *
 * Software distributed under the License is distributed on an "AS IS" basis,
 * WITHOUT WARRANTY OF ANY KIND, either express or implied. See the License for
 * the specific language governing rights and limitations under the License.
 *
 * The Original Code is Protege-2000.
 *
 * The Initial Developer of the Original Code is Stanford University. Portions
 * created by Stanford University are Copyright (C) 2001.  All Rights Reserved.
 *
 * Protege-2000 was developed by Stanford Medical Informatics
 * (http://www.smi.stanford.edu) at the Stanford University School of Medicine
 * with support from the National Library of Medicine, the National Science
 * Foundation, and the Defense Advanced Research Projects Agency.  Current
 * information about Protege can be obtained at http://protege.stanford.edu
 *
 * Contributor(s):
 */

package edu.stanford.smi.protegex.widget.diagram;

import edu.stanford.smi.protegex.layout.*;

import edu.stanford.smi.protege.model.*;

import java.awt.*;
import java.text.*;
import java.awt.event.*;

/**
 *  Description of the class
 *
 * @author    William Grosso <grosso@smi.stanford.edu>
 */
public class WireActorInstance extends StandardWireActor implements ActorInstance {
    private Instance _instance;
    private DiagramWidget _widget;

    protected Rectangle _textRectangle;
    protected WireTextualOverlay _textRenderer;
    protected WireState _wireState;
    protected WireGlyph _wireGlyph;

    public WireActorInstance(
        WireGlyph glyph,
        AnimationContext animationContext,
        ActorLocation location,
        ActorEventHandler eventHandler,
        ActorMovementHandler movementHandler,
        ActorControlPointHandler controlPointHandler,
        DiagramWidget widget,
        WireState wireState) {
        super(glyph, animationContext, location, eventHandler, movementHandler, controlPointHandler);
        _wireGlyph = glyph;
        _widget = widget;
        _wireState = wireState;
        _textRectangle = new Rectangle();
        _textRenderer = new WireTextualOverlay(_wireState);
    }

    private void configureWireEndpoints() {
        _wireGlyph.setStartingArrowIsConnected(null != getStartingAttachment());
        _wireGlyph.setEndingArrowIsConnected(null != getEndingAttachment());
    }

    public Object copy() {
        WireGlyph copyOfGlyph = (WireGlyph) _wireGlyph.copy();
        ActorLocation copyOfLocation = (ActorLocation) _location.copy();
        ActorEventHandler copyOfEventHandler = (ActorEventHandler) _eventHandler.copy();
        ActorMovementHandler copyOfMovementHandler = (ActorMovementHandler) _movementHandler.copy();
        ActorControlPointHandler copyOfControlPointHandler = (ActorControlPointHandler) _controlPointHandler.copy();
        WireActorInstance returnValue =
            new WireActorInstance(
                copyOfGlyph,
                _animationContext,
                copyOfLocation,
                copyOfEventHandler,
                copyOfMovementHandler,
                copyOfControlPointHandler,
                _widget,
                _wireState);
        return returnValue;
    }

    public Rectangle draw(Graphics g) {
        if ((null == _instance) || (_widget.isConnectorVisible(_instance))) {
            configureWireEndpoints();
            Rectangle returnValue = super.draw(g);
            drawText(g, returnValue);
            return returnValue;
        }
        return null;
    }

    private void drawText(Graphics g, Rectangle boundsForText) {
        if (null != _instance) {
            String browserText = _instance.getBrowserText();
            if (!browserText.equals(_textRenderer.getString())) {
                _textRenderer.setString(browserText);
            }
            _location.getBounds(_textRectangle);
            _textRenderer.draw(g, _textRectangle, getIsSelected());
        }
    }

    public Instance getInstance() {
        return _instance;
    }

    public boolean isAlwaysDisplayText() {
        return _textRenderer.isAlwaysDisplayText();
    }

    public void setAlwaysDisplayText(boolean alwaysDisplayText) {
        _textRenderer.setAlwaysDisplayText(alwaysDisplayText);
    }

    public void setInstance(Instance instance) {
        setInstance(instance, true);
    }

    public void setInstance(Instance instance, boolean createAttachmentListener) {
        if ((createAttachmentListener) && (null != instance)) {
            new ListensToWireMovements(instance.getProject(), this, instance, _widget.getNetworkInstance());
        }
        _instance = instance;
    }
}
