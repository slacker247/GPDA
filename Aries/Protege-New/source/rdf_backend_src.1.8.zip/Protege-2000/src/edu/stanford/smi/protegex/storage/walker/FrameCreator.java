/*
 * The contents of this file are subject to the Mozilla Public License
 * Version 1.1 (the "License");  you may not use this file except in compliance
 * with the License.  You may obtain a copy of the License at
 * http://www.mozilla.org/MPL/
 *
 * Software distributed under the License is distributed on an "AS IS" basis,
 * WITHOUT WARRANTY OF ANY KIND, either express or implied. See the License for
 * the specific language governing rights and limitations under the License.
 *
 * The Original Code is Protege-2000.
 *
 * The Initial Developer of the Original Code is Stanford University. Portions
 * created by Stanford University are Copyright (C) 2001.  All Rights Reserved.
 *
 * Protege-2000 was developed by Stanford Medical Informatics
 * (http://www.smi.stanford.edu) at the Stanford University School of Medicine
 * with support from the National Library of Medicine, the National Science
 * Foundation, and the Defense Advanced Research Projects Agency.  Current
 * information about Protege can be obtained at http://protege.stanford.edu
 *
 * Contributor(s):
 */

package edu.stanford.smi.protegex.storage.walker;

import java.util.*;

public interface FrameCreator {

  public void start();

  public void createCls(WalkerFrame cls, Collection superclasses,
    WalkerFrame type, boolean abstrct, String documentation);

  public boolean singleAllowedClass();

  public void createInstance(WalkerFrame instance, WalkerFrame type, 
    String documentation);

  public void createSlot(WalkerFrame slot, WalkerFrame type,
    Collection superslots, WalkerFrame inverseSlot,
    WalkerFrame associatedFacet,
    WalkerSlotRestriction slotRestriction, String documentation);

  public void attachSlot(WalkerFrame cls, WalkerFrame slot, boolean direct,
    WalkerSlotRestriction overriddenSlotRestriction,
    String overriddenDocumentation);
    // note: overriddenSlotRestriction != null if slot is somewhere
    // overridden (overriddenDocumentation can only be additionally != null!)

  public void addOwnSlotValues(WalkerFrame instance, WalkerFrame slot,
    Collection values);

  public void finish();

  public void error(String message);

}


