/*
 * The contents of this file are subject to the Mozilla Public License
 * Version 1.1 (the "License");  you may not use this file except in compliance
 * with the License.  You may obtain a copy of the License at
 * http://www.mozilla.org/MPL/
 *
 * Software distributed under the License is distributed on an "AS IS" basis,
 * WITHOUT WARRANTY OF ANY KIND, either express or implied. See the License for
 * the specific language governing rights and limitations under the License.
 *
 * The Original Code is Protege-2000.
 *
 * The Initial Developer of the Original Code is Stanford University. Portions
 * created by Stanford University are Copyright (C) 2001.  All Rights Reserved.
 *
 * Protege-2000 was developed by Stanford Medical Informatics
 * (http://www.smi.stanford.edu) at the Stanford University School of Medicine
 * with support from the National Library of Medicine, the National Science
 * Foundation, and the Defense Advanced Research Projects Agency.  Current
 * information about Protege can be obtained at http://protege.stanford.edu
 *
 * Contributor(s):
 */

package edu.stanford.smi.protegex.widget.graph;

import com.nwoods.jgo.JGoGridView;
import edu.stanford.smi.protege.util.PropertyList;

public class ViewProperties extends GraphProperties {
    private String gridStyle;
    private boolean wrapping;

    public ViewProperties(String clsName, PropertyList propertyList) {
        super(clsName, propertyList);
        initialize();
    }

    private void initialize() {
        String prefix = getPrefix();
        gridStyle = getStringProperty(prefix + "gridStyle", "Crosses");
        wrapping = getBooleanProperty(prefix + "wrapping", new Boolean(false));
    }

    public void save() {
        String prefix = getPrefix();
        PropertyList propertyList = getPropertyList();
        propertyList.setString(prefix + "gridStyle", this.gridStyle);
        propertyList.setBoolean(prefix + "wrapping", wrapping);
    }

    public String getGridStyle() {
        return gridStyle;
    }

    public int getGridStyleInt() {
        // Default to no grid lines.
        int retval = JGoGridView.GridInvisible;

        if (gridStyle != null) {
            if (gridStyle.equals(GraphTypes.GRID_CROSSES)) {
                retval = JGoGridView.GridCross;
            } else if (gridStyle.equals(GraphTypes.GRID_DOTS)) {
                retval = JGoGridView.GridDot;
            } else if (gridStyle.equals(GraphTypes.GRID_INVISIBLE)) {
                retval = JGoGridView.GridInvisible;
            } else if (gridStyle.equals(GraphTypes.GRID_LINES)) {
                retval = JGoGridView.GridLine;
            }
        }

        return retval;
    }

    public void setGridStyle(String gridStyle) {
        this.gridStyle = gridStyle;
    }

    public boolean hasTextWrap() {
        return wrapping;
    }

    public void setTextWrap(boolean wrapping) {
        this.wrapping = wrapping;
    }
}