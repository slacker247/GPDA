/*
 * The contents of this file are subject to the Mozilla Public License
 * Version 1.1 (the "License");  you may not use this file except in compliance
 * with the License.  You may obtain a copy of the License at
 * http://www.mozilla.org/MPL/
 *
 * Software distributed under the License is distributed on an "AS IS" basis,
 * WITHOUT WARRANTY OF ANY KIND, either express or implied. See the License for
 * the specific language governing rights and limitations under the License.
 *
 * The Original Code is Protege-2000.
 *
 * The Initial Developer of the Original Code is Stanford University. Portions
 * created by Stanford University are Copyright (C) 2001.  All Rights Reserved.
 *
 * Protege-2000 was developed by Stanford Medical Informatics
 * (http://www.smi.stanford.edu) at the Stanford University School of Medicine
 * with support from the National Library of Medicine, the National Science
 * Foundation, and the Defense Advanced Research Projects Agency.  Current
 * information about Protege can be obtained at http://protege.stanford.edu
 *
 * Contributor(s):
 */

package edu.stanford.smi.protegex.layout;

import java.awt.*;

/**
 *  Description of the class
 *
 * @author    William Grosso <grosso@smi.stanford.edu>
 */
public class NodeConstants {
    // icon shapes
    public final static String RECTANGLE = "Rectangle";
    public final static String ELLIPSE = "Ellipse";
    public final static String ROUNDED_RECTANGLE = "Rounded Rectangle";
    public final static String TRIANGLE_UP = "Triangle (pointing up)";
    public final static String TRIANGLE_DOWN = "Triangle (pointing down)";
    public final static String TRIANGLE_LEFT = "Triangle (pointing left)";
    public final static String TRIANGLE_RIGHT = "Triangle (pointing right)";
    public final static String HEXAGON = "Hexagon";
    public final static String DIAMOND = "Diamond";

    public final static String[] STYLE_NAMES = {RECTANGLE, ELLIPSE, ROUNDED_RECTANGLE, TRIANGLE_UP,
            TRIANGLE_DOWN, TRIANGLE_LEFT, TRIANGLE_RIGHT, HEXAGON, DIAMOND};

    public final static Color DEFAULT_NODE_COLOR = Color.green;
    public final static Color DEFAULT_TEXT_COLOR = Color.black;
    public final static String DEFAULT_NODE_STYLE = DIAMOND;
    public final static boolean NODES_DEFAULT_TO_FILLED = true;
    public final static boolean DEFAULT_DISPLAY_TEXT = true;
}
