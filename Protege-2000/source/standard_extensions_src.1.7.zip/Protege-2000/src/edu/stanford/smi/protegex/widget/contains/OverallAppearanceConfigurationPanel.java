/*
 * The contents of this file are subject to the Mozilla Public License
 * Version 1.1 (the "License");  you may not use this file except in compliance
 * with the License.  You may obtain a copy of the License at
 * http://www.mozilla.org/MPL/
 *
 * Software distributed under the License is distributed on an "AS IS" basis,
 * WITHOUT WARRANTY OF ANY KIND, either express or implied. See the License for
 * the specific language governing rights and limitations under the License.
 *
 * The Original Code is Protege-2000.
 *
 * The Initial Developer of the Original Code is Stanford University. Portions
 * created by Stanford University are Copyright (C) 2001.  All Rights Reserved.
 *
 * Protege-2000 was developed by Stanford Medical Informatics
 * (http://www.smi.stanford.edu) at the Stanford University School of Medicine
 * with support from the National Library of Medicine, the National Science
 * Foundation, and the Defense Advanced Research Projects Agency.  Current
 * information about Protege can be obtained at http://protege.stanford.edu
 *
 * Contributor(s):
 */

package edu.stanford.smi.protegex.widget.contains;

import java.awt.*;
import java.awt.event.*;
import javax.swing.*;
import javax.swing.event.*;
import java.util.*;
import edu.stanford.smi.protege.widget.*;
import edu.stanford.smi.protege.model.*;
import edu.stanford.smi.protege.ui.*;
import edu.stanford.smi.protege.util.*;
import edu.stanford.smi.protege.resource.*;

import edu.stanford.smi.protegex.util.*;

/**
 *  Description of the Class
 *
 * @author    William Grosso <grosso@smi.stanford.edu>
 */
public class OverallAppearanceConfigurationPanel extends AbstractWidgetConfigurationPanel {
    private ContainsWidgetState _containsWidgetState;
    private JCheckBox _subwidgetSelectionAllowed;
    private JCheckBox _putSeparatorBetweenSubwidgets;
    private JTextField _spaceBetweenWidgets;
    private JCheckBox _containInVerticalDirection;

    private class RowSelectionCheckboxListener implements ActionListener {
        public void actionPerformed(ActionEvent e) {
            ((ContainsWidgetState) _state).setSubwidgetSelectionAllowed(_subwidgetSelectionAllowed.isSelected());
        }
    }

    private class SubwidgetSeparatorListener implements ActionListener {
        public void actionPerformed(ActionEvent e) {
            ((ContainsWidgetState) _state).setSeparatorUsedBetweenSubwidgets(_putSeparatorBetweenSubwidgets.isSelected());
        }
    }

    private class ContainInVerticalDirection implements ActionListener {
        public void actionPerformed(ActionEvent e) {
            ((ContainsWidgetState) _state).setContainInVerticalDirection(_containInVerticalDirection.isSelected());
        }
    }

    private class SpacerSizeChangeListener extends DocumentChangedListener {
        public void stateChanged(ChangeEvent e) {
            Integer newValue = getTextFieldAsInteger();
            if (null != newValue) {
                _containsWidgetState.setSpaceBetweenSubwidgets(newValue.intValue());
            }
        }
    }

    public OverallAppearanceConfigurationPanel(ContainsWidgetState state) {
        super(state);
    }

    private void buildContainInVerticalDirection(int yPosition) {
        _containInVerticalDirection = createCheckBox("Stack subwidgets vertically", yPosition);
        _containInVerticalDirection.setSelected(_containsWidgetState.isContainInVerticalDirection());
        _containInVerticalDirection.addActionListener(new ContainInVerticalDirection());
    }

    protected void buildGUI() {
        _containsWidgetState = (ContainsWidgetState) _state;
        buildObjectsCanBeSelected(1);
        buildPutSeparatorBetweenSubwidgets(2);
        buildSpaceBetweenWidgets(3);
        buildContainInVerticalDirection(4);
        addVerticalSpace(5);
    }

    private void buildObjectsCanBeSelected(int yPosition) {
        _subwidgetSelectionAllowed = createCheckBox("Allow subordinate widgets to be selected", yPosition);
        _subwidgetSelectionAllowed.setSelected(_containsWidgetState.isSubwidgetSelectionAllowed());
        _subwidgetSelectionAllowed.addActionListener(new RowSelectionCheckboxListener());
    }

    private void buildPutSeparatorBetweenSubwidgets(int yPosition) {
        _putSeparatorBetweenSubwidgets = createCheckBox("Use separator between subwidgets", yPosition);
        _putSeparatorBetweenSubwidgets.setSelected(_containsWidgetState.isSeparatorUsedBetweenSubwidgets());
        _putSeparatorBetweenSubwidgets.addActionListener(new RowSelectionCheckboxListener());
    }

    private void buildSpaceBetweenWidgets(int yPosition) {
        _spaceBetweenWidgets = createTextfield("Space to put between subwidgets", yPosition);
        String integerValue = String.valueOf(_containsWidgetState.getSpaceBetweenSubwidgets());
        _spaceBetweenWidgets.setText(integerValue);
        (_spaceBetweenWidgets.getDocument()).addDocumentListener(new SpacerSizeChangeListener());
    }

    private Integer getTextFieldAsInteger() {
        String text = _spaceBetweenWidgets.getText();
        if ((null != text) && (false == text.equals(""))) {
            try {
                Integer intValue = new Integer(text);
                return intValue;
            } catch (Exception e) {
            }
        }
        return null;
    }
}
