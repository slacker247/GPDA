package protegex.prologtab;

import java.awt.*;
import javax.swing.*;
import javax.swing.event.*;
import java.awt.Rectangle;
import java.awt.event.*;
import java.util.*;
import java.io.*;
import edu.stanford.smi.protege.resource.Icons;
import edu.stanford.smi.protege.util.*;

/**
 * A basic question-and-answer dialog GUI.  This class is a Panel
 * containing input and output text areas for a Rete to use.  It uses
 * the TextReader and TextAreaWriter classes to turn textual data into
 * I/O streams.  The Console and ConsoleApplet classes both display an
 * instance of this.  (Changed the panel to support Swing. - Henrik
 * Eriksson)
 * (Modified for PrologTab by Troy Caldwell)
 * <P>
 * (C) 1998 E.J. Friedman-Hill and the Sandia Corporation
 * @author E.J. Friedman-Hill
 * @see JessTab
 */

public class JConsolePanel extends JPanel implements Serializable, PrologConsole
{
    private JTextAreaWriter _taw;
    protected PrintWriter _writer;

    private JTextField _textField;
    private TextReader _reader;

    private JButton _terminateButton;
    public JConsolePanel()
    {

        // Set up the GUI elements
        final JTextArea ta = new JTextArea(10, 40);
        ta.setEditable(false);
        ta.setLineWrap(true);
        ta.setWrapStyleWord(true);

        // Make it scrollable...
        JScrollPane scrollPane = new JScrollPane(ta,
                                 JScrollPane.VERTICAL_SCROLLBAR_AS_NEEDED,
                                 JScrollPane.HORIZONTAL_SCROLLBAR_NEVER);
        scrollPane.setBackground(Color.white);

        // Create the components...
        _textField = new JTextField(50);
        
        JButton clearButton = new JButton("Clear Window");
        clearButton.setToolTipText("Clears the Prolog console window");
        
        _terminateButton = new JButton("Terminate Query");
        _terminateButton.setToolTipText("Terminates the query");
        
        final JButton enterButton = new JButton("Enter");
        enterButton.setToolTipText("Sends an expression to the Prolog interpreter");
        
        final JButton upButton = new JButton(Icons.getUpIcon());
        upButton.setToolTipText("Move up the command history list");
        upButton.setPreferredSize(ComponentFactory.STANDARD_BUTTON_SIZE);
        
        final JButton downButton = new JButton(Icons.getDownIcon());
        downButton.setToolTipText("Move down the command history list");
        downButton.setPreferredSize(ComponentFactory.STANDARD_BUTTON_SIZE);

        // Set up I/O streams
        _taw = new JTextAreaWriter(ta, scrollPane);
        _reader = new TextReader();

        // Assemble the GUI
        setLayout(new BorderLayout());
        add(scrollPane, BorderLayout.CENTER);
        JPanel buttonPanel = new JPanel();
        buttonPanel.add(enterButton);
        buttonPanel.add(upButton);
        buttonPanel.add(downButton);
        buttonPanel.add(clearButton);
        buttonPanel.add(_terminateButton);
        JPanel p = new JPanel();
        p.setLayout(new BorderLayout());
        p.add(_textField, BorderLayout.CENTER);
        p.add(buttonPanel, BorderLayout.EAST);
        add(p, BorderLayout.SOUTH);

        final KeyListener key_action = new KeyAdapter() {
          public void keyPressed(KeyEvent e) {
            int delta = 1;
            switch (e.getKeyCode()) {
              case KeyEvent.VK_UP:
              case KeyEvent.VK_KP_UP:
                 delta = -1;
              case KeyEvent.VK_DOWN:
              case KeyEvent.VK_KP_DOWN:
                 _textField.setText(_reader.getHistory(delta));
                 setFocus();
                 break;
              case KeyEvent.VK_ENTER:
                 setFocus();
                 enterButton.doClick(50);
                 break;
              }
          }
        };
        _textField.addKeyListener(key_action);

        ActionListener enter_action = new ActionListener() {
                public void actionPerformed(ActionEvent ae)
                {
                    synchronized (ta)
                        {
                            try
                                {
                                    _taw.write(_textField.getText());
                                    _taw.write('\n');
                                    _taw.flush();
                                }
                            catch (IOException ioe)
                                {
                                    // Can't really happen
                                }


                            _reader.appendText(_textField.getText() + "\n");
                            _textField.setText("");
                            setFocus();
                        }

                }
            };

//        m_tf.addActionListener(enter_action);
        enterButton.addActionListener(enter_action);

        // Add listener for the up button...
        upButton.addActionListener(new ActionListener() {
                public void actionPerformed(ActionEvent ae) {
                  key_action.keyPressed(new KeyEvent(upButton, 0, 0, 0, KeyEvent.VK_UP));
                }
        });

        // Add listener for the down button...
        downButton.addActionListener(new ActionListener() {
                public void actionPerformed(ActionEvent ae) {
                  key_action.keyPressed(new KeyEvent(downButton, 0, 0, 0, KeyEvent.VK_DOWN));
                }
        });

        // Add listener for the clear button...
        clearButton.addActionListener(new ActionListener() {
                public void actionPerformed(ActionEvent ae) {
                    _taw.clear();
                    _textField.setText("");
                    setFocus();
                }
            });

       // Ensure we get the focus when the subtab is selected...
        addComponentListener(new ComponentAdapter() {
          public void componentShown(ComponentEvent e) { setFocus(); }
        });

        _writer = new PrintWriter(_taw, true);
        
    }
/**
 * Add actionListener to terminate button.
 * Creation date: (4/28/2002 5:16:34 PM)
 * @param listener java.awt.event.ActionListener
 */
public void addTerminateActionListener(ActionListener listener) {
	_terminateButton.addActionListener(listener);
}
/**
 * 
 * @return protegex.gnuprolog.TextReader
 */
public TextReader getReader() {
	return _reader;
}
/**
 * 
 * @return java.io.PrintWriter
 */
public java.io.PrintWriter getWriter() {
	return _writer;
}
/**
 * Scroll to end of text.
 * Creation date: (5/7/2002 12:14:33 PM)
 */
public void scrollToEnd() {
	_taw.scrollToEnd();
}
    /**
     * Move focus to the input area. Helps to call this whenever a button is clicked, etc.
     */

public void setFocus() {
	if(!_textField.isRequestFocusEnabled())
		_textField.setRequestFocusEnabled(true);
	_textField.requestFocus(); 
}
}
