/*
 * The contents of this file are subject to the Mozilla Public License
 * Version 1.1 (the "License");  you may not use this file except in compliance
 * with the License.  You may obtain a copy of the License at
 * http://www.mozilla.org/MPL/
 *
 * Software distributed under the License is distributed on an "AS IS" basis,
 * WITHOUT WARRANTY OF ANY KIND, either express or implied. See the License for
 * the specific language governing rights and limitations under the License.
 *
 * The Original Code is Protege-2000.
 *
 * The Initial Developer of the Original Code is Stanford University. Portions
 * created by Stanford University are Copyright (C) 2001.  All Rights Reserved.
 *
 * Protege-2000 was developed by Stanford Medical Informatics
 * (http://www.smi.stanford.edu) at the Stanford University School of Medicine
 * with support from the National Library of Medicine, the National Science
 * Foundation, and the Defense Advanced Research Projects Agency.  Current
 * information about Protege can be obtained at http://protege.stanford.edu
 *
 * Contributor(s):
 */

package edu.stanford.smi.protegex.layout;

import java.util.*;
import java.awt.*;

/**
 *  Description of the Class
 *
 * @author    William Grosso <grosso@smi.stanford.edu>
 */
public class AnimationContextSelectionHandler {
    private ArrayList _selectedActors;
    private AnimationContextSelectionBroadcaster _broadcaster;
    private AnimationContext _owner;
    private Rectangle _scratchRectangle;

    public AnimationContextSelectionHandler(AnimationContext owner) {
        _selectedActors = new ArrayList();
        _broadcaster = new AnimationContextSelectionBroadcaster();
        _scratchRectangle = new Rectangle();
        _owner = owner;
    }

    private void addActorToSelection(Actor actor) {
        _owner.moveActorToTop(actor);
        actor.setIsSelected(true);
        _selectedActors.add(actor);
    }

    public void addAnimationContextSelectionListener(AnimationContextSelectionListener newListener) {
        _broadcaster.addAnimationContextSelectionListener(newListener);
    }

    public Rectangle getActiveRectangle() {
        return getActiveRectangle(new Rectangle());
    }

    /*
         * minimal rectangle including all selected actors
         */
    public Rectangle getActiveRectangle(Rectangle returnValue) {
        Iterator i = _selectedActors.iterator();
        if (i.hasNext()) {
            Rectangle currentResult = new Rectangle();
            Actor firstActor = (Actor) i.next();
            firstActor.getLocation().getBounds(currentResult);
            while (i.hasNext()) {
                Actor nextActor = (Actor) i.next();
                nextActor.getLocation().getBounds(_scratchRectangle);
                currentResult = currentResult.union(_scratchRectangle);
            }
            returnValue.x = currentResult.x;
            returnValue.y = currentResult.y;
            returnValue.width = currentResult.width;
            returnValue.height = currentResult.height;
        } else {
            returnValue.x = 0;
            returnValue.y = 0;
            returnValue.width = 0;
            returnValue.height = 0;
        }
        return returnValue;
    }

    public Actor getLeadSelection() {
        int totalNumberOfActors = _selectedActors.size();
        if (0 == totalNumberOfActors) {
            return null;
        }
        Actor leadSelection = (Actor) _selectedActors.get(totalNumberOfActors - 1);
        return leadSelection;
    }

    public Collection getSelections() {
        return _selectedActors;
    }

    public boolean isActorSelected(Actor actor) {
        return _selectedActors.contains(actor);
    }

    public boolean isSingleSelection() {
        return (1 == _selectedActors.size());
    }

    private boolean removeActorFromSelection(Actor actor) {
        if (_selectedActors.remove(actor)) {
            actor.setIsSelected(false);
            return true;
        }
        return false;
    }

    private void removeAllCurrentSelections() {
        Iterator i = _selectedActors.iterator();
        while (i.hasNext()) {
            Actor nextActor = (Actor) i.next();
            nextActor.setIsSelected(false);
        }
        _selectedActors.clear();
    }

    public void removeAnimationContextSelectionListener(AnimationContextSelectionListener oldListener) {
        _broadcaster.removeAnimationContextSelectionListener(oldListener);
    }

    public void selectActor(Actor actor) {
        if ((null == actor) || (_selectedActors.contains(actor))) {
            return;
        }
        addActorToSelection(actor);
        _broadcaster.broadcastSelectionChange(null);
    }

    public void setSelectedActor(Actor actor) {
        if (null == actor) {
            if (0 == _selectedActors.size()) {
                return;
            }
            removeAllCurrentSelections();
            _broadcaster.broadcastSelectionChange(null);
            return;
        }
        if ((1 == _selectedActors.size()) && (actor.equals(_selectedActors.get(0)))) {
            return;
        }
        removeAllCurrentSelections();
        addActorToSelection(actor);
        _broadcaster.broadcastSelectionChange(null);
    }

    public void unselectActor(Actor actor) {
        if (removeActorFromSelection(actor)) {
            _broadcaster.broadcastSelectionChange(null);
        }
        return;
    }
}
