/*
 * The contents of this file are subject to the Mozilla Public License
 * Version 1.1 (the "License");  you may not use this file except in compliance
 * with the License.  You may obtain a copy of the License at
 * http://www.mozilla.org/MPL/
 *
 * Software distributed under the License is distributed on an "AS IS" basis,
 * WITHOUT WARRANTY OF ANY KIND, either express or implied. See the License for
 * the specific language governing rights and limitations under the License.
 *
 * The Original Code is Protege-2000.
 *
 * The Initial Developer of the Original Code is Stanford University. Portions
 * created by Stanford University are Copyright (C) 2001.  All Rights Reserved.
 *
 * Protege-2000 was developed by Stanford Medical Informatics
 * (http://www.smi.stanford.edu) at the Stanford University School of Medicine
 * with support from the National Library of Medicine, the National Science
 * Foundation, and the Defense Advanced Research Projects Agency.  Current
 * information about Protege can be obtained at http://protege.stanford.edu
 *
 * Contributor(s):
 */

package edu.stanford.smi.protegex.widget.instancetable;

import java.awt.*;
import java.awt.event.*;

import edu.stanford.smi.protegex.util.*;

/**
 *  Description of the Class
 *
 * @author    Ray Fergerson <fergerson@smi.stanford.edu>
 */
public class InstanceTableButtonsConfigurationPanel extends SixButtonsConfigurationPanel {
    private ButtonInformationPanel _moveInstancePanel;

    private class DisplayMoveButtonsListener implements ActionListener {
        public void actionPerformed(ActionEvent e) {
            _buttonRelatedWidgetState.setDisplayMoveInstanceButtons(_moveInstancePanel.isEnabled());
            _buttonRelatedWidgetState.setMoveInstanceButtonsTooltip(_moveInstancePanel.getTooltip());
        }
    }

    public InstanceTableButtonsConfigurationPanel(ButtonRelatedWidgetState state) {
        super(state);
        _mainPanel.setLayout(new GridLayout(7, 1, 0, 10));
    }

    protected void buildButtonSelectionPanel(int yPosition) {
        super.buildButtonSelectionPanel(yPosition);

        _moveInstancePanel =
            new ButtonInformationPanel(
                "Move Buttons",
                _buttonRelatedWidgetState.isDisplayMoveInstanceButtons(),
                _buttonRelatedWidgetState.getMoveInstanceTooltip());
        _moveInstancePanel.addActionListener(new DisplayMoveButtonsListener());

        _mainPanel.add(_moveInstancePanel);
    }
}
