/*
 * The contents of this file are subject to the Mozilla Public License
 * Version 1.1 (the "License");  you may not use this file except in compliance
 * with the License.  You may obtain a copy of the License at
 * http://www.mozilla.org/MPL/
 *
 * Software distributed under the License is distributed on an "AS IS" basis,
 * WITHOUT WARRANTY OF ANY KIND, either express or implied. See the License for
 * the specific language governing rights and limitations under the License.
 *
 * The Original Code is Protege-2000.
 *
 * The Initial Developer of the Original Code is Stanford University. Portions
 * created by Stanford University are Copyright (C) 2001.  All Rights Reserved.
 *
 * Protege-2000 was developed by Stanford Medical Informatics
 * (http://www.smi.stanford.edu) at the Stanford University School of Medicine
 * with support from the National Library of Medicine, the National Science
 * Foundation, and the Defense Advanced Research Projects Agency.  Current
 * information about Protege can be obtained at http://protege.stanford.edu
 *
 * Contributor(s):
 */

package edu.stanford.smi.protegex.widget.diagram;

import java.awt.Point;
import java.awt.Rectangle;
import java.util.*;
import edu.stanford.smi.protege.model.*;

import edu.stanford.smi.protegex.layout.*;

/**
 *  Static helper methods for the various bits and pieces of the diagrams
 *  package. Mostly dealing with editing the KB.
 *
 * @author    William Grosso <grosso@smi.stanford.edu>
 */
public class DiagramUtilities implements Constants {

    public static void addNewConnectorToNetwork(Instance networkInstance, Actor actor) {
        Instance actorInstance = ((ActorInstance) actor).getInstance();
        ActorLocation actorLocation = actor.getLocation();
        KnowledgeBase kb = networkInstance.getKnowledgeBase();

        Instance basePointInstance = kb.createInstance(null, kb.getCls(POINT_CLASS));
        Point basePoint = ((StandardWireActor) actor).getBeginningPoint();
        fillOutPointInstance(kb, basePointInstance, basePoint.x, basePoint.y);

        Instance endPointInstance = kb.createInstance(null, kb.getCls(POINT_CLASS));
        Point endPoint = ((StandardWireActor) actor).getEndingPoint();
        fillOutPointInstance(kb, endPointInstance, endPoint.x, endPoint.y);

        Slot connectorsSlot = kb.getSlot(CONNECTORS_SLOT);

        setLocation(kb, actorInstance, networkInstance, basePointInstance, endPointInstance);
        networkInstance.addOwnSlotValue(connectorsSlot, actorInstance);
    }

    public static void addNewNodeToNetwork(Instance networkInstance, Actor actor) {
        Instance actorInstance = ((ActorInstance) actor).getInstance();
        ActorLocation actorLocation = actor.getLocation();
        KnowledgeBase kb = networkInstance.getKnowledgeBase();

        Instance basePointInstance = kb.createInstance(null, kb.getCls(POINT_CLASS));
        fillOutPointInstance(kb, basePointInstance, actorLocation.getBaseX(), actorLocation.getBaseY());

        Instance endPointInstance = kb.createInstance(null, kb.getCls(POINT_CLASS));
        fillOutPointInstance(kb, endPointInstance, actorLocation.getExtensionX(), actorLocation.getExtensionY());

        Slot nodesSlot = getNodeSlot(networkInstance.getDirectType());

        setLocation(kb, actorInstance, networkInstance, basePointInstance, endPointInstance);
        networkInstance.addOwnSlotValue(nodesSlot, actorInstance);
        DiagramsAnimationContext diagramsAnimationContext = (DiagramsAnimationContext) actor.getAnimationContext();
        diagramsAnimationContext.selectInstance(actorInstance);
    }

    public static void bindAlongConnection(Instance connection) {
        KnowledgeBase kb = connection.getKnowledgeBase();
        Slot firstObjectSlot = kb.getSlot(FIRST_OBJECT_SLOT_NAME);
        Slot secondObjectSlot = kb.getSlot(SECOND_OBJECT_SLOT_NAME);
        Instance firstObject = (Instance) connection.getOwnSlotValue(firstObjectSlot);
        Instance secondObject = (Instance) connection.getOwnSlotValue(secondObjectSlot);
        if ((firstObject == null) || (secondObject == null)) {
            return;
        }
        Slot slotOnFirstObjectSlot = kb.getSlot(FIRST_OBJECT_SLOT_POINTER_NAME);
        Slot slotOnSecondObjectSlot = kb.getSlot(SECOND_OBJECT_SLOT_POINTER_NAME);
        Cls connectionType = connection.getDirectType();
        Slot slotOnFirstObject = (Slot) connectionType.getOwnSlotValue(slotOnFirstObjectSlot);
        Slot slotOnSecondObject = (Slot) connectionType.getOwnSlotValue(slotOnSecondObjectSlot);

        if (null != slotOnFirstObject) {
            firstObject.addOwnSlotValue(slotOnFirstObject, secondObject);
        }
        if (null != slotOnSecondObject) {
            secondObject.addOwnSlotValue(slotOnSecondObject, firstObject);
        }
        return;
    }

    public static void cleanupLayoutInformation(Instance underlyingNetworkInstance) {
        KnowledgeBase kb = underlyingNetworkInstance.getKnowledgeBase();
        Slot layoutInformationSlot = kb.getSlot(LAYOUT_INFORMATION_SLOT);
        Slot locationSlot = kb.getSlot(LOCATION_SLOT);
        Slot upperLeftCornerSlot = kb.getSlot(UPPER_LEFT_CORNER_SLOT);
        Slot lowerRightCornerSlot = kb.getSlot(LOWER_RIGHT_CORNER_SLOT);
        Slot objectSlot = kb.getSlot(OBJECT_SLOT);

        ArrayList copyOfSlotValues = new ArrayList(underlyingNetworkInstance.getOwnSlotValues(layoutInformationSlot));
        Iterator it = copyOfSlotValues.iterator();
        while (it.hasNext()) {

            Object nextObject = (Object) it.next();
            Instance objLocInstance = (Instance) nextObject;
            Object locationObject = objLocInstance.getOwnSlotValue(locationSlot);
            Instance locationInstance = (Instance) locationObject;
            Object objectObject = objLocInstance.getOwnSlotValue(objectSlot);
            Instance objectInstance = (Instance) objectObject;

            if ((null == objectInstance) || (null == locationInstance)) {
                kb.deleteInstance(objLocInstance);
            }
        }
    }

    public static Rectangle convertInstanceToRectangle(Instance instanceOfRectangle) {
        Point basePoint = readPoint(instanceOfRectangle, UPPER_LEFT_CORNER_SLOT, 0, 0);
        Point extPoint = readPoint(instanceOfRectangle, LOWER_RIGHT_CORNER_SLOT, DEFAULT_NODE_WIDTH, DEFAULT_NODE_HEIGHT);
        return new Rectangle(basePoint.x, basePoint.y, extPoint.x - basePoint.x, extPoint.y - basePoint.y);
    }

    private static void fillOutPointInstance(KnowledgeBase kb, Instance pointInstance, int x, int y) {
        Slot xSlot = kb.getSlot(POINT_X_SLOT);
        Slot ySlot = kb.getSlot(POINT_Y_SLOT);
        Integer xval = null;
        Integer yval = null;

        xval = new Integer(x);
        yval = new Integer(y);

        pointInstance.setOwnSlotValue(xSlot, xval);
        pointInstance.setOwnSlotValue(ySlot, yval);
        return;
    }

    public static Instance getFirstObject(Instance connector) {
        KnowledgeBase kb = connector.getKnowledgeBase();
        Slot firstObjectSlot = kb.getSlot(FIRST_OBJECT_SLOT_NAME);
        return (Instance) connector.getOwnSlotValue(firstObjectSlot);
    }

    public static Instance getInstanceRectangleForObject(Instance object, Instance networkInstance) {
        return getLocationRectangleForObject(object.getKnowledgeBase(), object, networkInstance);
    }

    public static Rectangle getLocationRectangleForObject(Instance object, Instance networkInstance) {
        return convertInstanceToRectangle(getInstanceRectangleForObject(object, networkInstance));
    }

    private static Instance getLocationRectangleForObject(KnowledgeBase kb, Instance object, Instance networkInstance) {
        Slot layoutInformationSlot = kb.getSlot(LAYOUT_INFORMATION_SLOT);
        Slot locationSlot = kb.getSlot(LOCATION_SLOT);
        Slot objectSlot = kb.getSlot(OBJECT_SLOT);
        Collection candidateInstances = networkInstance.getOwnSlotValues(layoutInformationSlot);
        Iterator i = candidateInstances.iterator();
        while (i.hasNext()) {
            Instance instanceOfLayoutInformation = (Instance) i.next();
            if (object == instanceOfLayoutInformation.getOwnSlotValue(objectSlot)) {
                return (Instance) instanceOfLayoutInformation.getOwnSlotValue(locationSlot);
            }
        }
        Instance rectInstance = kb.createInstance(null, kb.getCls(RECTANGLE_CLASS));
        Slot upperLeftSlot = kb.getSlot(UPPER_LEFT_CORNER_SLOT);
        Instance upperLeftCorner = kb.createInstance(null, kb.getCls(POINT_CLASS));
        fillOutPointInstance(kb, upperLeftCorner, 0, 0);

        Instance lowerRightCorner = kb.createInstance(null, kb.getCls(POINT_CLASS));
        fillOutPointInstance(kb, lowerRightCorner, DEFAULT_NODE_WIDTH, DEFAULT_NODE_HEIGHT);
        Slot lowerRightSlot = kb.getSlot(LOWER_RIGHT_CORNER_SLOT);

        rectInstance.setOwnSlotValue(upperLeftSlot, upperLeftCorner);
        rectInstance.setOwnSlotValue(lowerRightSlot, lowerRightCorner);

        Instance objectLocation = kb.createInstance(null, kb.getCls(OBJECT_LOCATION_CLASS));
        objectLocation.setOwnSlotValue(objectSlot, object);
        objectLocation.setOwnSlotValue(locationSlot, rectInstance);
        networkInstance.addOwnSlotValue(layoutInformationSlot, objectLocation);
        return rectInstance;
    }

    public static Slot getNodeSlot(Cls networkCls) {
        KnowledgeBase kb = networkCls.getKnowledgeBase();
        Slot nodeSlot = (Slot) networkCls.getOwnSlotValue(kb.getSlot(NODE_SLOT));
        return nodeSlot;
    }

    public static Instance getSecondObject(Instance connector) {
        KnowledgeBase kb = connector.getKnowledgeBase();
        Slot secondObjectSlot = kb.getSlot(SECOND_OBJECT_SLOT_NAME);
        return (Instance) connector.getOwnSlotValue(secondObjectSlot);
    }

    private static Point readPoint(Instance rectInstance, String slot, int defaultX, int defaultY) {
        Instance tmpInstance = (Instance) ModelUtilities.getOwnSlotValue(rectInstance, slot);
        int xValue;
        int yValue;
        Integer x = null;
        Integer y = null;
        if (null != tmpInstance) {
            x = (Integer) ModelUtilities.getOwnSlotValue(tmpInstance, POINT_X_SLOT);
            y = (Integer) ModelUtilities.getOwnSlotValue(tmpInstance, POINT_Y_SLOT);
        }
        if (null != x) {
            xValue = x.intValue();
        } else {
            xValue = defaultX;
        }
        if (null != y) {
            yValue = y.intValue();
        } else {
            yValue = defaultY;
        }
        return new Point(xValue, yValue);
    }

    public static void removeConnector(Instance networkInstance, Instance connector) {
        unbindAlongConnection(connector);
        KnowledgeBase kb = connector.getKnowledgeBase();
        Slot connectorsSlot = kb.getSlot(CONNECTORS_SLOT);
        networkInstance.removeOwnSlotValue(connectorsSlot, connector);
        removeLayoutInformation(networkInstance, connector);
    }

    public static void removeLayoutInformation(Instance underlyingNetworkInstance, Instance object) {
        KnowledgeBase kb = object.getKnowledgeBase();
        Slot layoutInformationSlot = kb.getSlot(LAYOUT_INFORMATION_SLOT);
        Slot locationSlot = kb.getSlot(LOCATION_SLOT);
        Slot upperLeftCornerSlot = kb.getSlot(UPPER_LEFT_CORNER_SLOT);
        Slot lowerRightCornerSlot = kb.getSlot(LOWER_RIGHT_CORNER_SLOT);
        Slot objectSlot = kb.getSlot(OBJECT_SLOT);

        Collection c = underlyingNetworkInstance.getOwnSlotValues(layoutInformationSlot);
        Iterator it = c.iterator();
        while (it.hasNext()) {
            Instance objLocInstance = (Instance) it.next();
            Instance locationInstance = (Instance) objLocInstance.getOwnSlotValue(locationSlot);
            Instance objectInstance = (Instance) objLocInstance.getOwnSlotValue(objectSlot);

            if ((null != objectInstance) && (objectInstance.equals(object))) {
                Instance leftPointInstance = (Instance) locationInstance.getOwnSlotValue(upperLeftCornerSlot);
                Instance rightPointInstance = (Instance) locationInstance.getOwnSlotValue(lowerRightCornerSlot);

                kb.deleteInstance(leftPointInstance);
                kb.deleteInstance(rightPointInstance);
                kb.deleteInstance(locationInstance);
                kb.deleteInstance(objLocInstance);
                break;
            }
        }
    }

    public static void removeNode(Instance networkInstance, Instance node) {
        Slot nodeSlot = getNodeSlot(networkInstance.getDirectType());
        networkInstance.removeOwnSlotValue(nodeSlot, node);
        removeLayoutInformation(networkInstance, node);
    }

    public static void setLocation(
        KnowledgeBase kb,
        Instance actorInstance,
        Instance networkInstance,
        Instance basePointInstance,
        Instance endPointInstance) {
        Slot upperLeftSlot = kb.getSlot(UPPER_LEFT_CORNER_SLOT);
        Slot lowerRightSlot = kb.getSlot(LOWER_RIGHT_CORNER_SLOT);

        Instance rectangleInstance = kb.createInstance(null, kb.getCls(RECTANGLE_CLASS));
        rectangleInstance.setOwnSlotValue(upperLeftSlot, basePointInstance);
        rectangleInstance.setOwnSlotValue(lowerRightSlot, endPointInstance);

        Slot locationSlot = kb.getSlot(LOCATION_SLOT);
        Slot objectSlot = kb.getSlot(OBJECT_SLOT);

        Instance locationInstance = kb.createInstance(null, kb.getCls(OBJECT_LOCATION_CLASS));
        locationInstance.setOwnSlotValue(locationSlot, rectangleInstance);
        locationInstance.setOwnSlotValue(objectSlot, actorInstance);

        Slot layoutInformationSlot = kb.getSlot(LAYOUT_INFORMATION_SLOT);
        networkInstance.addOwnSlotValue(layoutInformationSlot, locationInstance);
    }

    public static void unbindAlongConnection(Instance connection) {
        KnowledgeBase kb = connection.getKnowledgeBase();
        Slot firstObjectSlot = kb.getSlot(FIRST_OBJECT_SLOT_NAME);
        Slot secondObjectSlot = kb.getSlot(SECOND_OBJECT_SLOT_NAME);

        Instance firstObject = (Instance) connection.getOwnSlotValue(firstObjectSlot);
        Instance secondObject = (Instance) connection.getOwnSlotValue(secondObjectSlot);
        if (null != firstObject) {
            connection.removeOwnSlotValue(firstObjectSlot, firstObject);
            // connection.setOwnSlotValue(firstObjectSlot, null);
        }
        if (null != secondObject) {
            connection.removeOwnSlotValue(secondObjectSlot, secondObject);
            // connection.setOwnSlotValue(secondObjectSlot, null);
        }

        if ((firstObject == null) || (secondObject == null)) {
            return;
        }
        Slot slotOnFirstObjectSlot = kb.getSlot(FIRST_OBJECT_SLOT_POINTER_NAME);
        Slot slotOnSecondObjectSlot = kb.getSlot(SECOND_OBJECT_SLOT_POINTER_NAME);
        Cls connectionType = connection.getDirectType();
        Slot slotOnFirstObject = (Slot) connectionType.getOwnSlotValue(slotOnFirstObjectSlot);
        Slot slotOnSecondObject = (Slot) connectionType.getOwnSlotValue(slotOnSecondObjectSlot);

        if (null != slotOnFirstObject) {
            firstObject.removeOwnSlotValue(slotOnFirstObject, secondObject);
        }
        if (null != slotOnSecondObject) {
            secondObject.removeOwnSlotValue(slotOnSecondObject, firstObject);
        }
        return;
    }

    public static void updateConnectorLocation(Instance networkInstance, Actor actor) {
        Instance actorInstance = ((ActorInstance) actor).getInstance();
        KnowledgeBase kb = networkInstance.getKnowledgeBase();
        Instance locationRectangle = getLocationRectangleForObject(kb, actorInstance, networkInstance);

        Slot upperLeftSlot = kb.getSlot(UPPER_LEFT_CORNER_SLOT);
        Instance upperLeftPointInstance = (Instance) locationRectangle.getOwnSlotValue(upperLeftSlot);
        Point upperLeftPoint = ((StandardWireActor) actor).getBeginningPoint();
        fillOutPointInstance(kb, upperLeftPointInstance, upperLeftPoint.x, upperLeftPoint.y);

        Slot lowerRightSlot = kb.getSlot(LOWER_RIGHT_CORNER_SLOT);
        Instance lowerRightPointInstance = (Instance) locationRectangle.getOwnSlotValue(lowerRightSlot);
        Point lowerRightPoint = ((StandardWireActor) actor).getEndingPoint();
        fillOutPointInstance(kb, lowerRightPointInstance, lowerRightPoint.x, lowerRightPoint.y);
    }

    public static void updateNodeLocation(Instance networkInstance, Actor actor) {
        Instance actorInstance = ((ActorInstance) actor).getInstance();
        KnowledgeBase kb = networkInstance.getKnowledgeBase();
        Instance locationRectangle = getLocationRectangleForObject(kb, actorInstance, networkInstance);

        ActorLocation location = actor.getLocation();

        Slot upperLeftSlot = kb.getSlot(UPPER_LEFT_CORNER_SLOT);
        Instance upperLeftPointInstance = (Instance) locationRectangle.getOwnSlotValue(upperLeftSlot);
        fillOutPointInstance(kb, upperLeftPointInstance, location.getBaseX(), location.getBaseY());

        Slot lowerRightSlot = kb.getSlot(LOWER_RIGHT_CORNER_SLOT);
        Instance lowerRightPointInstance = (Instance) locationRectangle.getOwnSlotValue(lowerRightSlot);
        fillOutPointInstance(kb, lowerRightPointInstance, location.getExtensionX(), location.getExtensionY());
    }
}
