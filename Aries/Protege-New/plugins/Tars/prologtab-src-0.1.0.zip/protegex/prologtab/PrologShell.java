package protegex.prologtab;

import java.util.*;
import java.io.*;
import edu.stanford.smi.protege.model.*;
/**
 * Manage the shell context.
 * Creation date: (4/28/2002 4:14:31 PM)
 * @author: 
 */
public abstract class PrologShell implements IdleHandler {
	protected PrologConsole _console;
    protected PrintWriter _writer;
    protected TextReader _reader;

    protected PrologTab _tab;

    protected PrologEngine _engine;
    protected TripleDBAdapter _adapter;

    protected java.util.List consultRequests = new ArrayList();
    
    // Thread in which the parse loop runs
    protected Thread _thread;

    public static final String QUERY_PROMPT = "?-";
    public static final String SUCCESS_PROMPT = "SUCCESS. redo (y/n/a)?";

/**
 * PrologShell constructor comment.
 */
public PrologShell(PrologConsole console, PrologTab tab) {
	super();
	_console = console;
	_reader = _console.getReader();
	_reader.setIdleHandler(this);
	_writer = _console.getWriter();
	_tab = tab;
	_engine = createPrologEngine();
	_adapter = new TripleDBAdapterImpl(_tab.getKnowledgeBase(),_engine);
	_adapter.copyKnowledgeBase();
	PrologTabSystemClasses.setPrologBuiltins(_tab.getKnowledgeBase(),_engine.getBuiltIns());
}
/**
 * Insert the method's description here.
 * Creation date: (4/28/2002 4:19:36 PM)
 */
public void close() {
	_adapter.release();
}
/**
 * Load PrologEngine from InputStream created by concatenateing PrologCodeModules.
 * Creation date: (4/16/2002 11:32:57 AM)
 * @param module edu.stanford.smi.protege.model.Instance
 */
protected void consult(Instance module) {
	_console.setFocus();
	InputStream inputStream = PrologTabSystemClasses.getCodeModuleInputStream(module);
	String moduleName = PrologTabSystemClasses.getCodeModuleName(module);
	try {
		_writer.print("Consulting module: " + moduleName + "...");
		_writer.flush();
		_engine.loadFrom(moduleName,inputStream);
		_adapter.copyKnowledgeBase();
		_writer.println("Done");
		_writer.flush();
	} catch (IOException e) {
		e.printStackTrace(_writer);
	}
}
/**
 * Create the specific PrologEngine instance.
 * Creation date: (5/3/2002 10:09:05 AM)
 * @return protegex.prologtab.PrologEngine
 */
public abstract PrologEngine createPrologEngine();
/**
 * Insert the method's description here.
 * Creation date: (4/11/2002 6:39:21 PM)
 */
protected void executeShell() {
	_writer.print(QUERY_PROMPT);
	_writer.flush();
	_console.scrollToEnd();
	try {
		_reader.startHistory();
		PrologGoal goal = _engine.readGoal(_reader);
		_reader.addHistory();
		String response;
		int rc;
		LineNumberReader kin = new LineNumberReader(_reader);
		loop: do {
			long startTime = System.currentTimeMillis();
			rc = goal.evaluate();
			long stopTime = System.currentTimeMillis();
			_writer.println("time = "+(stopTime-startTime)+"ms");
			response = "n";
			switch (rc) {
				case PrologGoal.SUCCESS: {
					goal.printResults(_writer);
					_writer.print(SUCCESS_PROMPT);
					_writer.flush();
					_console.scrollToEnd();
					response = kin.readLine();
 
					if (response.equals("a")) {
						goal.restart();
					}
 
					if (response.equals("n")) {
						goal.stop();
						return;
					}
					break;
				}
				case PrologGoal.SUCCESS_LAST: {
					goal.printResults(_writer);
					_writer.println("SUCCESS LAST");
					_writer.flush();
					return;
				}
				case PrologGoal.FAIL: {
					_writer.println("FAIL");
					_writer.flush();
       				return;
				}
			}
		} while (true);
	} catch (PrologTabException pte) {
		_writer.println(pte.getWrappedException().getMessage());
		pte.getWrappedException().printStackTrace(_writer);
	} catch (Exception e) {
		_writer.println("Unexpected exception:");
		e.printStackTrace(_writer);
	} finally {
		_writer.flush();                
	}
}
/**
 * Handle a request to consult a prolog code module.
 * Creation date: (4/26/2002 2:40:58 PM)
 */
protected void handleConsultRequest() {
	Instance consultRequest = null;
	synchronized (consultRequests) {
		if (!consultRequests.isEmpty())
			consultRequest = (Instance) consultRequests.remove(consultRequests.size() - 1);
	}
	if (consultRequest != null)
		consult(consultRequest);
}
/**
 * Implement the IdleHandler interface. Called when the TextReader loop is idle.
 * Creation date: (4/26/2002 2:40:58 PM)
 */
public void idle() {
	handleConsultRequest();
}
/**
 * Insert the method's description here.
 * Creation date: (4/26/2002 2:46:32 PM)
 * @param module edu.stanford.smi.protege.model.Instance
 */
public void requestConsult(Instance module) {
	synchronized (consultRequests) {
		consultRequests.add(0,module);
	}
}
/**
 * Not pretty, but all we can do without major changes to GNU Prolog for Java.
 * Creation date: (4/28/2002 5:20:13 PM)
 */
public void restart() {
	if (_thread != null) {
		_thread.stop();
		_thread = null;
	};
	start();
}
/**
 * Insert the method's description here.
 * Creation date: (4/28/2002 4:30:21 PM)
 */
public void start() {
	_thread = new Thread() {
		public void run() {
			do {
				try {
					_console.setFocus();
					while (true) {
						executeShell();
					}
				}  catch (Throwable t) {
					_thread = null;
				}
			} while (_thread != null);
		}
	};
	_thread.start();
}
}
