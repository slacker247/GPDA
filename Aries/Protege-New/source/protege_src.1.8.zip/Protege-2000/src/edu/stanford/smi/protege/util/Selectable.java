/*
 * The contents of this file are subject to the Mozilla Public License
 * Version 1.1 (the "License");  you may not use this file except in compliance
 * with the License.  You may obtain a copy of the License at
 * http://www.mozilla.org/MPL/
 *
 * Software distributed under the License is distributed on an "AS IS" basis,
 * WITHOUT WARRANTY OF ANY KIND, either express or implied. See the License for
 * the specific language governing rights and limitations under the License.
 *
 * The Original Code is Protege-2000.
 *
 * The Initial Developer of the Original Code is Stanford University. Portions
 * created by Stanford University are Copyright (C) 2001.  All Rights Reserved.
 *
 * Protege-2000 was developed by Stanford Medical Informatics
 * (http://www.smi.stanford.edu) at the Stanford University School of Medicine
 * with support from the National Library of Medicine, the National Science
 * Foundation, and the Defense Advanced Research Projects Agency.  Current
 * information about Protege can be obtained at http://protege.stanford.edu
 *
 * Contributor(s):
 */

package edu.stanford.smi.protege.util;

import java.util.*;

/**
 * A generic interface for things that are selectable.  Often (always?) in this app listeners don't really care if they
 * are listening to a List or a Table or a Tree.  They just want to find out when the selection changes and to be able
 * to find out what the current selection list.  This interface allows listeners to do this.  There are a variety of
 * adapters available that turn component specific selection events into Selectable events.  There are also Selectable
 * versions of all of the standard components.
 *
 * @author Ray Fergerson <fergerson@smi.stanford.edu>
 */
public interface Selectable {

    void addSelectionListener(SelectionListener listener);

    void clearSelection();

    Collection getSelection();

    void notifySelectionListeners();

    void removeSelectionListener(SelectionListener listener);
}
