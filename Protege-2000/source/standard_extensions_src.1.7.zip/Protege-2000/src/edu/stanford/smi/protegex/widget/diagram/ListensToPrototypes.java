/*
 * The contents of this file are subject to the Mozilla Public License
 * Version 1.1 (the "License");  you may not use this file except in compliance
 * with the License.  You may obtain a copy of the License at
 * http://www.mozilla.org/MPL/
 *
 * Software distributed under the License is distributed on an "AS IS" basis,
 * WITHOUT WARRANTY OF ANY KIND, either express or implied. See the License for
 * the specific language governing rights and limitations under the License.
 *
 * The Original Code is Protege-2000.
 *
 * The Initial Developer of the Original Code is Stanford University. Portions
 * created by Stanford University are Copyright (C) 2001.  All Rights Reserved.
 *
 * Protege-2000 was developed by Stanford Medical Informatics
 * (http://www.smi.stanford.edu) at the Stanford University School of Medicine
 * with support from the National Library of Medicine, the National Science
 * Foundation, and the Defense Advanced Research Projects Agency.  Current
 * information about Protege can be obtained at http://protege.stanford.edu
 *
 * Contributor(s):
 */

package edu.stanford.smi.protegex.widget.diagram;

import edu.stanford.smi.protegex.layout.*;

import java.awt.event.*;
import java.awt.*;
import edu.stanford.smi.protege.model.*;
import edu.stanford.smi.protege.widget.*;
import edu.stanford.smi.protege.ui.*;
import edu.stanford.smi.protege.util.*;

/**
 *  Description of the Class
 *
 * @author    William Grosso <grosso@smi.stanford.edu>
 */
public abstract class ListensToPrototypes extends ActorAdapter {
    protected Actor _actor;
    protected AnimationContext _startingFrame;
    protected AnimationContext _overlayFrame;
    protected AnimationContext _destinationFrame;
    protected AnimationContext _rightFrame;
    protected AnimationContext _leftFrame;
    protected boolean _actorSelected;
    protected OuterPanel _outerPanel;
    protected Cls _actorClass;
    protected KnowledgeBase _kb;
    protected DiagramWidget _widget;

    public ListensToPrototypes(
        Actor actor,
        DiagramWidget widget,
        KnowledgeBase kb,
        Cls actorClass,
        AnimationContext startingFrame,
        AnimationContext destinationFrame,
        AnimationContext overlayFrame,
        AnimationContext rightFrame,
        AnimationContext leftFrame,
        OuterPanel outerPanel) {
        _actor = actor;
        _widget = widget;
        _kb = kb;
        _actorClass = actorClass;
        _actor.addActorListener(this);
        _startingFrame = startingFrame;
        _destinationFrame = destinationFrame;
        _overlayFrame = overlayFrame;
        _rightFrame = rightFrame;
        _leftFrame = leftFrame;
        _outerPanel = outerPanel;
    }

    public void actorSelected(ActorEvent e) {
        replicateActor();
    }

    protected abstract void createDraggingListener(Actor actor);

    protected void replicateActor() {
        Actor newActor = (Actor) _actor.copy();
        newActor.setTitle("");

        newActor.setCoordinateSystem(_overlayFrame.getCoordinateSystem());
        _startingFrame.setSelectedActor(null);

        createDraggingListener(newActor);
        _outerPanel.translateActorIntoOverlayFromPalette(newActor);
        _overlayFrame.setVisibleToEvents(true);
        _overlayFrame.addActorToTop(newActor);
        _overlayFrame.setSelectedActor(newActor);
        _destinationFrame.setVisibleToEvents(false);
        _startingFrame.setVisibleToEvents(false);
    }
}
