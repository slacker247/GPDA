/*
 * The contents of this file are subject to the Mozilla Public License
 * Version 1.1 (the "License");  you may not use this file except in compliance
 * with the License.  You may obtain a copy of the License at
 * http://www.mozilla.org/MPL/
 *
 * Software distributed under the License is distributed on an "AS IS" basis,
 * WITHOUT WARRANTY OF ANY KIND, either express or implied. See the License for
 * the specific language governing rights and limitations under the License.
 *
 * The Original Code is Protege-2000.
 *
 * The Initial Developer of the Original Code is Stanford University. Portions
 * created by Stanford University are Copyright (C) 2001.  All Rights Reserved.
 *
 * Protege-2000 was developed by Stanford Medical Informatics
 * (http://www.smi.stanford.edu) at the Stanford University School of Medicine
 * with support from the National Library of Medicine, the National Science
 * Foundation, and the Defense Advanced Research Projects Agency.  Current
 * information about Protege can be obtained at http://protege.stanford.edu
 *
 * Contributor(s):
 */

package edu.stanford.smi.protegex.widget.contains;

import java.awt.*;
import java.awt.event.*;
import javax.swing.*;
import javax.swing.event.*;
import java.util.*;

import edu.stanford.smi.protege.widget.*;
import edu.stanford.smi.protege.model.*;
import edu.stanford.smi.protege.ui.*;
import edu.stanford.smi.protege.util.*;
import edu.stanford.smi.protege.resource.*;

import edu.stanford.smi.protegex.util.*;

/**
 *  Description of the Class
 *
 * @author    William Grosso <grosso@smi.stanford.edu>
 */
public class PrototypingAndCreationConfigurationPanel extends AbstractWidgetConfigurationPanel {
    private ContainsWidgetState _containsWidgetState;
    private JCheckBox _displayNewInstanceForms;
    private JCheckBox _selectNewInsertions;
    private JCheckBox _insertAtCurrentSelection;

    private class DisplayNewInstanceFormsCheckBoxListener implements ActionListener {
        public void actionPerformed(ActionEvent e) {
            _containsWidgetState.setCreateFormForNewInstances(_displayNewInstanceForms.isSelected());
        }
    }

    private class NewlyInsertedObjectsAreSelectedCheckBoxListener implements ActionListener {
        public void actionPerformed(ActionEvent e) {
            _containsWidgetState.setSelectNewInsertions(_selectNewInsertions.isSelected());
        }
    }

    private class InsertAtCurrentSelectionPointCheckBoxListener implements ActionListener {
        public void actionPerformed(ActionEvent e) {
            _containsWidgetState.setInsertAtCurrentSelection(_insertAtCurrentSelection.isSelected());
        }
    }

    private class PrototypeButton implements ActionListener {
        private int _depth;

        private PrototypeButton(int depth) {
            _depth = depth;
        }

        public void actionPerformed(ActionEvent e) {
            JRadioButton caller = (JRadioButton) e.getSource();
            if (caller.isSelected()) {
                _containsWidgetState.setPrototypeDepth(_depth);
            }
        }
    }

    public PrototypingAndCreationConfigurationPanel(ContainsWidgetState state) {
        super(state);
    }

    private void addRadioButton(ButtonGroup buttonGroup, JPanel panel, String description, int depth) {
        int prototypeDepth = _containsWidgetState.getPrototypeDepth();
        JRadioButton newButton = new JRadioButton(description);
        newButton.addActionListener(new PrototypeButton(depth));
        panel.add(newButton);
        buttonGroup.add(newButton);
        if (depth == prototypeDepth) {
            newButton.setSelected(true);
        }
    }

    private void buildDisplayNewInstanceFormsCheckbox(int yPosition) {
        _displayNewInstanceForms = createCheckBox("Display forms for newly created instances", yPosition);
        _displayNewInstanceForms.setSelected(_containsWidgetState.isCreateFormForNewInstances());
        _displayNewInstanceForms.addActionListener(new DisplayNewInstanceFormsCheckBoxListener());
    }

    protected void buildGUI() {
        _containsWidgetState = (ContainsWidgetState) _state;
        buildDisplayNewInstanceFormsCheckbox(1);
        buildNewlyInsertedObjectsAreSelected(2);
        buildInsertAtCurrentSelectionPoint(3);
        buildPrototypeDepthRadioButton(4);
        addVerticalSpace(5);
    }

    private void buildInsertAtCurrentSelectionPoint(int yPosition) {
        _insertAtCurrentSelection = createCheckBox("Insert at point of current selection", yPosition);
        _insertAtCurrentSelection.setSelected(_containsWidgetState.isInsertAtCurrentSelection());
        _insertAtCurrentSelection.addActionListener(new InsertAtCurrentSelectionPointCheckBoxListener());
    }

    private void buildNewlyInsertedObjectsAreSelected(int yPosition) {
        _selectNewInsertions = createCheckBox("Newly inserted instances are selected", yPosition);
        _selectNewInsertions.setSelected(_containsWidgetState.isSelectNewInsertions());
        _selectNewInsertions.addActionListener(new NewlyInsertedObjectsAreSelectedCheckBoxListener());
    }

    private void buildPrototypeDepthRadioButton(int yPosition) {
        JPanel buttonPanel = new JPanel(new GridLayout(3, 1));
        ButtonGroup buttonGroup = new ButtonGroup();
        addRadioButton(buttonGroup, buttonPanel, "Shallow Copy", 0);
        addRadioButton(buttonGroup, buttonPanel, "Depth 1 Copy", 1);
        addRadioButton(buttonGroup, buttonPanel, "Deep Copy", -1);
        buttonPanel.setBorder(BorderFactory.createEtchedBorder());
        LabeledComponent componentToAdd = new LabeledComponent("Prototype Depth", buttonPanel);
        add(componentToAdd, buildComponentGridBagConstraints(yPosition));
    }
}
