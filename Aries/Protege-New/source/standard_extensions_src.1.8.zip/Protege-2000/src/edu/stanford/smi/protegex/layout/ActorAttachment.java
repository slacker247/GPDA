/*
 * The contents of this file are subject to the Mozilla Public License
 * Version 1.1 (the "License");  you may not use this file except in compliance
 * with the License.  You may obtain a copy of the License at
 * http://www.mozilla.org/MPL/
 *
 * Software distributed under the License is distributed on an "AS IS" basis,
 * WITHOUT WARRANTY OF ANY KIND, either express or implied. See the License for
 * the specific language governing rights and limitations under the License.
 *
 * The Original Code is Protege-2000.
 *
 * The Initial Developer of the Original Code is Stanford University. Portions
 * created by Stanford University are Copyright (C) 2001.  All Rights Reserved.
 *
 * Protege-2000 was developed by Stanford Medical Informatics
 * (http://www.smi.stanford.edu) at the Stanford University School of Medicine
 * with support from the National Library of Medicine, the National Science
 * Foundation, and the Defense Advanced Research Projects Agency.  Current
 * information about Protege can be obtained at http://protege.stanford.edu
 *
 * Contributor(s):
 */

package edu.stanford.smi.protegex.layout;

import java.awt.*;

/**
 *  Attachment between two node actors. This connects a control point on each
 *  actor. This is not used anywhere.
 *
 * @author    William Grosso <grosso@smi.stanford.edu>
 */
public class ActorAttachment {
    private Actor _actor;
    // secondary actor
    private int _controlPointOnTarget;
    private int _controlPointOnAttacher;

    public ActorAttachment(Actor actor, int controlPointOnAttacher, int controlPointOnTarget) {
        _controlPointOnAttacher = controlPointOnAttacher;
        _controlPointOnTarget = controlPointOnTarget;
        _actor = actor;
    }

    public boolean equals(Object object) {
        if (object instanceof ActorAttachment) {
            ActorAttachment cp = (ActorAttachment) object;
            if (_controlPointOnTarget == cp.getControlPointOnTarget()) {
                if (_controlPointOnAttacher == cp.getControlPointOnAttacher()) {
                    return (_actor == cp.getActor());
                }
            }
        }
        return false;
    }

    public Actor getActor() {
        return _actor;
    }

    public int getControlPointOnAttacher() {
        return _controlPointOnAttacher;
    }

    public int getControlPointOnTarget() {
        return _controlPointOnTarget;
    }

    public void getPointOnTarget(Point returnValue) {
        _actor.getControlPoint(_controlPointOnTarget, returnValue);
        return;
    }

    public int hashCode() {
        return _actor.hashCode() + _controlPointOnTarget * 32 + _controlPointOnAttacher;
    }
}
