/*
 * The contents of this file are subject to the Mozilla Public License
 * Version 1.1 (the "License");  you may not use this file except in compliance
 * with the License.  You may obtain a copy of the License at
 * http://www.mozilla.org/MPL/
 *
 * Software distributed under the License is distributed on an "AS IS" basis,
 * WITHOUT WARRANTY OF ANY KIND, either express or implied. See the License for
 * the specific language governing rights and limitations under the License.
 *
 * The Original Code is Protege-2000.
 *
 * The Initial Developer of the Original Code is Stanford University. Portions
 * created by Stanford University are Copyright (C) 2001.  All Rights Reserved.
 *
 * Protege-2000 was developed by Stanford Medical Informatics
 * (http://www.smi.stanford.edu) at the Stanford University School of Medicine
 * with support from the National Library of Medicine, the National Science
 * Foundation, and the Defense Advanced Research Projects Agency.  Current
 * information about Protege can be obtained at http://protege.stanford.edu
 *
 * Contributor(s):
 */

package edu.stanford.smi.protegex.layout;

import java.awt.*;
import java.awt.geom.*;

/**
 *  Description of the class
 *
 * @author    William Grosso <grosso@smi.stanford.edu>
 */
public class Ellipse extends AbstractShape {
    public final static int SMALL_AMOUNT = 2;

    public Ellipse() {
    }

    private boolean closeTogether(Point firstPoint, Point secondPoint) {
        if (firstPoint.x - secondPoint.x > SMALL_AMOUNT) {
            return false;
        }
        if (firstPoint.y - secondPoint.y > SMALL_AMOUNT) {
            return false;
        }
        if (secondPoint.x - firstPoint.x > SMALL_AMOUNT) {
            return false;
        }
        if (secondPoint.y - firstPoint.y > SMALL_AMOUNT) {
            return false;
        }
        return true;
    }

    public void drawBorder(Graphics g, java.awt.Rectangle location) {
        g.drawOval(location.x, location.y, location.width, location.height);
    }

    public void drawFilledShape(Graphics g, java.awt.Rectangle location) {
        g.fillOval(location.x, location.y, location.width, location.height);
    }

    public void drawShape(Graphics g, java.awt.Rectangle location) {
        g.drawOval(location.x, location.y, location.width, location.height);
    }

    public Point getBoundaryPointOnLine(Line line, java.awt.Rectangle shapeLocation) {
        Ellipse2D underlyingEllipse =
            new Ellipse2D.Double(shapeLocation.x, shapeLocation.y, shapeLocation.width, shapeLocation.height);
        if (underlyingEllipse.contains(line.startingPoint.x, line.startingPoint.y)) {
            return getBoundaryPointOnLine(line.startingPoint, line.endingPoint, underlyingEllipse);
        }
        return getBoundaryPointOnLine(line.endingPoint, line.startingPoint, underlyingEllipse);
    }

    private Point getBoundaryPointOnLine(Point interiorPoint, Point exteriorPoint, Ellipse2D underlyingEllipse) {
        Point intermediatePoint = new Point();
        intermediatePoint.x = (interiorPoint.x + exteriorPoint.x) / 2;
        intermediatePoint.y = (interiorPoint.y + exteriorPoint.y) / 2;
        if (closeTogether(interiorPoint, exteriorPoint)) {
            return intermediatePoint;
        }
        if (underlyingEllipse.contains(intermediatePoint.x, intermediatePoint.y)) {
            return getBoundaryPointOnLine(intermediatePoint, exteriorPoint, underlyingEllipse);
        }
        return getBoundaryPointOnLine(interiorPoint, intermediatePoint, underlyingEllipse);
    }

    public boolean intersectsLineUniquely(Line line, java.awt.Rectangle shapeLocation) {
        return true;
    }
}
