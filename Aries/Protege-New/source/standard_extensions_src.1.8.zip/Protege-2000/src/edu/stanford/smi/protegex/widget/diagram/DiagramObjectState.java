/*
 * The contents of this file are subject to the Mozilla Public License
 * Version 1.1 (the "License");  you may not use this file except in compliance
 * with the License.  You may obtain a copy of the License at
 * http://www.mozilla.org/MPL/
 *
 * Software distributed under the License is distributed on an "AS IS" basis,
 * WITHOUT WARRANTY OF ANY KIND, either express or implied. See the License for
 * the specific language governing rights and limitations under the License.
 *
 * The Original Code is Protege-2000.
 *
 * The Initial Developer of the Original Code is Stanford University. Portions
 * created by Stanford University are Copyright (C) 2001.  All Rights Reserved.
 *
 * Protege-2000 was developed by Stanford Medical Informatics
 * (http://www.smi.stanford.edu) at the Stanford University School of Medicine
 * with support from the National Library of Medicine, the National Science
 * Foundation, and the Defense Advanced Research Projects Agency.  Current
 * information about Protege can be obtained at http://protege.stanford.edu
 *
 * Contributor(s):
 */

package edu.stanford.smi.protegex.widget.diagram;

import java.awt.*;

import edu.stanford.smi.protege.util.*;

/**
 *  Description of the class
 *
 * @author    William Grosso <grosso@smi.stanford.edu>
 */
public class DiagramObjectState implements Constants {
    public final static boolean BOLD_TEXT_DEFAULT = false;
    public final static boolean ITALIC_TEXT_DEFAULT = false;
    public final static boolean VERTICALLY_CENTERED_TEXT_DEFAULT = true;
    public final static boolean HORIZONTALLY_CENTERED_TEXT_DEFAULT = true;
    public final static boolean DRAW_TEXT_USING_GLYPH_COLOR_DEFAULT = false;

    protected Color _objectColor;
    protected Color _textColor;
    protected boolean _displayText;
    protected boolean _boldText;
    protected boolean _italicText;
    protected boolean _verticallyCenteredText;
    protected boolean _horizontallyCenteredText;

    protected final static String OBJECT_COLOR_RGB_DESCRIPTOR = ":COLOR:RGB:DESCRIPTOR";
    protected final static String TEXT_COLOR_RGB_DESCRIPTOR = ":TEXT:COLOR:RGB:DESCRIPTOR";
    protected final static String DISPLAY_TEXT = ":DISPLAY:TEXT";
    protected final static String MAKE_TEXT_BOLD = ":MAKE:TEXT:BOLD";
    protected final static String MAKE_TEXT_ITALIC = ":MAKE:TEXT:ITALIC";
    protected final static String VERTICALLY_CENTER_TEXT = ":VERTICALLY:CENTER:TEXT";
    protected final static String HORIZONTALLY_CENTER_TEXT = ":HORIZONTALLY:CENTER:TEXT";

    public DiagramObjectState(PropertyList pList) {
        _boldText = readBoolean(pList, MAKE_TEXT_BOLD, BOLD_TEXT_DEFAULT);
        _italicText = readBoolean(pList, MAKE_TEXT_ITALIC, ITALIC_TEXT_DEFAULT);
        _verticallyCenteredText = readBoolean(pList, VERTICALLY_CENTER_TEXT, VERTICALLY_CENTERED_TEXT_DEFAULT);
        _horizontallyCenteredText = readBoolean(pList, HORIZONTALLY_CENTER_TEXT, HORIZONTALLY_CENTERED_TEXT_DEFAULT);
    }

    public boolean getBoldText() {
        return _boldText;
    }

    public boolean getDisplayText() {
        return _displayText;
    }

    public boolean getHorizontallyCenteredText() {
        return _horizontallyCenteredText;
    }

    public boolean getItalicText() {
        return _italicText;
    }

    public Color getObjectColor() {
        return _objectColor;
    }

    public Color getTextColor() {
        return _textColor;
    }

    public boolean getVerticallyCenteredText() {
        return _verticallyCenteredText;
    }

    public boolean isBoldText() {
        return _boldText;
    }

    public boolean isDisplayText() {
        return _displayText;
    }

    public boolean isHorizontallyCenteredText() {
        return _horizontallyCenteredText;
    }

    public boolean isItalicText() {
        return _italicText;
    }

    public boolean isVerticallyCenteredText() {
        return _verticallyCenteredText;
    }

    protected boolean readBoolean(PropertyList properties, String name, boolean defaultValue) {
        Boolean objectValue = properties.getBoolean(name);
        if (null != objectValue) {
            return objectValue.booleanValue();
        }
        return defaultValue;
    }

    protected Color readColor(PropertyList properties, String name, Color defaultValue) {
        Integer rGB = properties.getInteger(name);
        if (null != rGB) {
            return new Color(rGB.intValue());
        }
        return defaultValue;
    }

    protected int readInt(PropertyList properties, String name, int defaultValue) {
        Integer objectValue = properties.getInteger(name);
        if (null != objectValue) {
            return objectValue.intValue();
        }
        return defaultValue;
    }

    protected String readString(PropertyList properties, String name, String defaultValue) {
        String objectValue = properties.getString(name);
        if (null != objectValue) {
            return objectValue;
        }
        return defaultValue;
    }

    public void setBoldText(boolean boldText) {
        _boldText = boldText;
    }

    public void setDisplayText(boolean displayText) {
        _displayText = displayText;
    }

    public void setHorizontallyCenteredText(boolean horizontallyCenteredText) {
        _horizontallyCenteredText = horizontallyCenteredText;
    }

    public void setItalicText(boolean italicText) {
        _italicText = italicText;
    }

    public void setObjectColor(Color objectColor) {
        _objectColor = objectColor;
    }

    public void setTextColor(Color textColor) {
        _textColor = textColor;
    }

    public void setVerticallyCenteredText(boolean verticallyCenteredText) {
        _verticallyCenteredText = verticallyCenteredText;
    }

    public void writeToPropertyList(PropertyList pList) {
        pList.setInteger(OBJECT_COLOR_RGB_DESCRIPTOR, _objectColor.getRGB());
        pList.setInteger(TEXT_COLOR_RGB_DESCRIPTOR, _textColor.getRGB());
        pList.setBoolean(DISPLAY_TEXT, _displayText);
        pList.setBoolean(MAKE_TEXT_BOLD, _boldText);
        pList.setBoolean(MAKE_TEXT_ITALIC, _italicText);
        pList.setBoolean(VERTICALLY_CENTER_TEXT, _verticallyCenteredText);
        pList.setBoolean(HORIZONTALLY_CENTER_TEXT, _horizontallyCenteredText);
    }
}
