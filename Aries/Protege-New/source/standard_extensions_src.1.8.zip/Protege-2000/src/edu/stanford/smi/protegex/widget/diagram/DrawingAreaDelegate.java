/*
 * The contents of this file are subject to the Mozilla Public License
 * Version 1.1 (the "License");  you may not use this file except in compliance
 * with the License.  You may obtain a copy of the License at
 * http://www.mozilla.org/MPL/
 *
 * Software distributed under the License is distributed on an "AS IS" basis,
 * WITHOUT WARRANTY OF ANY KIND, either express or implied. See the License for
 * the specific language governing rights and limitations under the License.
 *
 * The Original Code is Protege-2000.
 *
 * The Initial Developer of the Original Code is Stanford University. Portions
 * created by Stanford University are Copyright (C) 2001.  All Rights Reserved.
 *
 * Protege-2000 was developed by Stanford Medical Informatics
 * (http://www.smi.stanford.edu) at the Stanford University School of Medicine
 * with support from the National Library of Medicine, the National Science
 * Foundation, and the Defense Advanced Research Projects Agency.  Current
 * information about Protege can be obtained at http://protege.stanford.edu
 *
 * Contributor(s):
 */

package edu.stanford.smi.protegex.widget.diagram;

import edu.stanford.smi.protege.model.*;

import java.util.*;
import java.awt.*;

/**
 *  Description of the Class
 *
 * @author    William Grosso <grosso@smi.stanford.edu>
 */
public class DrawingAreaDelegate implements Constants {
    private DiagramWidget _widget;
    private Dimension _minimalLogicalBoundingBox;

    public DrawingAreaDelegate(DiagramWidget widget) {
        _widget = widget;
    }

    private void adjustMinimalLogicalBounds(Iterator i) {
        Instance networkInstance = _widget.getNetworkInstance();
        while (i.hasNext()) {
            Rectangle nextRect = DiagramUtilities.getLocationRectangleForObject((Instance) i.next(), networkInstance);
            int suggestedWidth = nextRect.x + nextRect.width;
            if (suggestedWidth > _minimalLogicalBoundingBox.width) {
                _minimalLogicalBoundingBox.width = suggestedWidth;
            }
            int suggestedHeight = nextRect.y + nextRect.height;
            if (suggestedHeight > _minimalLogicalBoundingBox.height) {
                _minimalLogicalBoundingBox.height = suggestedHeight;
            }
        }
    }

    private void computeMinimalLogicalBoundingBox() {
        DiagramWidgetState state = _widget.getState();
        Collection currentNodes = _widget.getNodes();
        Collection currentConnectors = _widget.getConnectors();
        _minimalLogicalBoundingBox = new Dimension(state.getLowerBoundOnDiagramWidth(), state.getLowerBoundOnDiagramHeight());
        if (null != currentNodes) {
            adjustMinimalLogicalBounds(currentNodes.iterator());
        }
        if (null != currentConnectors) {
            adjustMinimalLogicalBounds(currentConnectors.iterator());
        }
    }

    public int getDividerLocation() {
        return getIntegerSlotValue(LAST_DIVIDER_LOCATION, DEFAULT_LAST_DIVIDER_LOCATION);
    }

    private int getIntegerSlotValue(String slotName, int defaultValue) {
        Instance networkInstance = _widget.getNetworkInstance();
        if (null == networkInstance) {
            return defaultValue;
        }
        Slot slot = _widget.getKnowledgeBase().getSlot(slotName);
        Integer value = (Integer) networkInstance.getOwnSlotValue(slot);
        if (null == value) {
            setIntegerSlot(slotName, defaultValue);
            return defaultValue;
        }
        return value.intValue();
    }

    public int getLogicalDrawingAreaHeight() {
        int nominalValue = getIntegerSlotValue(MAIN_SIDE_RECTANGLE_HEIGHT, 0);
        computeMinimalLogicalBoundingBox();
        if (nominalValue < _minimalLogicalBoundingBox.height) {
            setLogicalDrawingAreaHeight(_minimalLogicalBoundingBox.height);
            return _minimalLogicalBoundingBox.height;
        }
        return nominalValue;
    }

    public int getLogicalDrawingAreaWidth() {
        int nominalValue = getIntegerSlotValue(MAIN_SIDE_RECTANGLE_WIDTH, 0);
        computeMinimalLogicalBoundingBox();
        if (nominalValue < _minimalLogicalBoundingBox.width) {
            setLogicalDrawingAreaWidth(_minimalLogicalBoundingBox.width);
            return _minimalLogicalBoundingBox.width;
        }
        return nominalValue;
    }

    public int getMinimumPossibleLogicalDrawingAreaHeight() {
        computeMinimalLogicalBoundingBox();
        return _minimalLogicalBoundingBox.height;
    }

    public int getMinimumPossibleLogicalDrawingAreaWidth() {
        computeMinimalLogicalBoundingBox();
        return _minimalLogicalBoundingBox.width;
    }

    public void setDividerLocation(int dividerLocation) {
        setIntegerSlot(LAST_DIVIDER_LOCATION, dividerLocation);
    }

    private void setIntegerSlot(String slotname, int value) {
        Instance networkInstance = _widget.getNetworkInstance();
        if (null == networkInstance) {
            return;
        }
        Slot slot = _widget.getKnowledgeBase().getSlot(slotname);
        networkInstance.setOwnSlotValue(slot, new Integer(value));
    }

    public void setLogicalDrawingAreaHeight(int mainDrawingAreaHeight) {
        setIntegerSlot(MAIN_SIDE_RECTANGLE_HEIGHT, mainDrawingAreaHeight);
    }

    public void setLogicalDrawingAreaWidth(int mainDrawingAreaWidth) {
        setIntegerSlot(MAIN_SIDE_RECTANGLE_WIDTH, mainDrawingAreaWidth);
    }
}
