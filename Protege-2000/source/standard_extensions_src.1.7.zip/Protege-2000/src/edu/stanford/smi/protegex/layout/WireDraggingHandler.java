/*
 * The contents of this file are subject to the Mozilla Public License
 * Version 1.1 (the "License");  you may not use this file except in compliance
 * with the License.  You may obtain a copy of the License at
 * http://www.mozilla.org/MPL/
 *
 * Software distributed under the License is distributed on an "AS IS" basis,
 * WITHOUT WARRANTY OF ANY KIND, either express or implied. See the License for
 * the specific language governing rights and limitations under the License.
 *
 * The Original Code is Protege-2000.
 *
 * The Initial Developer of the Original Code is Stanford University. Portions
 * created by Stanford University are Copyright (C) 2001.  All Rights Reserved.
 *
 * Protege-2000 was developed by Stanford Medical Informatics
 * (http://www.smi.stanford.edu) at the Stanford University School of Medicine
 * with support from the National Library of Medicine, the National Science
 * Foundation, and the Defense Advanced Research Projects Agency.  Current
 * information about Protege can be obtained at http://protege.stanford.edu
 *
 * Contributor(s):
 */

package edu.stanford.smi.protegex.layout;

import java.awt.event.*;
import java.awt.*;

/**
 *  Description of the Class
 *
 * @author    William Grosso <grosso@smi.stanford.edu>
 */
public class WireDraggingHandler extends ActorDraggingHandler {
    private int controlPoint;
    private boolean _isAttachable;
    private Point _p1;
    private Point _p2;
    private int _sensitivity;
    private int _negativeSensitivity;

    // hit testing sensitivity
    public final static int DEFAULT_SENSITIVITY = 10;

    public WireDraggingHandler(Actor actor) {
        this(actor, DEFAULT_SENSITIVITY);
    }

    public WireDraggingHandler(Actor actor, int sensitivity) {
        super(actor);
        _p1 = new Point();
        _p2 = new Point();
        _sensitivity = sensitivity;
        _negativeSensitivity = -1 * _sensitivity;
    }

    public Object copy() {
        return new WireDraggingHandler(_actor);
    }

    public void processDragging(MouseEvent e) {
        Point mouseEventLocation = e.getPoint();
        if (null != _oldMouseLocation) {
            ((StandardWireActor) _actor).setStartingAttachment(null);
            ((StandardWireActor) _actor).setEndingAttachment(null);

            _location.translate(mouseEventLocation.x - _oldMouseLocation.x, mouseEventLocation.y - _oldMouseLocation.y);
            _location.moveInsideCoordinateSystem();
        }
        _oldMouseLocation = mouseEventLocation;
        return;
    }

    private float square(int value) {
        return value * value;
    }

    public boolean wantDrag(MouseEvent e) {
        int x1 = _location.getBaseX();
        int x2 = _location.getExtensionX();
        int y1 = _location.getBaseY();
        int y2 = _location.getExtensionY();

        int ex = e.getX();
        int ey = e.getY();

        if (ex < (x1 - _sensitivity) || ex > (x2 + _sensitivity)) {
            return false;
        }

        if (ey < (y1 - _sensitivity) || ey > (y2 + _sensitivity)) {
            return false;
        }

        _actor.getControlPoint(((StandardWireActor) _actor).getBeginningControlPoint(), _p1);
        _actor.getControlPoint(((StandardWireActor) _actor).getEndingControlPoint(), _p2);

        double a = - (_p2.y - _p1.y);
        double b = (_p2.x - _p1.x);
        double c = ((_p2.y - _p1.y) * _p2.x) - (_p2.y * (_p2.x - _p1.x));
        double pointDistance = (a * ex + b * ey + c) / (Math.sqrt(a * a + b * b));

        if ((pointDistance < _sensitivity) && (pointDistance > _negativeSensitivity)) {
            return true;
        }
        return false;
    }
}
