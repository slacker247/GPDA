/*
 * The contents of this file are subject to the Mozilla Public License
 * Version 1.1 (the "License");  you may not use this file except in compliance
 * with the License.  You may obtain a copy of the License at
 * http://www.mozilla.org/MPL/
 *
 * Software distributed under the License is distributed on an "AS IS" basis,
 * WITHOUT WARRANTY OF ANY KIND, either express or implied. See the License for
 * the specific language governing rights and limitations under the License.
 *
 * The Original Code is Protege-2000.
 *
 * The Initial Developer of the Original Code is Stanford University. Portions
 * created by Stanford University are Copyright (C) 2001.  All Rights Reserved.
 *
 * Protege-2000 was developed by Stanford Medical Informatics
 * (http://www.smi.stanford.edu) at the Stanford University School of Medicine
 * with support from the National Library of Medicine, the National Science
 * Foundation, and the Defense Advanced Research Projects Agency.  Current
 * information about Protege can be obtained at http://protege.stanford.edu
 *
 * Contributor(s):
 */

package edu.stanford.smi.protegex.widget.diagram;

import edu.stanford.smi.protege.model.*;
import java.awt.event.*;
import java.awt.*;
import javax.swing.*;
import javax.swing.border.*;
import java.util.*;

/**
 *  Description of the class
 *
 * @author    William Grosso <grosso@smi.stanford.edu>
 */
public class CheckboxBasedClassDisplayer extends JPanel {
    private TypeBasedVisibilityChecker _visibilityChecker;
    private DiagramWidget _widget;
    private HashMap _namesToClasses;

    private class ClassCheckBoxListener implements ActionListener {
        public void actionPerformed(ActionEvent e) {
            JCheckBox source = (JCheckBox) e.getSource();
            Cls value = (Cls) _namesToClasses.get(source.getText());
            if (source.isSelected()) {
                _visibilityChecker.unhideCls(value);
            } else {
                _visibilityChecker.hideCls(value);
            }
            _widget.repaint();
        }
    }

    public CheckboxBasedClassDisplayer(
        Collection classes,
        TypeBasedVisibilityChecker visibilityChecker,
        DiagramWidget widget,
        String label) {
        super(new BorderLayout());
        _visibilityChecker = visibilityChecker;
        _widget = widget;
        buildGUI(classes, label);
    }

    private JCheckBox buildCheckbox(String name, boolean isChecked) {
        JCheckBox returnValue = new JCheckBox(name);
        returnValue.setSelected(isChecked);
        return returnValue;
    }

    private void buildGUI(Collection classes, String label) {
        ClassCheckBoxListener listener = new ClassCheckBoxListener();
        _namesToClasses = new HashMap();
        if ((null == classes) || (0 == classes.size())) {
            return;
        }
        JPanel centerPanel = new JPanel(new GridBagLayout());
        GridBagConstraints gridBagConstraint = getFirstConstraint();
        Iterator i = classes.iterator();
        while (i.hasNext()) {
            Cls nextCls = (Cls) i.next();
            String clsName = nextCls.getName();
            JCheckBox nextBox = buildCheckbox(clsName, _visibilityChecker.isClsVisible(nextCls));
            nextBox.addActionListener(listener);
            _namesToClasses.put(clsName, nextCls);
            gridBagConstraint.gridy++;
            centerPanel.add(nextBox, gridBagConstraint);
        }
        JScrollPane _outerPane = new JScrollPane(centerPanel);
        Border etchedBorder = BorderFactory.createEtchedBorder();
        Border mainBorder = BorderFactory.createTitledBorder(etchedBorder, label);
        _outerPane.setBorder(mainBorder);
        add(_outerPane, BorderLayout.CENTER);
    }

    private GridBagConstraints getFirstConstraint() {
        GridBagConstraints returnValue = new GridBagConstraints();
        returnValue.gridwidth = 1;
        returnValue.gridheight = 1;
        returnValue.gridx = 0;
        returnValue.gridy = 0;
        returnValue.weightx = 1.0;
        returnValue.weighty = 1.0;
        returnValue.fill = GridBagConstraints.HORIZONTAL;
        return returnValue;
    }
}
