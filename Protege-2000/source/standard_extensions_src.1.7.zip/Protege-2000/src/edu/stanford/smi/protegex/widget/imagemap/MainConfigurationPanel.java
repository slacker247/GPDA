/*
 * The contents of this file are subject to the Mozilla Public License
 * Version 1.1 (the "License");  you may not use this file except in compliance
 * with the License.  You may obtain a copy of the License at
 * http://www.mozilla.org/MPL/
 *
 * Software distributed under the License is distributed on an "AS IS" basis,
 * WITHOUT WARRANTY OF ANY KIND, either express or implied. See the License for
 * the specific language governing rights and limitations under the License.
 *
 * The Original Code is Protege-2000.
 *
 * The Initial Developer of the Original Code is Stanford University. Portions
 * created by Stanford University are Copyright (C) 2001.  All Rights Reserved.
 *
 * Protege-2000 was developed by Stanford Medical Informatics
 * (http://www.smi.stanford.edu) at the Stanford University School of Medicine
 * with support from the National Library of Medicine, the National Science
 * Foundation, and the Defense Advanced Research Projects Agency.  Current
 * information about Protege can be obtained at http://protege.stanford.edu
 *
 * Contributor(s):
 */

package edu.stanford.smi.protegex.widget.imagemap;

import edu.stanford.smi.protege.widget.*;
import edu.stanford.smi.protege.model.*;
import edu.stanford.smi.protege.ui.*;
import edu.stanford.smi.protege.util.*;
import edu.stanford.smi.protegex.util.*;
import java.awt.*;
import java.awt.event.*;
import javax.swing.*;
import javax.swing.event.*;
import java.util.*;
import java.io.*;

import javax.swing.*;

/**
 *  Description of the class
 *
 * @author    William Grosso <grosso@smi.stanford.edu>
 */
public class MainConfigurationPanel extends JPanel implements Validatable, Observer {
    private ImageMapState _state;

    private FileField _imageLocation;
    private AnnotatedSlider _lineWidthSlider;
    private ColorWell _selectionColorWell;
    private ColorWell _tooltipColorWell;
    private JCheckBox _showTooltips;
    private JCheckBox _showSelectedRectanglesDuringKA;
    private GenericListener _gcl;
    private FileLocationListener _fcl;

    private boolean _preventEdits;

    private class GenericListener extends FocusAdapter implements ActionListener, ChangeListener {
        public void stateChanged(ChangeEvent e) {
            setStatefromUI();
        }

        public void focusLost(FocusEvent e) {
            setStatefromUI();
        }

        public void actionPerformed(ActionEvent e) {
            setStatefromUI();
        }
    }

    private class FileLocationListener implements ChangeListener {
        public void stateChanged(ChangeEvent e) {
            if (_preventEdits) {
                return;
            }
            setStateImageLocationFromFileField();
            SwingUtilities.invokeLater(
                new Runnable() {
                    public void run() {
                        setFileField();
                    }
                }
            );
        }
    }

    public MainConfigurationPanel(ImageMapWidget widget) {
        super(new GridLayout(6, 1));
        _state = widget.getState();
        _gcl = new GenericListener();
        _fcl = new FileLocationListener();
        buildGUI();
        addActions();
        setUIFromState();
    }

    private void addActions() {
        _imageLocation.addChangeListener(_fcl);
        _showTooltips.addActionListener(_gcl);
        _showSelectedRectanglesDuringKA.addActionListener(_gcl);
        _lineWidthSlider.addChangeListener(_gcl);
    }

    private void buildGUI() {
        _selectionColorWell = createColorChooser("Color for Selected Rectangles");
        _tooltipColorWell = createColorChooser("Color for Tooltips");
        _showTooltips = createCheckBox("Show tooltips");
        _showSelectedRectanglesDuringKA = createCheckBox("Show Rectangles during KA");
        _imageLocation = new FileField("Image Location", "", "", "Where the undelrying image is stored");
        add(_imageLocation);
        _lineWidthSlider = createSlider("Line Thickness");
        _state.addObserver(this);
    }

    private JCheckBox createCheckBox(String name) {
        JCheckBox returnValue = new JCheckBox(name);
        LabeledComponent surroundingBox = new LabeledComponent("", returnValue);
        add(surroundingBox);
        return returnValue;
    }

    private ColorWell createColorChooser(String name) {
        ColorWell returnValue = new ColorWell(Color.white, _gcl);
        LabeledComponent lc = new LabeledComponent(name, returnValue);
        add(lc);
        return returnValue;
    }

    private AnnotatedSlider createSlider(String name) {
        AnnotatedSlider returnValue =
            AnnotatedSlider.getAnnotatedSlider(
                _state.getLineThicknessMinimum(),
                _state.getLineThicknessMaximum(),
                _state.getLineThickness(),
                AnnotatedSlider.LINE_VIEW);
        LabeledComponent surroundingBox = new LabeledComponent(name, returnValue);
        add(surroundingBox);
        return returnValue;
    }

    private boolean isFile(String location) {
        // hack to handle Ray's API
        if (location.startsWith("http:")) {
            return false;
        }
        if (location.startsWith("ftp:")) {
            return false;
        }
        return true;
    }

    private String relativiseLocation(String initialLocation) {
        // hack until Ray gives me a real file API
        if (null == initialLocation) {
            return null;
        }
        if (false == isFile(initialLocation)) {
            return initialLocation;
        }
        File file = new File(initialLocation);
        return file.getName();
    }

    public void saveContents() {
        _state.save();
    }

    private void setFileField() {
        if (_preventEdits) {
            return;
        }
        _preventEdits = true;
        _state.setImageLocation(relativiseLocation(_imageLocation.getPath()));
        _imageLocation.setPath(_state.getImageLocation());
        _preventEdits = false;
    }

    private void setStatefromUI() {
        if (_preventEdits) {
            return;
        }
        _preventEdits = true;
        _state.setSelectionColor(_selectionColorWell.getColor());
        _state.setTooltipColor(_tooltipColorWell.getColor());
        _state.setShowTooltips(_showTooltips.isSelected());
        _state.setShowSelectedRectanglesDuringKA(_showSelectedRectanglesDuringKA.isSelected());
        _state.setImageLocation(relativiseLocation(_imageLocation.getPath()));
        _state.setLineThickness(_lineWidthSlider.getValue());
        _preventEdits = false;
    }

    private void setStateImageLocationFromFileField() {
        if (_preventEdits) {
            return;
        }
        _preventEdits = true;
        _state.setImageLocation(relativiseLocation(_imageLocation.getPath()));
        _preventEdits = false;
    }

    private void setUIFromState() {
        if (_preventEdits) {
            return;
        }
        _preventEdits = true;
        _selectionColorWell.setColor(_state.getSelectionColor());
        _tooltipColorWell.setColor(_state.getTooltipColor());
        _showTooltips.setSelected(_state.getShowTooltips());
        _showSelectedRectanglesDuringKA.setSelected(_state.getShowSelectedRectanglesDuringKA());
        _imageLocation.setPath(_state.getImageLocation());
        _lineWidthSlider.setValue(_state.getLineThickness());
        _preventEdits = false;
    }

    public void update(Observable o, Object arg) {
        setUIFromState();
    }

    public boolean validateContents() {
        return true;
    }
}
