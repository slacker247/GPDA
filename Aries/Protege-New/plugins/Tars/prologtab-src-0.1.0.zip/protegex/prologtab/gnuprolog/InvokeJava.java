package protegex.prologtab.gnuprolog;

import java.lang.reflect.*;
import gnu.prolog.term.*;
import gnu.prolog.vm.*;
/**
 * Insert the type's description here.
 * Creation date: (4/29/2002 11:05:07 AM)
 * @author: 
 */
public class InvokeJava extends GNUPrologTabBuiltin {
	public static final AtomTerm invokeAtom = AtomTerm.get("invoke"); 
/**
 * InvokeJava constructor comment.
 */
public InvokeJava() {
	super();
}
/**
 * Insert the method's description here.
 * Creation date: (5/7/2002 11:29:37 AM)
 * @return boolean
 * @param parameters java.lang.Object[]
 * @param parameterTypes java.lang.Class[]
 */
public static boolean compareParameters(Object[] parameters, Class[] parameterTypes) {
	for (int i=0; i<parameters.length; i++)
		if ((parameters[i] != null) && !parameterTypes[i].isInstance(parameters[i]))
			return false;
	return true;
}
 /** this method is used for execution of code
     * @param interpreter interpreter in which context code is executed 
     * @param backtrackMode true if predicate is called on backtracking and false otherwise
     * @param args arguments of code
     * @return either SUCCESS, SUCCESS_LAST, or FAIL.
     */
public int execute(gnu.prolog.vm.Interpreter interpreter, boolean backtrackMode, gnu.prolog.term.Term[] args) throws gnu.prolog.vm.PrologException {
	if (backtrackMode) return FAIL;
	Term targetTerm = checkNonVar(args,0);
	AtomTerm methodNameTerm = checkAtom(args,1);
	Term parameterListTerm = checkList(args,2);
	Term resultTerm = checkVar(args,3);

	Object result = null;
	try {
		Object target = _engine.getJavaObject(targetTerm);
		Class clss;
		if (target instanceof String)
			clss = Class.forName((String) target);
		else
			clss = target.getClass();
		Object[] parameters = _engine.getArray(parameterListTerm);
		Method method = getMethod(clss,((AtomTerm) methodNameTerm).value,parameters);
		result = method.invoke(target,parameters);
	} catch (InvocationTargetException ite) {
	} catch (Exception e) {
		PrologException.domainError(methodNameTerm,AtomTerm.get(e.getClass().getName()));
	}
	return interpreter.unify(resultTerm,_engine.getTerm(result));
}
/**
 * Insert the method's description here.
 * Creation date: (12/5/00 1:41:05 PM)
 * @return java.lang.reflect.Method
 * @param clss java.lang.Class
 * @param methodName java.lang.String
 */
public static Method getMethod(Class clss, String methodName, Object[] parameters) {
	Method[] methods = clss.getMethods();
	Method method = null;
	for (int i=0; i < methods.length; i++)
		if ((methods[i].getName().equals(methodName)) &&
			(methods[i].getParameterTypes().length == parameters.length) &&
				compareParameters(parameters,methods[i].getParameterTypes()))
					return methods[i];
	return null;
}
}
