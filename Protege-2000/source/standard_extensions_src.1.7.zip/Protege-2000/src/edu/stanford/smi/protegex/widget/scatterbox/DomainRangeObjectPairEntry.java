/*
 * The contents of this file are subject to the Mozilla Public License
 * Version 1.1 (the "License");  you may not use this file except in compliance
 * with the License.  You may obtain a copy of the License at
 * http://www.mozilla.org/MPL/
 *
 * Software distributed under the License is distributed on an "AS IS" basis,
 * WITHOUT WARRANTY OF ANY KIND, either express or implied. See the License for
 * the specific language governing rights and limitations under the License.
 *
 * The Original Code is Protege-2000.
 *
 * The Initial Developer of the Original Code is Stanford University. Portions
 * created by Stanford University are Copyright (C) 2001.  All Rights Reserved.
 *
 * Protege-2000 was developed by Stanford Medical Informatics
 * (http://www.smi.stanford.edu) at the Stanford University School of Medicine
 * with support from the National Library of Medicine, the National Science
 * Foundation, and the Defense Advanced Research Projects Agency.  Current
 * information about Protege can be obtained at http://protege.stanford.edu
 *
 * Contributor(s):
 */

package edu.stanford.smi.protegex.widget.scatterbox;

import java.awt.*;
import java.awt.event.*;
import java.util.*;

import edu.stanford.smi.protege.model.*;
import edu.stanford.smi.protege.widget.*;
import edu.stanford.smi.protege.util.*;
import edu.stanford.smi.protege.event.*;
import edu.stanford.smi.protege.ui.*;
import edu.stanford.smi.protege.Application;

/**
 *  Description of the class
 *
 * @author    William Grosso <grosso@smi.stanford.edu>
 */
public class DomainRangeObjectPairEntry extends BasicQueryObject implements DomainRangeObjectPairConstants {

    public Instance getDomainObject(Instance entry) {
        KnowledgeBase kb = entry.getKnowledgeBase();
        Slot domainValueSlot = kb.getSlot(DOMAIN_VALUE_SLOT);
        return (Instance) entry.getOwnSlotValue(domainValueSlot);
    }

    public Cls getDomainTypeFromEntryCls(Cls entryCls) {
        KnowledgeBase kb = entryCls.getKnowledgeBase();
        Slot domainValueSlot = kb.getSlot(DOMAIN_VALUE_SLOT);
        return getType(entryCls, domainValueSlot);
    }

    public Instance getOrCreateDomainObject(Instance entry) {
        Instance domainInstance = getDomainObject(entry);
        if (null != domainInstance) {
            return domainInstance;
        }
        KnowledgeBase kb = entry.getKnowledgeBase();
        Cls entryCls = entry.getDirectType();
        Cls domainCls = getDomainTypeFromEntryCls(entryCls);

        domainInstance = kb.createInstance(null, domainCls);
        setDomainObject(entry, domainInstance);
        return domainInstance;
    }

    public Instance getOrCreateRangeObject(Instance entry) {
        Instance rangeInstance = getRangeObject(entry);
        if (null != rangeInstance) {
            return rangeInstance;
        }
        KnowledgeBase kb = entry.getKnowledgeBase();
        Cls entryCls = entry.getDirectType();
        Cls rangeCls = getRangeTypeFromEntryCls(entryCls);

        rangeInstance = kb.createInstance(null, rangeCls);
        setRangeObject(entry, rangeInstance);
        return rangeInstance;
    }

    public Instance getRangeObject(Instance entry) {
        KnowledgeBase kb = entry.getKnowledgeBase();
        Slot rangeValueSlot = kb.getSlot(RANGE_VALUE_SLOT);
        return (Instance) entry.getOwnSlotValue(rangeValueSlot);
    }

    // range
    public Cls getRangeTypeFromEntryCls(Cls entryCls) {
        KnowledgeBase kb = entryCls.getKnowledgeBase();
        Slot rangeValueSlot = kb.getSlot(RANGE_VALUE_SLOT);
        return getType(entryCls, rangeValueSlot);
    }

    private Cls getType(Cls cls, Slot slot) {
        Collection allowedClasses = cls.getTemplateSlotAllowedClses(slot);
        if ((null == allowedClasses) || (1 != allowedClasses.size())) {
            return null;
        }
        Cls type = (Cls) CollectionUtilities.getSoleItem(allowedClasses);
        return type;
    }

    public void setDomainObject(Instance entry, Instance domainObject) {
        KnowledgeBase kb = entry.getKnowledgeBase();
        Slot domainValueSlot = kb.getSlot(DOMAIN_VALUE_SLOT);
        entry.setOwnSlotValue(domainValueSlot, domainObject);
        return;
    }

    public void setRangeObject(Instance entry, Instance rangeObject) {
        KnowledgeBase kb = entry.getKnowledgeBase();
        Slot rangeValueSlot = kb.getSlot(RANGE_VALUE_SLOT);
        entry.setOwnSlotValue(rangeValueSlot, rangeObject);
        return;
    }
}
