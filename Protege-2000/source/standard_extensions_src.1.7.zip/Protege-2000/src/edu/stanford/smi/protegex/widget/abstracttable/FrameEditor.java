/*
 * The contents of this file are subject to the Mozilla Public License
 * Version 1.1 (the "License");  you may not use this file except in compliance
 * with the License.  You may obtain a copy of the License at
 * http://www.mozilla.org/MPL/
 *
 * Software distributed under the License is distributed on an "AS IS" basis,
 * WITHOUT WARRANTY OF ANY KIND, either express or implied. See the License for
 * the specific language governing rights and limitations under the License.
 *
 * The Original Code is Protege-2000.
 *
 * The Initial Developer of the Original Code is Stanford University. Portions
 * created by Stanford University are Copyright (C) 2001.  All Rights Reserved.
 *
 * Protege-2000 was developed by Stanford Medical Informatics
 * (http://www.smi.stanford.edu) at the Stanford University School of Medicine
 * with support from the National Library of Medicine, the National Science
 * Foundation, and the Defense Advanced Research Projects Agency.  Current
 * information about Protege can be obtained at http://protege.stanford.edu
 *
 * Contributor(s):
 */

package edu.stanford.smi.protegex.widget.abstracttable;

import java.awt.*;
import java.awt.event.*;
import java.util.*;
import java.util.List;
import javax.swing.*;

import edu.stanford.smi.protege.model.*;
import edu.stanford.smi.protege.model.Frame;
import edu.stanford.smi.protege.ui.*;
import edu.stanford.smi.protege.util.*;

import edu.stanford.smi.protegex.util.*;

/**
 *  Description of the Class
 *
 * @author    William Grosso <grosso@smi.stanford.edu>
 */
public abstract class FrameEditor extends ComboBoxEditor {
    protected Frame _value;
    protected Project _project;
    protected JComponent _onScreenComponent;
    protected boolean _hasModelBeenConfigured;
    protected boolean _processingUserSelection;

    protected EditableComboBoxModel _model;
    protected final static String REMOVE = "Remove";
    protected final static String CHOOSE = "Choose ...";
    protected final static String EDIT = "View ...";

    public FrameEditor(JComponent onScreenComponent, Project project) {
        this(onScreenComponent, project, null, null);
    }

    public FrameEditor(JComponent onScreenComponent, Project project, Instance instance, Slot slot) {
        super(instance, slot);
        _project = project;
        _onScreenComponent = onScreenComponent;
        _processingUserSelection = false;
        configureUIFromKB();
        setRenderer(new FrameRenderer_ListCell());
    }

    protected void addUniquely(Collection addToMe, Collection addFromMe) {
        Iterator i = addFromMe.iterator();
        while (i.hasNext()) {
            Object nextObject = (i.next());
            if (false == addToMe.contains(nextObject)) {
                addToMe.add(nextObject);
            }
        }
    }

    protected abstract void configureComboBoxModel();

    public void configureUIFromKB() {
        if (_readingFromModel) {
            return;
        }
        _readingFromModel = true;
        _value = (Frame) getValue();
        configureComboBoxModel();
        selectValueInComboBox();
        _readingFromModel = false;
    }

    private void editCurrentValue() {
        if (_value != null) {
            _project.show((Instance) _value);
        }
        selectValueInComboBox();
    }

    protected ComboBoxModel getComboBoxModel() {
        _model = new EditableComboBoxModel();
        return _model;
    }

    protected abstract List getPossibleChoices();

    private void getUserChoice() {
        getValueFromDialog();
        selectValueInComboBox();
        return;
    }

    protected abstract void getValueFromDialog();

    protected void handleSelectionChange() {
        if (_processingSelection) {
            return;
        }
        _processingSelection = true;
        if (!_readingFromModel) {
            processUserSelection();
        }
        _processingSelection = false;
    }

    protected void processUserSelection() {
        Object selection = getSelectedItem();
        if (REMOVE == selection) {
            removeCurrentValue();
            return;
        }
        if (EDIT == selection) {
            editCurrentValue();
            return;
        }
        if (CHOOSE == selection) {
            getUserChoice();
            return;
        }
        if (selection instanceof Frame) {
            _value = (Frame) selection;
            storeValueInKB();
        }
    }

    private void removeCurrentValue() {
        _value = null;
        storeValueInKB();
        configureUIFromKB();
    }

    protected void selectValueInComboBox() {
        if (null == _value) {
            _model.setSelectedItem(NULL_STRING);
        } else {
            _model.setSelectedItem(_value);
        }
    }

    public void storeValueInKB() {
        if ((_instance == null) || (_slot == null)) {
            return;
        }
        if (_readingFromModel) {
            return;
        }
        if ((null != _instance) && (null != _slot)) {
            _instance.setOwnSlotValue(_slot, _value);
        }
    }
}
