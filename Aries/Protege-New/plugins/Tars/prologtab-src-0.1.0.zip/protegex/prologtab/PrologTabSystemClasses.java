package protegex.prologtab;

import java.lang.reflect.*;
import java.util.*;
import java.io.*;
import java.awt.Rectangle;
import edu.stanford.smi.protege.widget.*;
import edu.stanford.smi.protege.model.*;
import edu.stanford.smi.protege.util.*;
/**
 * Helper class for creating and accessing Prolog code within the KnowledgeBase.
 * Creation date: (4/11/2002 10:07:59 AM)
 * @author: 
 */
public class PrologTabSystemClasses {
	public static final String PROLOG_MODULE = ":PROLOG-MODULE";
	public static final String PROLOG_MODULE_NAME = ":PROLOG-MODULE-NAME";
	public static final String PROLOG_CODE = ":PROLOG-CODE";
	public static final String PROLOG_DEPENDENTS = ":PROLOG-DEPENDENTS";
	public static final String PROLOG_BUILTINS_MODULE = ":PROLOG-BUILTINS-MODULE";
/**
 * PrologTabSystemClasses constructor comment.
 */
public PrologTabSystemClasses() {
	super();
}
/**
 * Insert the method's description here.
 * Creation date: (4/11/2002 10:09:22 AM)
 * @param kb edu.stanford.smi.protege.model.KnowledgeBase
 */
public static void addSystemClasses(KnowledgeBase kb) {
	Collection superClasses = new ArrayList(1);
	superClasses.add(kb.getCls(Model.Cls.SYSTEM_CLASS));
	Cls prologModuleClass = kb.getCls(PROLOG_MODULE);
	if (prologModuleClass == null) {
		prologModuleClass = kb.createCls(PROLOG_MODULE, superClasses);
		Slot prologModuleNameSlot = kb.getSlot(PROLOG_MODULE_NAME);
		if (prologModuleNameSlot == null) {
			prologModuleNameSlot = kb.createSlot(PROLOG_MODULE_NAME);
			prologModuleNameSlot.setEditable(false);
		}
		prologModuleClass.addDirectTemplateSlot(prologModuleNameSlot);
		Slot prologCodeSlot = kb.getSlot(PROLOG_CODE);
		if (prologCodeSlot == null) {
			prologCodeSlot = kb.createSlot(PROLOG_CODE);
			prologCodeSlot.setEditable(false);
		}
		prologModuleClass.addDirectTemplateSlot(prologCodeSlot);
		Slot prologDependentsSlot = kb.getSlot(PROLOG_DEPENDENTS);
		if (prologDependentsSlot == null) {
			prologDependentsSlot = kb.createSlot(PROLOG_DEPENDENTS);
			prologDependentsSlot.setAllowsMultipleValues(true);
			prologDependentsSlot.setValueType(ValueType.INSTANCE);
			Collection allowedClasses = new ArrayList(1);
			allowedClasses.add(prologModuleClass);
			prologDependentsSlot.setAllowedClses(allowedClasses);
		}
		prologModuleClass.addDirectTemplateSlot(prologDependentsSlot);
		prologModuleClass.setDirectBrowserSlot(prologModuleNameSlot);
		customizeForm(prologModuleClass);
	}
	Instance builtinsModule = kb.getInstance(PROLOG_BUILTINS_MODULE);
	if (builtinsModule == null) {
		Slot prologModuleNameSlot = kb.getSlot(PROLOG_MODULE_NAME);
		builtinsModule = kb.createInstance(PROLOG_BUILTINS_MODULE,prologModuleClass);
		builtinsModule.setOwnSlotValue(prologModuleNameSlot,"BUILT-INS");
	}
}
/**
 * Insert the method's description here.
 * Creation date: (4/15/2002 11:01:46 AM)
 * @param prologCls edu.stanford.smi.protege.model.Cls
 */
private static void customizeForm(Cls prologCls) {
	Project project = prologCls.getProject();
	
	// Hack to make things work under Protege 1.5 *and* 1.6...
	ClsWidget widget = null;
	Method m = null;
	try {  // Protege 1.5
		// ClsWidget jess_widget = project.createDesignTimeClsWidget(jess_class);  // Doesn't work under Protege 1.6 (the method is missing)
		m = Project.class.getMethod("createDesignTimeClsWidget", new Class []{Cls.class} );
	} catch (NoSuchMethodException e) { }
	try {  // Protege 1.6
		// ClsWidget jess_widget = project.getDesignTimeClsWidget(jess_class);  // Works under Protege 1.6
		m = Project.class.getMethod("getDesignTimeClsWidget", new Class []{Cls.class} );
	} catch (NoSuchMethodException e) { }
	if (m instanceof Method) {
		try {
			widget = (ClsWidget)m.invoke(project, new Object[] {prologCls});
		} catch (InvocationTargetException e) {  }
			catch (IllegalAccessException e) {  }
	}
	// End hack

	// Get the descriptor and set as modified...
	if (widget instanceof ClsWidget) {
		widget.getDescriptor().setDirectlyCustomizedByUser(true);
	}

	PropertyList properties = project.getClsWidgetPropertyList(prologCls);
	WidgetDescriptor name_descr = properties.getWidgetDescriptor(PROLOG_MODULE_NAME);
	name_descr.setLabel("Name");
	name_descr.setBounds(new Rectangle(0, 0, 200, 60));
	
	WidgetDescriptor code_descr = properties.getWidgetDescriptor(PROLOG_CODE);
	code_descr.setLabel("Module");
	code_descr.setBounds(new Rectangle(0, 80, 200, 400));
	code_descr.setWidgetClassName(TextAreaWidget.class.getName());

	WidgetDescriptor dependents_descr = properties.getWidgetDescriptor(PROLOG_DEPENDENTS);
	dependents_descr.setLabel("Dependents");
	dependents_descr.setBounds(new Rectangle(0, 500, 200, 120));
}
/**
 * Insert the method's description here.
 * Creation date: (4/11/2002 1:17:35 PM)
 * @return java.io.InputStream
 * @param codeModule edu.stanford.smi.protege.model.Instance
 */
public static InputStream getCodeModuleInputStream(Instance codeModule) {
	Slot codeSlot = codeModule.getKnowledgeBase().getSlot(PROLOG_CODE);
	Slot dependentsSlot = codeModule.getKnowledgeBase().getSlot(PROLOG_DEPENDENTS);
	ByteArrayOutputStream baos = new ByteArrayOutputStream();
	PrintWriter writer = new PrintWriter(baos);
	Set expanded = new HashSet();
	Set visited = new HashSet();
	List stack = new ArrayList();
	stack.add(0,codeModule);
	Instance currentModule;
	while (!stack.isEmpty()) {
		currentModule = (Instance) stack.remove(0);
		if (!expanded.contains(currentModule)) {
			expanded.add(currentModule);
			stack.add(0,currentModule);
			stack.addAll(0,currentModule.getOwnSlotValues(dependentsSlot));
		} else {
			if (!visited.contains(currentModule)) {
				visited.add(currentModule);
				String prologCode = (String) currentModule.getOwnSlotValue(codeSlot);
				if (prologCode != null) {
					writer.println(prologCode);
					writer.flush();
				}
			}
		}
	}
	return new ByteArrayInputStream(baos.toByteArray());
}
/**
 * Insert the method's description here.
 * Creation date: (4/11/2002 1:17:35 PM)
 * @return java.io.InputStream
 * @param codeModule edu.stanford.smi.protege.model.Instance
 */
public static String getCodeModuleName(Instance codeModule) {
	Slot nameSlot = codeModule.getKnowledgeBase().getSlot(PROLOG_MODULE_NAME);
	return (String) codeModule.getOwnSlotValue(nameSlot);
}
/**
 * Insert the method's description here.
 * Creation date: (4/24/2002 12:18:08 PM)
 * @return edu.stanford.smi.protege.model.Instance
 * @param kb edu.stanford.smi.protege.model.KnowledgeBase
 */
public static Instance getPrologBuiltInsModule(KnowledgeBase kb) {
	return kb.getInstance(PROLOG_BUILTINS_MODULE);
}
/**
 * Insert the method's description here.
 * Creation date: (4/15/2002 10:47:49 AM)
 * @return java.util.Collection
 * @param kb edu.stanford.smi.protege.model.KnowledgeBase
 */
public static Collection getPrologCodeClses(KnowledgeBase kb) {
	Collection clses = new HashSet();
	Cls prologCodeCls = kb.getCls(PROLOG_MODULE);
	clses.add(prologCodeCls);
	clses.addAll(prologCodeCls.getSubclasses());
	return clses;
}
/**
 * Lookup the PrologModule by name.
 * Creation date: (4/12/2002 10:07:21 AM)
 * @return edu.stanford.smi.protege.model.Instance
 * @param name java.lang.String
 * @param kb edu.stanford.smi.protege.model.KnowledgeBase
 */
public static Instance getPrologModule(String name, KnowledgeBase kb) {
	Cls moduleCls = kb.getCls(PROLOG_MODULE);
	Slot moduleNameSlot = kb.getSlot(PROLOG_MODULE_NAME);
	Iterator iterator = moduleCls.getInstances().iterator();
	while (iterator.hasNext()) {
		Instance module = (Instance) iterator.next();
		if (name.equals(module.getOwnSlotValue(moduleNameSlot)))
			return module;
	}
	return null;
}
/**
 * Insert the method's description here.
 * Creation date: (4/24/2002 12:26:51 PM)
 * @param kb edu.stanford.smi.protege.model.KnowledgeBase
 * @param builtins java.lang.String
 */
public static void setPrologBuiltins(KnowledgeBase kb, String builtins) {
	Slot codeSlot = kb.getSlot(PROLOG_CODE);
	Instance builtinsModule = kb.getInstance(PROLOG_BUILTINS_MODULE);
	builtinsModule.setEditable(true);
	builtinsModule.setOwnSlotValue(codeSlot,builtins);
	builtinsModule.setEditable(false);
}
}
