/*
 * The contents of this file are subject to the Mozilla Public License
 * Version 1.1 (the "License");  you may not use this file except in compliance
 * with the License.  You may obtain a copy of the License at
 * http://www.mozilla.org/MPL/
 *
 * Software distributed under the License is distributed on an "AS IS" basis,
 * WITHOUT WARRANTY OF ANY KIND, either express or implied. See the License for
 * the specific language governing rights and limitations under the License.
 *
 * The Original Code is Protege-2000.
 *
 * The Initial Developer of the Original Code is Stanford University. Portions
 * created by Stanford University are Copyright (C) 2001.  All Rights Reserved.
 *
 * Protege-2000 was developed by Stanford Medical Informatics
 * (http://www.smi.stanford.edu) at the Stanford University School of Medicine
 * with support from the National Library of Medicine, the National Science
 * Foundation, and the Defense Advanced Research Projects Agency.  Current
 * information about Protege can be obtained at http://protege.stanford.edu
 *
 * Contributor(s):
 */

package edu.stanford.smi.protegex.layout;

import java.awt.*;
import java.awt.event.*;
import java.awt.geom.*;
import java.util.*;
import javax.swing.*;

/**
 *  Description of the Class
 *
 * @author    William Grosso <grosso@smi.stanford.edu>
 */
public class StandardWireActor extends AbstractActor {
    protected WireGlyph _glyph;
    protected Point _scratchPoint;
    protected Line _underlyingLine;
    protected ActorAttachment _startingAttachment;
    protected ActorAttachment _endingAttachment;
    protected int _BEGINNING = ControlPoints.UPPER_LEFT;
    // tells the starting control point w.r.t. the location
    protected int _ENDING = ControlPoints.LOWER_RIGHT;

    // tells the ending control point w.r.t. the location
    public StandardWireActor(
        WireGlyph glyph,
        AnimationContext animationContext,
        ActorLocation location,
        ActorEventHandler eventHandler,
        ActorMovementHandler movementHandler,
        ActorControlPointHandler controlPointHandler) {
        super(animationContext, location, eventHandler, movementHandler, controlPointHandler);
        _glyph = glyph;
        _scratchPoint = new Point();
        _underlyingLine = new Line();
    }

    private void adjustLine() {
        _location.getBounds(_lastDrawingLocation);
        if (null != _startingAttachment) {
            Point newStartingPoint = (_startingAttachment.getActor()).getBoundaryPointForLine(_underlyingLine);
            if (null != newStartingPoint) {
                _underlyingLine.startingPoint.x = newStartingPoint.x;
                _underlyingLine.startingPoint.y = newStartingPoint.y;
                //    _underlyingLine.startingPoint = new Point(newStartingPoint);
            }
        }
        if (null != _endingAttachment) {
            Point newEndingPoint = (_endingAttachment.getActor()).getBoundaryPointForLine(_underlyingLine);
            if (null != newEndingPoint) {
                _underlyingLine.endingPoint.x = newEndingPoint.x;
                _underlyingLine.endingPoint.y = newEndingPoint.y;
                //    _underlyingLine.endingPoint = new Point(newEndingPoint);
            }
        }
        return;
    }

    private void buildLine() {
        buildPreliminaryLine();
        adjustLine();
    }

    private void buildPreliminaryLine() {
        if (null != _startingAttachment) {
            _startingAttachment.getPointOnTarget(_underlyingLine.startingPoint);
            _controlPointHandler.moveControlPoint(_startingAttachment.getControlPointOnAttacher(), _underlyingLine.startingPoint);
        } else {
            ((WireControlPointHandler) _controlPointHandler).getBeginningPoint(_underlyingLine.startingPoint);
        }
        if (null != _endingAttachment) {
            _endingAttachment.getPointOnTarget(_underlyingLine.endingPoint);
            _controlPointHandler.moveControlPoint(_endingAttachment.getControlPointOnAttacher(), _underlyingLine.endingPoint);
        } else {
            ((WireControlPointHandler) _controlPointHandler).getEndingPoint(_underlyingLine.endingPoint);
        }
        return;
    }

    public Object copy() {
        WireGlyph copyOfGlyph = (WireGlyph) _glyph.copy();
        ActorLocation copyOfLocation = (ActorLocation) _location.copy();
        ActorEventHandler copyOfEventHandler = (ActorEventHandler) _eventHandler.copy();
        ActorMovementHandler copyOfMovementHandler = (ActorMovementHandler) _movementHandler.copy();
        ActorControlPointHandler copyOfControlPointHandler = (ActorControlPointHandler) _controlPointHandler.copy();
        StandardWireActor returnValue =
            new StandardWireActor(
                copyOfGlyph,
                _animationContext,
                copyOfLocation,
                copyOfEventHandler,
                copyOfMovementHandler,
                copyOfControlPointHandler);
        returnValue.setStartingAttachment(_startingAttachment);
        returnValue.setEndingAttachment(_endingAttachment);
        return returnValue;
    }

    public Rectangle draw(Graphics g) {
        _location.moveInsideCoordinateSystem();
        buildLine();
        positionUnderlyingGlyph();
        if (_eventHandler.getIsSelected()) {
            _glyph.displaySelectedImage(_location, g);
        } else {
            _glyph.displayImage(_location, g);
        }
        return _lastDrawingLocation;
    }

    public int getBeginningControlPoint() {
        return _BEGINNING;
    }

    public Point getBeginningPoint() {
        return (((WireControlPointHandler) _controlPointHandler).getBeginningPoint());
    }

    public Point getBoundaryPointForLine(Line line) {
        return _glyph.getBoundaryPointForLine(line);
    }

    public ActorAttachment getEndingAttachment() {
        return _endingAttachment;
    }

    public int getEndingControlPoint() {
        return _ENDING;
    }

    public Point getEndingPoint() {
        return (((WireControlPointHandler) _controlPointHandler).getEndingPoint());
    }

    public ActorAttachment getStartingAttachment() {
        return _startingAttachment;
    }

    public boolean isWire() {
        return true;
    }

    private void positionUnderlyingGlyph() {
        _glyph.setStartingPoint(_underlyingLine.startingPoint);
        _glyph.setEndingPoint(_underlyingLine.endingPoint);
    }

    public void setBeginningControlPoint(int BEGINNING) {
        _BEGINNING = BEGINNING;
    }

    public void setBeginningPoint(Point pt) {
        ((WireControlPointHandler) _controlPointHandler).changeLocation(_BEGINNING, pt);
    }

    public void setEndingAttachment(ActorAttachment attachment) {
        _endingAttachment = attachment;
    }

    public void setEndingControlPoint(int ENDING) {
        _ENDING = ENDING;
    }

    public void setEndingPoint(Point pt) {
        ((WireControlPointHandler) _controlPointHandler).changeLocation(_ENDING, pt);
    }

    public void setStartingAttachment(ActorAttachment attachment) {
        _startingAttachment = attachment;
    }

    public void setTitle(String title) {
        _glyph.setTitle(title);
    }

    public void tick(int currentTime) {

        _movementHandler.tick(currentTime);

    }
}
