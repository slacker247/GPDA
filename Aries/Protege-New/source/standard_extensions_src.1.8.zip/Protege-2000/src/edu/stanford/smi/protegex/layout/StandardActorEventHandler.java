/*
 * The contents of this file are subject to the Mozilla Public License
 * Version 1.1 (the "License");  you may not use this file except in compliance
 * with the License.  You may obtain a copy of the License at
 * http://www.mozilla.org/MPL/
 *
 * Software distributed under the License is distributed on an "AS IS" basis,
 * WITHOUT WARRANTY OF ANY KIND, either express or implied. See the License for
 * the specific language governing rights and limitations under the License.
 *
 * The Original Code is Protege-2000.
 *
 * The Initial Developer of the Original Code is Stanford University. Portions
 * created by Stanford University are Copyright (C) 2001.  All Rights Reserved.
 *
 * Protege-2000 was developed by Stanford Medical Informatics
 * (http://www.smi.stanford.edu) at the Stanford University School of Medicine
 * with support from the National Library of Medicine, the National Science
 * Foundation, and the Defense Advanced Research Projects Agency.  Current
 * information about Protege can be obtained at http://protege.stanford.edu
 *
 * Contributor(s):
 */

package edu.stanford.smi.protegex.layout;

import java.awt.event.*;

/**
 *  Aggregates DraggingHandler and a ResizingHandler
 *
 * @author    William Grosso <grosso@smi.stanford.edu>
 */
public final class StandardActorEventHandler extends ActorDelegateImpl
         implements ActorEventHandler {
    private boolean _isSelected;
    private boolean _isSelectable;
    private ActorDraggingHandler _actorDraggingHandler;
    private ResizingHandler _actorResizingHandler;

    public StandardActorEventHandler(Actor actor) {
        super(actor);
        _location = actor.getLocation();
        _actorResizingHandler = new ResizingHandler(_actor);
        _actorDraggingHandler = new ActorDraggingHandler(_actor);
    }

    public StandardActorEventHandler(
        Actor actor,
        ResizingHandler actorResizingHandler,
        ActorDraggingHandler actorDraggingHandler) {
        super(actor);
        _location = actor.getLocation();
        _actorResizingHandler = actorResizingHandler;
        _actorDraggingHandler = actorDraggingHandler;
    }

    public boolean canPerformIncrementalDrag(int deltaX, int deltaY) {
        return _location.translationStaysInCoordinateSystem(deltaX, deltaY);
    }

    // The Copyable Interface
    public Object copy() {
        ResizingHandler newRH = (ResizingHandler) _actorResizingHandler.copy();
        ActorDraggingHandler newADH = (ActorDraggingHandler) _actorDraggingHandler.copy();
        StandardActorEventHandler returnValue = new StandardActorEventHandler(_actor, newRH, newADH);
        returnValue.setIsSelectable(_isSelectable);
        returnValue.setIsDraggable(getIsDraggable());
        returnValue.setIsResizable(getIsResizable());
        return returnValue;
    }

    public Class getDraggingHandler() {
        return _actorDraggingHandler.getClass();
    }

    // Dragging information
    public boolean getIsDraggable() {
        return _actorDraggingHandler.getCanBeActive();
    }

    public boolean getIsDragging() {
        return _actorDraggingHandler.getIsActive();
    }

    // Resizing information
    public boolean getIsResizable() {
        return _actorResizingHandler.getCanBeActive();
    }

    public boolean getIsResizing() {
        return _actorResizingHandler.getIsActive();
    }

    public boolean getIsSelectable() {
        return _isSelectable;
    }

    // The Event Handler interface
    public boolean getIsSelected() {
        return _isSelected;
    }

    public Class getResizingHandler() {
        return _actorResizingHandler.getClass();
    }

    public void processClick(MouseEvent e) {
        if (e.getClickCount() == 2) {
            _actor.broadcastActorDoubleClickedEvent();
        } else {
            AnimationContext animationContext = _actor.getAnimationContext();
            if ((_isSelected) && (!animationContext.isSingleSelection())) {
                animationContext.unselectActor(_actor);
            } else {
                if (e.isShiftDown()) {
                    animationContext.selectActor(_actor);
                }
            }
        }
    }

    public void processDrag(MouseEvent e) {
        // Resizing takes precedence
        if (getIsResizing()) {
            _actorResizingHandler.processDrag(e);
            return;
        }
        if (getIsDragging()) {
            _actorDraggingHandler.processDrag(e);
            _actor.broadcastActorMovedEvent();
            return;
        }
        if (_actorResizingHandler.wantDrag(e)) {
            _actorResizingHandler.processDrag(e);
            return;
        }
        if (_actorDraggingHandler.wantDrag(e)) {
            _actorDraggingHandler.processDrag(e);
            _actor.broadcastActorStartedMovingEvent();
            return;
        }
        return;
    }

    public void processIncrementalDrag(int deltaX, int deltaY) {
        _actorDraggingHandler.processIncrementalDrag(deltaX, deltaY);
        _actor.broadcastActorMovedEvent();
        return;
    }

    public void processMousePress(MouseEvent e) {
        if (e.getClickCount() > 1) {
            return;
        }
        AnimationContext animationContext = _actor.getAnimationContext();
        if (!_isSelected) {
            if (!e.isShiftDown()) {
                animationContext.setSelectedActor(_actor);
            }
        }
    }

    public void processMouseRelease(MouseEvent e) {
        if (getIsResizing()) {
            _actorResizingHandler.processMouseRelease(e);
            _actor.broadcastActorResizedEvent();
        } else {
            if (getIsDragging()) {
                _actorDraggingHandler.processMouseRelease(e);
                _actor.broadcastActorStoppedMovingEvent();
            }
        }
    }

    public void setActor(Actor actor) {
        super.setActor(actor);
        _actorResizingHandler.setActor(_actor);
        _actorDraggingHandler.setActor(_actor);

    }

    public void setIsDraggable(boolean isDraggable) {
        _actorDraggingHandler.setCanBeActive(isDraggable);
        return;
    }

    public void setIsResizable(boolean isResizable) {
        _actorResizingHandler.setCanBeActive(isResizable);
        return;
    }

    public void setIsSelectable(boolean isSelectable) {
        _isSelectable = isSelectable;
    }

    public void setIsSelected(boolean isSelected) {
        if (_isSelected == isSelected) {
            return;
        }
        _isSelected = isSelected;
        if (_isSelected) {
            _actor.broadcastActorSelectedEvent();
        }
        return;
    }

    public boolean wantEvent(MouseEvent e) {
        return _location.contains(e.getPoint());
    }
}
