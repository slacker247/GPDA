/*
 * The contents of this file are subject to the Mozilla Public License
 * Version 1.1 (the "License");  you may not use this file except in compliance
 * with the License.  You may obtain a copy of the License at
 * http://www.mozilla.org/MPL/
 *
 * Software distributed under the License is distributed on an "AS IS" basis,
 * WITHOUT WARRANTY OF ANY KIND, either express or implied. See the License for
 * the specific language governing rights and limitations under the License.
 *
 * The Original Code is Protege-2000.
 *
 * The Initial Developer of the Original Code is Stanford University. Portions
 * created by Stanford University are Copyright (C) 2001.  All Rights Reserved.
 *
 * Protege-2000 was developed by Stanford Medical Informatics
 * (http://www.smi.stanford.edu) at the Stanford University School of Medicine
 * with support from the National Library of Medicine, the National Science
 * Foundation, and the Defense Advanced Research Projects Agency.  Current
 * information about Protege can be obtained at http://protege.stanford.edu
 *
 * Contributor(s):
 */

package edu.stanford.smi.protegex.layout;

import java.awt.*;

/**
 *  Description of the class
 *
 * @author    William Grosso <grosso@smi.stanford.edu>
 */
public class WireGlyph implements Glyph {
    // names of types defined in WireUtilities
    protected String _wireType;
    protected String _startingArrow;
    protected String _endingArrow;

    protected String _title;

    protected Color _color;
    protected Point _startingPoint;
    protected Point _endingPoint;
    protected boolean _startingArrowIsConnected;
    protected boolean _endingArrowIsConnected;

    protected int BEGINNING;
    // not used
    protected int ENDING;
    // when there is a movement this is set
    final static int selectedRectangleSize = 4;

    // not used
    public WireGlyph(
        String wireType,
        Color color,
        String startingArrow,
        String endingArrow,
        String title,
        boolean startingArrowIsConnected,
        boolean endingArrowIsConnected) {
        _color = color;

        _wireType = wireType;
        _startingArrow = startingArrow;
        _endingArrow = endingArrow;

        _startingPoint = new Point();
        _endingPoint = new Point();
        _title = title;
        setStartingArrowIsConnected(startingArrowIsConnected);
        setEndingArrowIsConnected(endingArrowIsConnected);
    }

    private void _displayImage(Graphics g, boolean isSelected) {
        int startX;
        int startY;
        int endX;
        int endY;
        startX = Math.min(_startingPoint.x, _endingPoint.x);
        endX = Math.max(_startingPoint.x, _endingPoint.x);

        if (startX == _startingPoint.x) {
            startY = _startingPoint.y;
            endY = _endingPoint.y;
        } else {
            startY = _endingPoint.y;
            endY = _startingPoint.y;
        }
        WireUtilities.drawWire(
            g,
            _wireType,
            _startingArrow,
            _endingArrow,
            _color,
            _startingPoint.x,
            _startingPoint.y,
            _endingPoint.x,
            _endingPoint.y,
            isSelected,
            _startingArrowIsConnected,
            _endingArrowIsConnected);
    }

    // The Copyable Interface
    public Object copy() {
        return new WireGlyph(
            _wireType,
            _color,
            _startingArrow,
            _endingArrow,
            _title,
            _startingArrowIsConnected,
            _endingArrowIsConnected);
    }

    //  The Glyph Interface
    public void displayImage(ActorLocation location, Graphics g) {
        _displayImage(g, false);
    }

    public void displayImage(Rectangle location, Graphics g) {
        _displayImage(g, false);
    }

    public void displaySelectedImage(ActorLocation location, Graphics g) {
        _displayImage(g, true);
    }

    public void displaySelectedImage(Rectangle location, Graphics g) {
        _displayImage(g, true);
    }

    public Point getBoundaryPointForLine(Line line) {
        throw new Error("Implement me");
    }

    public int getPreferredHeight() {
        return 30;
    }

    public int getPreferredWidth() {
        return 30;
    }

    public void setEndingArrowIsConnected(boolean endingArrowIsConnected) {
        _endingArrowIsConnected = endingArrowIsConnected;
    }

    public void setEndingPoint(Point endingPoint) {
        _endingPoint.x = endingPoint.x;
        _endingPoint.y = endingPoint.y;
        return;
    }

    public void setStartingArrowIsConnected(boolean startingArrowIsConnected) {
        _startingArrowIsConnected = startingArrowIsConnected;
    }

    public void setStartingPoint(Point startingPoint) {
        _startingPoint.x = startingPoint.x;
        _startingPoint.y = startingPoint.y;
        return;
    }

    public void setTitle(String title) {
        _title = title;
    }
}
