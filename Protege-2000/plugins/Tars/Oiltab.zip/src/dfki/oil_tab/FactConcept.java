package dfki.protege.oil_tab;

public abstract class FactConcept extends FactExpression {

}

