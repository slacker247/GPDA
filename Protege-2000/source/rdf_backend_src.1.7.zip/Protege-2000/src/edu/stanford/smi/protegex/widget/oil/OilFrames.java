/*
 * The contents of this file are subject to the Mozilla Public License
 * Version 1.1 (the "License");  you may not use this file except in compliance
 * with the License.  You may obtain a copy of the License at
 * http://www.mozilla.org/MPL/
 *
 * Software distributed under the License is distributed on an "AS IS" basis,
 * WITHOUT WARRANTY OF ANY KIND, either express or implied. See the License for
 * the specific language governing rights and limitations under the License.
 *
 * The Original Code is Protege-2000.
 *
 * The Initial Developer of the Original Code is Stanford University. Portions
 * created by Stanford University are Copyright (C) 2001.  All Rights Reserved.
 *
 * Protege-2000 was developed by Stanford Medical Informatics
 * (http://www.smi.stanford.edu) at the Stanford University School of Medicine
 * with support from the National Library of Medicine, the National Science
 * Foundation, and the Defense Advanced Research Projects Agency.  Current
 * information about Protege can be obtained at http://protege.stanford.edu
 *
 * Contributor(s):
 */

package edu.stanford.smi.protegex.widget.oil;


import java.util.*;
import javax.swing.*;
import edu.stanford.smi.protege.model.*;


class OilFrames {

  KnowledgeBase itsKB;
  JTextArea itsTextArea; // for reporting warnings/errors
  HashMap itsSlots;
  HashMap itsClses;


  OilFrames(KnowledgeBase kb) {
    this(kb, null);
  }

  OilFrames(KnowledgeBase kb, JTextArea textArea) {
    itsKB = kb;
    itsTextArea = textArea; // for reporting errors
    itsSlots = new HashMap();
    itsClses = new HashMap();
  }


  Cls getCls(String name) {
    Cls cls = (Cls)itsClses.get(name);
    if (cls == null) {
      cls = itsKB.getCls(name);
      if (cls == null)
        report("class not found: " + name);
      else
	itsClses.put(name, cls);
    }
    return cls;
  }

  Slot getSlot(String name) {
    Slot slot = (Slot)itsSlots.get(name);
    if (slot == null) {
      slot = itsKB.getSlot(name);
      if (slot == null)
        report("slot not found: " + name);
      else
	itsSlots.put(name, slot);
    }
    return slot;
  }

  Collection getSubclasses(String clsName) {
    Cls cls = getCls(clsName);
    if (cls != null)
      return cls.getSubclasses();
    else
      return Collections.EMPTY_LIST;
  }

  Collection getInstances(String clsName) {
    Cls cls = getCls(clsName);
    if (cls != null)
      return cls.getInstances();
    else
      return Collections.EMPTY_LIST;
  }

  Object getOwnSlotValue(Instance inst, String slotName) {
    Slot slot = getSlot(slotName);
    if (inst != null && slot != null)
      return inst.getOwnSlotValue(slot);
    else
      return null;
  }

  Object getOwnSlotRequiredValue(Instance inst, String slotName) {
    return getOwnSlotRequiredValue(inst, slotName, null);
  }

  Object getOwnSlotRequiredValue(Instance inst, String slotName, Object def) {
    Slot slot = getSlot(slotName);
    if (inst != null && slot != null) {
      Object value = inst.getOwnSlotValue(slot);
      // check there's only one value!
      if (value != null)
	return value;
      else {
	report("no value for slot " + slotName + " on frame " + inst);
	return def;
      }
    } else
      return def;
  }

  String getOwnSlotRequiredValueName(Instance inst, 
				     String slotName, String def) {
    Frame frame = (Frame)getOwnSlotRequiredValue(inst, slotName);
    // check if cast to Frame is ok ... !!!
    if (frame == null)
      return def;
    else
      return frame.getName();
  }

  int getOwnSlotRequiredIntValue(Instance inst, String slotName, int def) {
    Integer integer = (Integer)getOwnSlotRequiredValue(inst, slotName);
    // check if cast to Integer is ok ... !!!
    if (integer == null)
      return def;
    else
      return integer.intValue();
  }

  Collection getOwnSlotValues(Instance inst, String slotName) {
    Slot slot = getSlot(slotName);
    if (inst != null && slot != null)
      return inst.getOwnSlotValues(slot);
    else
      return Collections.EMPTY_LIST;
  }

  Collection getOwnSlotValuesNotEmpty(Instance inst, String slotName) {
    Slot slot = getSlot(slotName);
    if (inst != null && slot != null) {
      Collection values = inst.getOwnSlotValues(slot);
      if (values.isEmpty())
	report("no values for slot " + slotName + " on instance " + inst);
      return values;
    } else
      return Collections.EMPTY_LIST;
  }

  boolean equals(Cls cls, String clsName) {
    Cls cls1 = getCls(clsName);
    return cls.equals(cls1);
  }


  // reporting

  void report(String text) {
    if (itsTextArea != null) {
      itsTextArea.append(text);
      itsTextArea.append("\n");
    } else {
      System.out.println("### ");
      System.out.println(text);
    }
  }

  
}


