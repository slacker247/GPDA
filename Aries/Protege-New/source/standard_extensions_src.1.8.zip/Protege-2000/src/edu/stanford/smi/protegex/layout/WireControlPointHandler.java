/*
 * The contents of this file are subject to the Mozilla Public License
 * Version 1.1 (the "License");  you may not use this file except in compliance
 * with the License.  You may obtain a copy of the License at
 * http://www.mozilla.org/MPL/
 *
 * Software distributed under the License is distributed on an "AS IS" basis,
 * WITHOUT WARRANTY OF ANY KIND, either express or implied. See the License for
 * the specific language governing rights and limitations under the License.
 *
 * The Original Code is Protege-2000.
 *
 * The Initial Developer of the Original Code is Stanford University. Portions
 * created by Stanford University are Copyright (C) 2001.  All Rights Reserved.
 *
 * Protege-2000 was developed by Stanford Medical Informatics
 * (http://www.smi.stanford.edu) at the Stanford University School of Medicine
 * with support from the National Library of Medicine, the National Science
 * Foundation, and the Defense Advanced Research Projects Agency.  Current
 * information about Protege can be obtained at http://protege.stanford.edu
 *
 * Contributor(s):
 */

package edu.stanford.smi.protegex.layout;

import java.awt.*;
import java.awt.event.*;

/**
 *  Description of the Class
 *
 * @author    William Grosso <grosso@smi.stanford.edu>
 */
public class WireControlPointHandler extends ActorControlPointHandlerImpl {
    // start y is at "base" (top) of actor location (rectangle)
    protected boolean _beginningAtBase;
    public int BEGINNING = ControlPoints.UPPER_LEFT;
    public int ENDING = ControlPoints.LOWER_RIGHT;
    private Point _scratchPoint1;
    private Point _scratchPoint2;
    private int _sensitivity;
    public final static int DEFAULT_SENSITIVITY = 6;
    public final static int NEGATIVE_DEFAULT_SENSITIVITY = -1 * DEFAULT_SENSITIVITY;

    public WireControlPointHandler(int precision, int minimumSize, Actor actor) {
        super(precision, minimumSize, actor);
        _beginningAtBase = true;
        _scratchPoint1 = new Point();
        _scratchPoint2 = new Point();
        _sensitivity = DEFAULT_SENSITIVITY;
    }

    public void changeLocation(int controlPoint, Point destinationPoint) {
        // moving the beginning point
        // get that particular point corresponding to the old point and set location
        getControlPoint(controlPoint, _scratchPoint);
        int deltaX = destinationPoint.x - _scratchPoint.x;
        int deltaY = destinationPoint.y - _scratchPoint.y;

        _location.getBasePoint(_scratchPoint);
        int newHeight = _location.getHeight();
        int newWidth = _location.getWidth();
        switch (controlPoint) {
            case ControlPoints.UPPER_LEFT :
                _scratchPoint.x += deltaX;
                _scratchPoint.y += deltaY;
                newWidth -= deltaX;
                newHeight -= deltaY;

                break;
            case ControlPoints.UPPER_RIGHT :
                _scratchPoint.y += deltaY;
                newWidth += deltaX;
                newHeight -= deltaY;

                break;
            case ControlPoints.LOWER_LEFT :
                _scratchPoint.x += deltaX;
                newWidth -= deltaX;
                newHeight += deltaY;

                break;
            case ControlPoints.LOWER_RIGHT :
                newWidth += deltaX;
                newHeight += deltaY;
                break;
        }

        _location.move(_scratchPoint.x, _scratchPoint.y);
        _location.setHeight(newHeight);
        _location.setWidth(newWidth);

        // relative to the center point can be decided what new control point has the point to be
        _location.getCenterPoint(_scratchPoint);
        deltaX = destinationPoint.x - _scratchPoint.x;
        deltaY = destinationPoint.y - _scratchPoint.y;

        // set new beginning and ending control points
        if (BEGINNING == controlPoint) {
            BEGINNING = setNewControlPoint(deltaX, deltaY);
            ENDING = 8 - BEGINNING;
        } else {
            ENDING = setNewControlPoint(deltaX, deltaY);
            BEGINNING = 8 - ENDING;
        }

        ((StandardWireActor) _actor).setBeginningControlPoint(BEGINNING);
        ((StandardWireActor) _actor).setEndingControlPoint(ENDING);

    }

    public Object copy() {
        return new WireControlPointHandler(_precision, _minimumSize, _actor);
    }

    public Point getBeginningPoint() {
        return getBeginningPoint(new Point());
    }

    public Point getBeginningPoint(Point point) {
        getControlPoint(BEGINNING, point);
        return point;
    }

    public void getControlPoint(int controlPoint, Point returnValue) {
        switch (controlPoint) {
            case ControlPoints.UPPER_LEFT :
                _location.getBasePoint(returnValue);
                break;
            case ControlPoints.UPPER_RIGHT :
                returnValue.x = _location.getExtensionX();
                returnValue.y = _location.getBaseY();
                break;
            case ControlPoints.LOWER_LEFT :
                returnValue.x = _location.getBaseX();
                returnValue.y = _location.getExtensionY();
                break;
            case ControlPoints.LOWER_RIGHT :
                _location.getExtensionPoint(returnValue);
                break;
            default :
                break;
        }
        return;
    }

    public int getControlPointForPoint(Point inputLocation) {
        Point returnValue = new Point();

        // get coordinates of BEGINNING
        getControlPoint(BEGINNING, returnValue);
        if (fuzzyEqual(inputLocation.x, returnValue.x) && fuzzyEqual(inputLocation.y, returnValue.y)) {
            return ControlPoints.BEGINNING;
        }

        // get coordinates of ENDING
        getControlPoint(ENDING, returnValue);
        if (fuzzyEqual(inputLocation.x, returnValue.x) && fuzzyEqual(inputLocation.y, returnValue.y)) {
            return ControlPoints.END;
        }

        return ControlPoints.NOT_A_VALID_CONTROL_POINT;
    }

    public Point getEndingPoint() {
        return getEndingPoint(new Point());
    }

    public Point getEndingPoint(Point point) {
        getControlPoint(ENDING, point);
        return point;
    }

    public void moveControlPoint(int controlPoint, Point destinationPoint) {
        if (controlPoint == ControlPoints.BEGINNING) {
            _location.getBasePoint(_scratchPoint1);
            if (_scratchPoint1.equals(destinationPoint)) {
                return;
            }
            changeLocation(BEGINNING, destinationPoint);
        } else {
            _location.getExtensionPoint(_scratchPoint1);
            if (_scratchPoint1.equals(destinationPoint)) {
                return;
            }
            changeLocation(ENDING, destinationPoint);
        }
        return;
    }

    private int setNewControlPoint(int deltaX, int deltaY) {
        if (deltaX >= 0) {
            if (deltaY >= 0) {
                return ControlPoints.LOWER_RIGHT;
            } else {
                return ControlPoints.UPPER_RIGHT;
            }
        } else {
            if (deltaY >= 0) {
                return ControlPoints.LOWER_LEFT;
            } else {
                return ControlPoints.UPPER_LEFT;
            }
        }

    }

    public void translateControlPoint(int controlPoint, int deltaX, int deltaY) {
        Point actualPoint;
        if (controlPoint == ControlPoints.BEGINNING) {
            actualPoint = getBeginningPoint();
            actualPoint.x += deltaX;
            actualPoint.y += deltaY;
            changeLocation(BEGINNING, actualPoint);
        } else {
            actualPoint = getEndingPoint();
            actualPoint.x += deltaX;
            actualPoint.y += deltaY;
            changeLocation(ENDING, actualPoint);
        }
    }

    public boolean wantEvent(MouseEvent e) {
        // constraining the event to happen in the vicinity of the actor
        int x1 = _location.getBaseX();
        int x2 = _location.getExtensionX();
        int y1 = _location.getBaseY();
        int y2 = _location.getExtensionY();

        int ex = e.getX();
        int ey = e.getY();

        if (ex < (x1 - DEFAULT_SENSITIVITY) || ex > (x2 + DEFAULT_SENSITIVITY)) {
            return false;
        }

        if (ey < (y1 - DEFAULT_SENSITIVITY) || ey > (y2 + DEFAULT_SENSITIVITY)) {
            return false;
        }

        _actor.getControlPoint(((StandardWireActor) _actor).getBeginningControlPoint(), _scratchPoint1);
        _actor.getControlPoint(((StandardWireActor) _actor).getEndingControlPoint(), _scratchPoint2);

        double a;

        double b;

        double c;

        double pointDistance;

        a = - (_scratchPoint2.y - _scratchPoint1.y);
        b = (_scratchPoint2.x - _scratchPoint1.x);
        c =
            ((_scratchPoint2.y - _scratchPoint1.y) * _scratchPoint2.x) - (_scratchPoint2.y * (_scratchPoint2.x - _scratchPoint1.x));

        pointDistance = (a * ex + b * ey + c) / (Math.sqrt(a * a + b * b));

        if ((pointDistance < DEFAULT_SENSITIVITY) && (pointDistance > NEGATIVE_DEFAULT_SENSITIVITY)) {
            return true;
        }
        return false;
    }
}
