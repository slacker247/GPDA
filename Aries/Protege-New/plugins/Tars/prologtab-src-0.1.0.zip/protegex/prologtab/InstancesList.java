package protegex.prologtab;

import java.awt.*;
import java.util.*;
import javax.swing.*;
import javax.swing.event.*;
import edu.stanford.smi.protege.action.*;
import edu.stanford.smi.protege.event.*;
import edu.stanford.smi.protege.model.*;
import edu.stanford.smi.protege.util.*;
import edu.stanford.smi.protege.ui.*;

public class InstancesList extends SelectableContainer implements Disposable {

    private SelectableList _list;
    private Project _project;
    private AllowableAction _deleteAction;

    private FrameListener _instanceFrameListener = new FrameAdapter() {
        public void browserTextChanged(FrameEvent event) {
            super.browserTextChanged(event);
            repaint();
        }
    };

    public InstancesList(Project project) {
        _project = project;
        Action viewAction = createViewAction();
        // itsList = ComponentFactory.createSelectableList(viewAction, true);
        _list = ComponentFactory.createSelectableList(viewAction);
        _list.setCellRenderer(new FrameRenderer());
        _list.addListSelectionListener(new ListSelectionListener() {
            public void valueChanged(ListSelectionEvent event) {
                notifySelectionListeners();
            }
        });
        setLayout(new BorderLayout());
        LabeledComponent c = new LabeledComponent("Instances", new JScrollPane(_list));
        c.addHeaderButton(viewAction);
        // c.addHeaderButton(createReferencersAction());
        // c.addHeaderButton(createDeleteAction());
        c.setFooterComponent(new ListFinder(_list, "Find Instance"));
        add(c);
        setSelectable(_list);
    }
    private void addListeners() {
        Iterator i = getModel().getValues().iterator();
        while (i.hasNext()) {
            Instance instance = (Instance) i.next();
            instance.addFrameListener(_instanceFrameListener);
        }
    }
    private Action createDeleteAction() {
        _deleteAction = new DeleteInstancesAction("Delete Selected Instances", this);
        return _deleteAction;
    }
    private Action createViewAction() {
        return new ViewAction("View Instance", this) {
            public void onView(Object o) {
                _project.show((Instance) o);
            }
        };
    }
    public void dispose() {
        removeListeners();
    }
    public JComponent getDragComponent() {
        return _list;
    }
    private SimpleListModel getModel() {
        return (SimpleListModel) _list.getModel();
    }
    public void initializeSelection() {
        if (_list.getModel().getSize() > 0) {
            _list.setSelectedIndex(0);
        }
    }
    private boolean isSelectionEditable() {
        boolean isEditable = true;
        Iterator i = getSelection().iterator();
        while (i.hasNext()) {
            Instance instance = (Instance) i.next();
            if (!instance.isEditable()) {
                isEditable = false;
                break;
            }
        }
        return isEditable;
    }
    /*
    private Action createReferencersAction() {
        return new ReferencersAction(itsProject, this);
    }
    */

    public void onSelectionChange() {
        // Log.enter(this, "onSelectionChange");
        boolean editable = isSelectionEditable();
        ComponentUtilities.setDragAndDropEnabled(_list, editable);
    }
    private void removeListeners() {
        Iterator i = getModel().getValues().iterator();
        while (i.hasNext()) {
            Instance instance = (Instance) i.next();
            instance.removeFrameListener(_instanceFrameListener);
        }
    }
    public void setInstances(Collection instances) {
        removeListeners();
        // Collections.sort(instances, new FrameComparator());
        getModel().setValues(instances);
        addListeners();
        notifySelectionListeners();
    }
}
