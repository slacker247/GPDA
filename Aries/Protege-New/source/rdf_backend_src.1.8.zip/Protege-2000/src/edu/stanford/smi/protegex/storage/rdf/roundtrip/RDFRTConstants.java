/*
 * The contents of this file are subject to the Mozilla Public License
 * Version 1.1 (the "License");  you may not use this file except in compliance
 * with the License.  You may obtain a copy of the License at
 * http://www.mozilla.org/MPL/
 *
 * Software distributed under the License is distributed on an "AS IS" basis,
 * WITHOUT WARRANTY OF ANY KIND, either express or implied. See the License for
 * the specific language governing rights and limitations under the License.
 *
 * The Original Code is Protege-2000.
 *
 * The Initial Developer of the Original Code is Stanford University. Portions
 * created by Stanford University are Copyright (C) 2001.  All Rights Reserved.
 *
 * Protege-2000 was developed by Stanford Medical Informatics
 * (http://www.smi.stanford.edu) at the Stanford University School of Medicine
 * with support from the National Library of Medicine, the National Science
 * Foundation, and the Defense Advanced Research Projects Agency.  Current
 * information about Protege can be obtained at http://protege.stanford.edu
 *
 * Contributor(s):
 */

package edu.stanford.smi.protegex.storage.rdf.roundtrip;


public interface RDFRTConstants {

  static final String SYSTEMNAMESPACE = "http://protege.stanford.edu/system#";
  static final String ROLE = "role";
  static final String ABSTRACT = "abstract";
  static final String INVERSEPROPERTY = "inverseProperty";
  static final String ASSOCIATEDFACET = "associatedFacet"; // FACET
  static final String HASFACET = "hasFacet"; // FACET
  static final String RANGE = "range";
  static final String ANY = "any";
  static final String BOOLEAN = "boolean";
  static final String CLS = "cls";
  static final String FLOAT = "float";
  static final String INSTANCE = "instance";
  static final String INTEGER = "integer";
  static final String STRING = "string";
  static final String SYMBOL = "symbol";
  static final String ALLOWEDCLASSES = "allowedClasses";
  static final String ALLOWEDPARENTS = "allowedParents";
  static final String ALLOWEDVALUES = "allowedValues";
  static final String DEFAULTVALUES = "defaultValues";
  static final String VALUES = "values";
  static final String MINCARDINALITY = "minCardinality";
  static final String MAXCARDINALITY = "maxCardinality";
  static final String MINVALUE = "minValue";
  static final String MAXVALUE = "maxValue";
  static final String OVERRIDINGPROPERTY = "OverridingProperty";
  static final String DOMAIN = "domain";
  static final String OVERRIDDENPROPERTY = "overriddenProperty";

}


