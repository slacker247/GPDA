/*
 * The contents of this file are subject to the Mozilla Public License
 * Version 1.1 (the "License");  you may not use this file except in compliance
 * with the License.  You may obtain a copy of the License at
 * http://www.mozilla.org/MPL/
 *
 * Software distributed under the License is distributed on an "AS IS" basis,
 * WITHOUT WARRANTY OF ANY KIND, either express or implied. See the License for
 * the specific language governing rights and limitations under the License.
 *
 * The Original Code is Protege-2000.
 *
 * The Initial Developer of the Original Code is Stanford University. Portions
 * created by Stanford University are Copyright (C) 2001.  All Rights Reserved.
 *
 * Protege-2000 was developed by Stanford Medical Informatics
 * (http://www.smi.stanford.edu) at the Stanford University School of Medicine
 * with support from the National Library of Medicine, the National Science
 * Foundation, and the Defense Advanced Research Projects Agency.  Current
 * information about Protege can be obtained at http://protege.stanford.edu
 *
 * Contributor(s):
 */

package edu.stanford.smi.protegex.widget.diagram;

import edu.stanford.smi.protege.model.*;
import edu.stanford.smi.protegex.util.*;
import javax.swing.event.*;
import javax.swing.*;
import javax.swing.table.*;
import java.awt.event.*;
import java.awt.*;
import java.util.*;

/**
 *  Description of the class
 *
 * @author    William Grosso <grosso@smi.stanford.edu>
 */
public abstract class ObjectEditingPanel extends JPanel {
    protected ColorWell _textColorWell;
    protected ColorWell _glyphColorWell;
    protected DiagramObjectState _diagramObjectState;
    protected DiagramWidgetState _widgetState;
    protected TablePanelModel _tablePanelModel;
    protected JCheckBox _displayTextCheckBox;
    protected JCheckBox _boldTextCheckBox;
    protected JCheckBox _italicTextCheckBox;
    protected JCheckBox _verticalCenteringTextCheckBox;
    protected JCheckBox _horizontalCenteringTextCheckBox;
    protected boolean _editUnderWay;

    protected abstract class GatedTextListener implements ActionListener {
        public void actionPerformed(ActionEvent e) {
            if (!_editUnderWay) {
                _editUnderWay = true;
                makeChange();
                _editUnderWay = false;
            }
        }

        protected abstract void makeChange();
    }

    private class DisplayTextListener extends GatedTextListener {
        protected void makeChange() {
            boolean isDisplayText = _displayTextCheckBox.isSelected();
            _diagramObjectState.setDisplayText(isDisplayText);
            setSecondaryTextBoxesEnabled(isDisplayText);
        }
    }

    private class BoldTextListener extends GatedTextListener {
        protected void makeChange() {
            _diagramObjectState.setBoldText(_boldTextCheckBox.isSelected());
        }
    }

    private class ItalicTextListener extends GatedTextListener {
        protected void makeChange() {
            _diagramObjectState.setItalicText(_italicTextCheckBox.isSelected());
        }
    }

    private class VerticallyCenteredTextListener extends GatedTextListener {
        protected void makeChange() {
            _diagramObjectState.setVerticallyCenteredText(_verticalCenteringTextCheckBox.isSelected());
        }
    }

    private class HorizontallyCenteredTextListener extends GatedTextListener {
        protected void makeChange() {
            _diagramObjectState.setHorizontallyCenteredText(_horizontalCenteringTextCheckBox.isSelected());
        }
    }

    private class GlyphColorChangeListener implements ActionListener {
        public void actionPerformed(ActionEvent e) {
            if (!_editUnderWay) {
                _editUnderWay = true;
                Color newColor = _glyphColorWell.getColor();
                _diagramObjectState.setObjectColor(newColor);
                _tablePanelModel.fireTableChanged(new TableModelEvent(_tablePanelModel));
                _editUnderWay = false;
            }
        }
    }

    private class TextColorChangeListener implements ActionListener {
        public void actionPerformed(ActionEvent e) {
            if (!_editUnderWay) {
                _editUnderWay = true;
                Color newColor = _textColorWell.getColor();
                _diagramObjectState.setTextColor(newColor);
                _editUnderWay = false;
            }
        }
    }

    public ObjectEditingPanel(DiagramWidget widget, TablePanelModel tablePanelModel, int numberOfEntries) {
        super(new GridLayout(numberOfEntries + 7, 1));
        _tablePanelModel = tablePanelModel;
        _widgetState = widget.getState();
        addGlyphColorPanel();
        addTextColorPanel();
        addTextProperties();
    }

    private void addBoldTextPanel() {
        _boldTextCheckBox = addLabeledCheckBox("Use Bold Text");
        _boldTextCheckBox.addActionListener(new BoldTextListener());
    }

    private void addDisplayTextPanel() {
        _displayTextCheckBox = addLabeledCheckBox("Display Text");
        _displayTextCheckBox.addActionListener(new DisplayTextListener());
    }

    private void addGlyphColorPanel() {
        JPanel colorPanel = new JPanel(new BorderLayout());
        JLabel label = new JLabel("Glyph Color");
        label.setPreferredSize(new Dimension(80, 30));

        _glyphColorWell = new ColorWell(Color.blue, new GlyphColorChangeListener());
        colorPanel.add(label, BorderLayout.WEST);
        colorPanel.add(_glyphColorWell, BorderLayout.CENTER);
        add(colorPanel);
    }

    private void addHorizontalCenteringTextPanel() {
        _horizontalCenteringTextCheckBox = addLabeledCheckBox("Horizontally Center Displayed Text");
        _horizontalCenteringTextCheckBox.addActionListener(new HorizontallyCenteredTextListener());
    }

    private void addItalicTextPanel() {
        _italicTextCheckBox = addLabeledCheckBox("Use Italicized Text");
        _italicTextCheckBox.addActionListener(new ItalicTextListener());
    }

    protected JCheckBox addLabeledCheckBox(String label) {
        JPanel containerPanel = new JPanel(new BorderLayout());
        JCheckBox returnValue = new JCheckBox(label);
        containerPanel.add(returnValue, BorderLayout.CENTER);
        add(containerPanel);
        return returnValue;
    }

    private void addTextColorPanel() {
        JPanel colorPanel = new JPanel(new BorderLayout());
        JLabel label = new JLabel("Text Color");
        label.setPreferredSize(new Dimension(80, 30));

        _textColorWell = new ColorWell(Color.blue, new TextColorChangeListener());
        colorPanel.add(label, BorderLayout.WEST);
        colorPanel.add(_textColorWell, BorderLayout.CENTER);
        add(colorPanel);
    }

    private void addTextProperties() {
        addDisplayTextPanel();
        addBoldTextPanel();
        addItalicTextPanel();
        addVerticalCenteringTextPanel();
        addHorizontalCenteringTextPanel();
    }

    private void addVerticalCenteringTextPanel() {
        _verticalCenteringTextCheckBox = addLabeledCheckBox("Vertically Center Displayed Text");
        _verticalCenteringTextCheckBox.addActionListener(new VerticallyCenteredTextListener());
    }

    protected abstract DiagramObjectState getStateObjectForCls(Cls cls);

    public void resetDisplay() {
        if (_diagramObjectState == null) {
            return;
        }
        boolean isDisplayText = _diagramObjectState.isDisplayText();
        _displayTextCheckBox.setSelected(isDisplayText);
        _boldTextCheckBox.setSelected(_diagramObjectState.isBoldText());
        _italicTextCheckBox.setSelected(_diagramObjectState.isItalicText());
        _verticalCenteringTextCheckBox.setSelected(_diagramObjectState.isVerticallyCenteredText());
        _horizontalCenteringTextCheckBox.setSelected(_diagramObjectState.isHorizontallyCenteredText());
        setSecondaryTextBoxesEnabled(isDisplayText);
        _glyphColorWell.setColor(_diagramObjectState.getObjectColor());
        _textColorWell.setColor(_diagramObjectState.getTextColor());
    }

    private void setSecondaryTextBoxesEnabled(boolean enabled) {
        if (enabled) {
            _boldTextCheckBox.setEnabled(enabled);
            _italicTextCheckBox.setEnabled(enabled);
            _verticalCenteringTextCheckBox.setEnabled(enabled);
            _horizontalCenteringTextCheckBox.setEnabled(enabled);
        }
    }

    public void setValue(Cls cls) {
        if (!_editUnderWay) {
            _editUnderWay = true;
            _diagramObjectState = getStateObjectForCls(cls);
            resetDisplay();
            _editUnderWay = false;
        }
    }
}
