/*
 * The contents of this file are subject to the Mozilla Public License
 * Version 1.1 (the "License");  you may not use this file except in compliance
 * with the License.  You may obtain a copy of the License at
 * http://www.mozilla.org/MPL/
 *
 * Software distributed under the License is distributed on an "AS IS" basis,
 * WITHOUT WARRANTY OF ANY KIND, either express or implied. See the License for
 * the specific language governing rights and limitations under the License.
 *
 * The Original Code is Protege-2000.
 *
 * The Initial Developer of the Original Code is Stanford University. Portions
 * created by Stanford University are Copyright (C) 2001.  All Rights Reserved.
 *
 * Protege-2000 was developed by Stanford Medical Informatics
 * (http://www.smi.stanford.edu) at the Stanford University School of Medicine
 * with support from the National Library of Medicine, the National Science
 * Foundation, and the Defense Advanced Research Projects Agency.  Current
 * information about Protege can be obtained at http://protege.stanford.edu
 *
 * Contributor(s):
 */

package edu.stanford.smi.protegex.widget.diagram;

import edu.stanford.smi.protegex.layout.*;
import edu.stanford.smi.protegex.util.*;

import edu.stanford.smi.protege.widget.*;
import edu.stanford.smi.protege.model.*;
import edu.stanford.smi.protege.ui.*;
import edu.stanford.smi.protege.util.*;
import javax.swing.*;
import java.util.*;
import java.awt.event.*;
import java.awt.*;

/**
 *  Description of the class
 *
 * @author    William Grosso <grosso@smi.stanford.edu>
 */
public class MiniwindowActivationPanel extends AbstractWidgetConfigurationPanel {
    protected ButtonInformationPanel _classBasedHiderPanel;
    protected ButtonInformationPanel _reusableFormPanel;
    protected ButtonInformationPanel _legendPanel;
    protected ButtonInformationPanel _thumbnailPanel;
    protected ButtonInformationPanel _flowchartPanel;
    protected ButtonInformationPanel _wirebuilderPanel;
    protected ButtonInformationPanel _zoomWindowPanel;

    protected JPanel _mainPanel;
    private DiagramWidgetState _diagramWidgetState;

    private class DisplayClassBasedHiderButtonListener implements ActionListener {
        public void actionPerformed(ActionEvent e) {
            _diagramWidgetState.setDisplayClassBasedHiderButton(_classBasedHiderPanel.isEnabled());
            _diagramWidgetState.setClassBasedHiderButtonTooltip(_classBasedHiderPanel.getTooltip());
        }
    }

    private class DisplayReusableFormButtonListener implements ActionListener {
        public void actionPerformed(ActionEvent e) {
            _diagramWidgetState.setDisplayReusableFormButton(_reusableFormPanel.isEnabled());
            _diagramWidgetState.setReusableFormButtonTooltip(_reusableFormPanel.getTooltip());
        }
    }

    private class DisplayLegendButtonListener implements ActionListener {
        public void actionPerformed(ActionEvent e) {
            _diagramWidgetState.setDisplayLegendButton(_legendPanel.isEnabled());
            _diagramWidgetState.setLegendButtonTooltip(_legendPanel.getTooltip());
        }
    }

    private class DisplayThumbnailButtonListener implements ActionListener {
        public void actionPerformed(ActionEvent e) {
            _diagramWidgetState.setDisplayThumbnailButton(_thumbnailPanel.isEnabled());
            _diagramWidgetState.setThumbnailButtonTooltip(_thumbnailPanel.getTooltip());
        }
    }

    //PM
    private class DisplayFlowchartButtonListener implements ActionListener {
        public void actionPerformed(ActionEvent e) {
            _diagramWidgetState.setDisplayFlowchartButton(_thumbnailPanel.isEnabled());
            _diagramWidgetState.setFlowchartButtonTooltip(_thumbnailPanel.getTooltip());
        }
    }

    private class DisplayWireBuilderButtonListener implements ActionListener {
        public void actionPerformed(ActionEvent e) {
            _diagramWidgetState.setDisplayWirebuilderButton(_wirebuilderPanel.isEnabled());
            _diagramWidgetState.setWirebuilderButtonTooltip(_wirebuilderPanel.getTooltip());
        }
    }

    public MiniwindowActivationPanel(DiagramWidgetState state) {
        super(state);
    }

    protected void buildButtonSelectionPanel(int yPosition) {
        _mainPanel = new JPanel(new GridLayout(6, 1, 0, 10));

        _classBasedHiderPanel =
            new ButtonInformationPanel(
                "Class-based Hider Button",
                _diagramWidgetState.isDisplayClassBasedHiderButton(),
                _diagramWidgetState.getClassBasedHiderButtonTooltip());
        _classBasedHiderPanel.addActionListener(new DisplayClassBasedHiderButtonListener());

        _reusableFormPanel =
            new ButtonInformationPanel(
                "Reusable Form Button",
                _diagramWidgetState.isDisplayReusableFormButton(),
                _diagramWidgetState.getReusableFormButtonTooltip());
        _reusableFormPanel.addActionListener(new DisplayReusableFormButtonListener());

        _legendPanel =
            new ButtonInformationPanel(
                "Legend Button",
                _diagramWidgetState.isDisplayLegendButton(),
                _diagramWidgetState.getLegendButtonTooltip());
        _legendPanel.addActionListener(new DisplayLegendButtonListener());

        _thumbnailPanel =
            new ButtonInformationPanel(
                "Thumbnail Button",
                _diagramWidgetState.isDisplayThumbnailButton(),
                _diagramWidgetState.getThumbnailButtonTooltip());
        _thumbnailPanel.addActionListener(new DisplayThumbnailButtonListener());

        _flowchartPanel =
            new ButtonInformationPanel(
                "Flowchart Button",
                _diagramWidgetState.isDisplayFlowchartButton(),
                _diagramWidgetState.getFlowchartButtonTooltip());
        _flowchartPanel.addActionListener(new DisplayFlowchartButtonListener());

        _wirebuilderPanel =
            new ButtonInformationPanel(
                "Wire Builder Button",
                _diagramWidgetState.isDisplayWirebuilderButton(),
                _diagramWidgetState.getWirebuilderButtonTooltip());
        _wirebuilderPanel.addActionListener(new DisplayWireBuilderButtonListener());

        _mainPanel.add(_classBasedHiderPanel);
        _mainPanel.add(_reusableFormPanel);
        _mainPanel.add(_legendPanel);
        _mainPanel.add(_thumbnailPanel);
        _mainPanel.add(_flowchartPanel);
        _mainPanel.add(_wirebuilderPanel);
        _mainPanel.setBorder(BorderFactory.createEtchedBorder());
        LabeledComponent componentToAdd = new LabeledComponent("Miniwindow Buttons", _mainPanel);
        add(componentToAdd, buildComponentGridBagConstraints(yPosition));
    }

    protected void buildGUI() {
        _diagramWidgetState = (DiagramWidgetState) _state;
        buildButtonSelectionPanel(1);
        addVerticalSpace(2);
    }
}
