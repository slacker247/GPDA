/*
 * The contents of this file are subject to the Mozilla Public License
 * Version 1.1 (the "License");  you may not use this file except in compliance
 * with the License.  You may obtain a copy of the License at
 * http://www.mozilla.org/MPL/
 *
 * Software distributed under the License is distributed on an "AS IS" basis,
 * WITHOUT WARRANTY OF ANY KIND, either express or implied. See the License for
 * the specific language governing rights and limitations under the License.
 *
 * The Original Code is Protege-2000.
 *
 * The Initial Developer of the Original Code is Stanford University. Portions
 * created by Stanford University are Copyright (C) 2001.  All Rights Reserved.
 *
 * Protege-2000 was developed by Stanford Medical Informatics
 * (http://www.smi.stanford.edu) at the Stanford University School of Medicine
 * with support from the National Library of Medicine, the National Science
 * Foundation, and the Defense Advanced Research Projects Agency.  Current
 * information about Protege can be obtained at http://protege.stanford.edu
 *
 * Contributor(s):
 */

package edu.stanford.smi.protegex.widget.instancetable;

import edu.stanford.smi.protege.model.*;
import edu.stanford.smi.protege.widget.*;
import edu.stanford.smi.protege.util.*;
import javax.swing.event.*;
import javax.swing.*;
import java.util.*;
import java.awt.*;

/**
 *  Static methods to make sure that InstanceTable is valid. Returns a string. A
 *  null return value means "okay"
 *
 * @author    William Grosso <grosso@smi.stanford.edu>
 */
public class InstanceTableConfigurationChecks {

    public static boolean checkValidity(Cls cls, Slot slot) {
        if ((null == cls) || (null == slot)) {
            return false;
        }
        boolean returnValue = true;
        returnValue = returnValue && slotTargetOfTypeInstance(cls, slot);
        returnValue = returnValue && slotHasRightCardinality(cls, slot);
        // returnValue = returnValue && singleAllowedClass(cls, slot);
        return returnValue;
    }

    public static JComponent getDetailedWarnings(Cls cls, Slot slot) {
        JTextArea returnValue = new JTextArea();
        boolean noErrorsFound = singleAllowedClass(cls, slot, returnValue);
        if (noErrorsFound) {
            returnValue.setForeground(Color.black);
            returnValue.setText("The widget seems to be correctly configured.");
        }
        return returnValue;
    }

    public static JComponent getShortWarning(Cls cls, Slot slot) {
        if (checkValidity(cls, slot)) {
            return null;
        }
        JTextField returnValue = new JTextField();
        returnValue.setForeground(Color.red);
        returnValue.setText("Widget incorrectly configured. See Forms Layout Panel for details.");
        return returnValue;
    }

    protected static boolean singleAllowedClass(Cls cls, Slot slot) {
        if (1 != (cls.getTemplateSlotAllowedClses(slot)).size()) {
            return false;
        }
        return true;
    }

    protected static boolean singleAllowedClass(Cls cls, Slot slot, JTextArea warningDisplayArea) {
        if (false == singleAllowedClass(cls, slot)) {
            warningDisplayArea.setForeground(Color.red);
            warningDisplayArea.append("The slot must have a single allowed class. \n");
            return false;
        }
        return true;
    }

    protected static boolean slotHasRightCardinality(Cls cls, Slot slot) {
        if (false == cls.getTemplateSlotAllowsMultipleValues(slot)) {
            return false;
        }
        return true;
    }

    protected static boolean slotHasRightCardinality(Cls cls, Slot slot, JTextArea warningDisplayArea) {
        if (false == slotHasRightCardinality(cls, slot)) {
            warningDisplayArea.setForeground(Color.red);
            warningDisplayArea.append("The slot must be a multiple-valued slot. \n");
            return false;
        }
        return true;
    }

    // validity checks
    protected static boolean slotTargetOfTypeInstance(Cls cls, Slot slot) {
        if (cls.getTemplateSlotValueType(slot) != ValueType.INSTANCE) {
            return false;
        }
        return true;
    }

    // configuration checks
    protected static boolean slotTargetOfTypeInstance(Cls cls, Slot slot, JTextArea warningDisplayArea) {
        if (false == slotTargetOfTypeInstance(cls, slot)) {
            warningDisplayArea.setForeground(Color.red);
            warningDisplayArea.append("The Target of the slot must be of type instance. \n");
            return false;
        }
        return true;
    }
}
