/*
 * The contents of this file are subject to the Mozilla Public License
 * Version 1.1 (the "License");  you may not use this file except in compliance
 * with the License.  You may obtain a copy of the License at
 * http://www.mozilla.org/MPL/
 *
 * Software distributed under the License is distributed on an "AS IS" basis,
 * WITHOUT WARRANTY OF ANY KIND, either express or implied. See the License for
 * the specific language governing rights and limitations under the License.
 *
 * The Original Code is Protege-2000.
 *
 * The Initial Developer of the Original Code is Stanford University. Portions
 * created by Stanford University are Copyright (C) 2001.  All Rights Reserved.
 *
 * Protege-2000 was developed by Stanford Medical Informatics
 * (http://www.smi.stanford.edu) at the Stanford University School of Medicine
 * with support from the National Library of Medicine, the National Science
 * Foundation, and the Defense Advanced Research Projects Agency.  Current
 * information about Protege can be obtained at http://protege.stanford.edu
 *
 * Contributor(s):
 */

package edu.stanford.smi.protegex.widget.graph;

// java
import java.awt.Color;
import java.awt.Point;

// nwoods
import com.nwoods.jgo.JGoLinkLabel;
import com.nwoods.jgo.JGoText;
import com.nwoods.jgo.JGoView;

// stanford
import edu.stanford.smi.protege.model.Cls;
import edu.stanford.smi.protege.model.Instance;
import edu.stanford.smi.protege.model.Slot;
import edu.stanford.smi.protege.model.ValueType;

public class ComplexLinkLabel extends JGoLinkLabel {

    public ComplexLinkLabel() {
        setAlignment(JGoText.ALIGN_CENTER);
        setDraggable(false);
        setSelectable(true);
        setEditable(true);
        setEditOnSingleClick(true);

        // Partly transparent white.
        setBkColor(new Color(255, 255, 255, 200));

        setTransparent(false);
    }

    public void doEndEdit() {
        ComplexLink cLink = (ComplexLink) getLabeledLink();
        Instance instance = cLink.getInstance();
        Cls cls = instance.getDirectType();
        Slot slot = cls.getBrowserSlot();
        instance.setOwnSlotValue(slot, getText());

        // Call super.doEndEdit so that the JTextComponent will go away.
        super.doEndEdit();
    }

    public void doStartEdit(JGoView view, Point vc) {
        ComplexLink cLink = (ComplexLink) getLabeledLink();
        Instance instance = cLink.getInstance();
        Cls cls = instance.getDirectType();
        Slot slot = cls.getBrowserSlot();

        // Don't allow the user to perform in-place editing if:
        // 1. They haven't specified a browser key.
        // 2. The slot is not of type string.
        if ((slot.getName() == ":NAME") || (slot.getValueType() != ValueType.STRING)) {
            setEditable(false);
        } else {
            super.doStartEdit(view, vc);
        }
    }
}