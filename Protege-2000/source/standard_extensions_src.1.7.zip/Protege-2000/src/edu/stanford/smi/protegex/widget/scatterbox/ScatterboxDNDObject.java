/*
 * The contents of this file are subject to the Mozilla Public License
 * Version 1.1 (the "License");  you may not use this file except in compliance
 * with the License.  You may obtain a copy of the License at
 * http://www.mozilla.org/MPL/
 *
 * Software distributed under the License is distributed on an "AS IS" basis,
 * WITHOUT WARRANTY OF ANY KIND, either express or implied. See the License for
 * the specific language governing rights and limitations under the License.
 *
 * The Original Code is Protege-2000.
 *
 * The Initial Developer of the Original Code is Stanford University. Portions
 * created by Stanford University are Copyright (C) 2001.  All Rights Reserved.
 *
 * Protege-2000 was developed by Stanford Medical Informatics
 * (http://www.smi.stanford.edu) at the Stanford University School of Medicine
 * with support from the National Library of Medicine, the National Science
 * Foundation, and the Defense Advanced Research Projects Agency.  Current
 * information about Protege can be obtained at http://protege.stanford.edu
 *
 * Contributor(s):
 */

package edu.stanford.smi.protegex.widget.scatterbox;

import edu.stanford.smi.protege.model.*;
import java.awt.datatransfer.*;
import java.awt.dnd.*;
import java.awt.*;

/**
 *  Description of the class
 *
 * @author    William Grosso <grosso@smi.stanford.edu>
 */
public class ScatterboxDNDObject {
    protected ScatterboxWidget _widget;
    protected ScatterboxTable _underlyingTable;
    protected DataFlavor _flavor;
    protected Cls _entryCls;
    protected KBQueryUtils _queryUtilsObject;

    public ScatterboxDNDObject(ScatterboxWidget widget, ScatterboxTable underlyingTable, KBQueryUtils queryUtilsObject) {
        _queryUtilsObject = queryUtilsObject;
        _widget = widget;
        try {
            _flavor = new DataFlavor(DataFlavor.javaJVMLocalObjectMimeType);
        } catch (Exception e) {
        }
        _underlyingTable = underlyingTable;
        _entryCls = _queryUtilsObject.getEntryCls(_widget.getCls());
    }

    protected Point getTableLocationForEvent(DragGestureEvent dragGestureEvent) {
        Point dragStartPoint = dragGestureEvent.getDragOrigin();
        int column = _underlyingTable.columnAtPoint(dragStartPoint);
        int row = _underlyingTable.rowAtPoint(dragStartPoint);
        if ((row < 0) || (column < 0)) {
            return null;
        }
        return new Point(row, column);
    }

    protected void putEntryAtPoint(Instance entry, Point tableLocation) {
        Order horizontalOrder = _widget.getHorizontalOrder();
        Order verticalOrder = _widget.getVerticalOrder();
        Instance domainObject = _queryUtilsObject.getDomainObject(entry);
        horizontalOrder.fillObjectWithIndexedValue(domainObject, tableLocation.y);
        verticalOrder.fillObjectWithIndexedValue(domainObject, tableLocation.x);
        _widget.addEntry(entry);
    }
}
