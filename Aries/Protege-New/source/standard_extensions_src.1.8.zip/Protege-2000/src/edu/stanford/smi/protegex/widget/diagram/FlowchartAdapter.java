/*
 * The contents of this file are subject to the Mozilla Public License
 * Version 1.1 (the "License");  you may not use this file except in compliance
 * with the License.  You may obtain a copy of the License at
 * http://www.mozilla.org/MPL/
 *
 * Software distributed under the License is distributed on an "AS IS" basis,
 * WITHOUT WARRANTY OF ANY KIND, either express or implied. See the License for
 * the specific language governing rights and limitations under the License.
 *
 * The Original Code is Protege-2000.
 *
 * The Initial Developer of the Original Code is Stanford University. Portions
 * created by Stanford University are Copyright (C) 2001.  All Rights Reserved.
 *
 * Protege-2000 was developed by Stanford Medical Informatics
 * (http://www.smi.stanford.edu) at the Stanford University School of Medicine
 * with support from the National Library of Medicine, the National Science
 * Foundation, and the Defense Advanced Research Projects Agency.  Current
 * information about Protege can be obtained at http://protege.stanford.edu
 *
 * Contributor(s):
 */

package edu.stanford.smi.protegex.widget.diagram;

import java.awt.event.*;

import javax.swing.event.*;

import edu.stanford.smi.protege.event.*;
import edu.stanford.smi.protege.model.*;

/**
 *  Description of the class
 *
 * @author    William Grosso <grosso@smi.stanford.edu>
 */
public class FlowchartAdapter implements Constants,
        ActionListener,
        ListSelectionListener,
        FrameListener,
        ClsListener {

    private OptionsFlowchartPanel _options;
    private PreviewFlowchartPanel _preview;

    //  private int _numConnectors;
    public FlowchartAdapter(OptionsFlowchartPanel options, PreviewFlowchartPanel preview) {
        _options = options;
        _preview = preview;
        //    _numConnectors = _options.getNumConnectors();
    }

    public void actionPerformed(ActionEvent e) {
        // Checkbox event.
        _preview.setGraph(null);
    }

    public void browserTextChanged(FrameEvent p0) {
    }

    public void deleted(FrameEvent p0) {
    }

    public void directInstanceCreated(ClsEvent p0) {
        Instance connector = p0.getInstance();
        connector.addFrameListener(this);
    }

    public void directInstanceDeleted(ClsEvent p0) {
        Instance connector = p0.getInstance();
        connector.addFrameListener(this);
    }

    public void directSubclassAdded(ClsEvent p0) {
    }

    public void directSubclassMoved(ClsEvent p0) {
    }

    public void directSubclassRemoved(ClsEvent p0) {
    }

    public void directSuperclassAdded(ClsEvent p0) {
    }

    public void directSuperclassRemoved(ClsEvent p0) {
    }

    public void nameChanged(FrameEvent p0) {
    }

    public void ownFacetAdded(FrameEvent p0) {
    }

    public void ownFacetRemoved(FrameEvent p0) {
    }

    public void ownFacetValueChanged(FrameEvent p0) {
    }

    public void ownSlotAdded(FrameEvent p0) {
    }

    public void ownSlotRemoved(FrameEvent p0) {
    }

    public void ownSlotValueChanged(FrameEvent p0) {
        Slot slotAffected = p0.getSlot();
        String slotName = slotAffected.getName();
        if (slotName.equals(LAYOUT_INFORMATION_SLOT)) {
            // Node affected.
            _options.resetRoots();
        } else if (slotName.equals(CONNECTORS_SLOT)) {
            // Wire affected.
            _preview.setGraph(null);
        } else if (slotName.equals(FIRST_OBJECT_SLOT_NAME)) {
            _preview.setGraph(null);
        } else if (slotName.equals(SECOND_OBJECT_SLOT_NAME)) {
            _preview.setGraph(null);
        }
    }

    public void templateFacetAdded(ClsEvent p0) {
    }

    public void templateFacetRemoved(ClsEvent p0) {
    }

    public void templateFacetValueChanged(ClsEvent p0) {
    }

    public void templateSlotAdded(ClsEvent p0) {
    }

    public void templateSlotRemoved(ClsEvent p0) {
    }

    public void templateSlotValueChanged(ClsEvent p0) {
    }

    public void valueChanged(ListSelectionEvent e) {
        // List selection event.
        _preview.setGraph(null);
    }

    public void visibilityChanged(FrameEvent e) {
        /*
         * This is a frame event, new in Protege 1.4; we need to think about
         * whether or not it matters here
         */
    }
}
