/*
 * The contents of this file are subject to the Mozilla Public License
 * Version 1.1 (the "License");  you may not use this file except in compliance
 * with the License.  You may obtain a copy of the License at
 * http://www.mozilla.org/MPL/
 *
 * Software distributed under the License is distributed on an "AS IS" basis,
 * WITHOUT WARRANTY OF ANY KIND, either express or implied. See the License for
 * the specific language governing rights and limitations under the License.
 *
 * The Original Code is Protege-2000.
 *
 * The Initial Developer of the Original Code is Stanford University. Portions
 * created by Stanford University are Copyright (C) 2001.  All Rights Reserved.
 *
 * Protege-2000 was developed by Stanford Medical Informatics
 * (http://www.smi.stanford.edu) at the Stanford University School of Medicine
 * with support from the National Library of Medicine, the National Science
 * Foundation, and the Defense Advanced Research Projects Agency.  Current
 * information about Protege can be obtained at http://protege.stanford.edu
 *
 * Contributor(s):
 */

package edu.stanford.smi.protegex.widget.slider;

import edu.stanford.smi.protege.model.*;
import edu.stanford.smi.protege.widget.*;
import edu.stanford.smi.protege.util.*;
import java.util.*;
import edu.stanford.smi.protege.event.*;

/**
 *  This is the "state" for the sliderwidget.
 *
 * @author    William Grosso <grosso@smi.stanford.edu>
 */
public class SliderProperties extends Observable {
    private final String displayTicksKey = ":SliderWidget:Display-Ticks";
    private final String tickIncrementKey = ":SliderWidget:Tick-Increment";

    private Boolean _displayTicks;
    private Integer _tickIncrement;
    private PropertyList _properties;
    private Cls _cls;
    private Slot _slot;
    private ListensToClass _classChangeListener;

    private class ListensToClass implements ClsListener {
        public void directInstanceCreated(ClsEvent event) {
        }

        public void directInstanceDeleted(ClsEvent event) {
        }

        public void directSubclassAdded(ClsEvent event) {
        }

        public void directSubclassRemoved(ClsEvent event) {
        }

        public void directSubclassMoved(ClsEvent event) {
        }

        public void directSuperclassAdded(ClsEvent event) {
        }

        public void directSuperclassRemoved(ClsEvent event) {
        }

        public void templateFacetAdded(ClsEvent event) {
        }

        public void templateFacetRemoved(ClsEvent event) {
        }

        public void templateSlotAdded(ClsEvent event) {
        }

        public void templateSlotValueChanged(ClsEvent event) {
        }

        public void directSubclassesReordered(ClsEvent p0) {
        }

        public void templateFacetValueChanged(ClsEvent event) {
            broadcast();
        }

        public void templateSlotRemoved(ClsEvent event) {
            if ((event.getSlot()).equals(_slot)) {
                _cls.removeClsListener(_classChangeListener);
            }
        }
    }

    public SliderProperties(PropertyList properties, Cls cls, Slot slot) {
        _properties = properties;
        _cls = cls;
        _slot = slot;
        _classChangeListener = new ListensToClass();
        _cls.addClsListener(_classChangeListener);
        restore();
    }

    private void broadcast() {
        setChanged();
        notifyObservers();
    }

    public void dispose() {
        _classChangeListener = null;
    }

    public int getMaximum() {
        return ((Integer) _cls.getTemplateSlotMaximumValue(_slot)).intValue();
    }

    public int getMinimum() {
        return ((Integer) _cls.getTemplateSlotMinimumValue(_slot)).intValue();
    }

    // and a whole lot of get/set methods
    public int getTickIncrement() {
        return _tickIncrement.intValue();
    }

    public boolean isDisplayTicks() {
        return _displayTicks.booleanValue();
    }

    public void restore() {
        _displayTicks = _properties.getBoolean(displayTicksKey);
        _tickIncrement = _properties.getInteger(tickIncrementKey);

        // default values
        if (null == _displayTicks) {
            _displayTicks = new Boolean(true);
        }
        if (null == _tickIncrement) {
            _tickIncrement = new Integer(1);
        }
    }

    public void save() {
        _properties.setBoolean(displayTicksKey, _displayTicks);
        _properties.setInteger(tickIncrementKey, _tickIncrement);
        broadcast();
    }

    public void setDisplayTicks(Boolean displayTicks) {
        _displayTicks = displayTicks;
    }

    public void setDisplayTicks(boolean displayTicks) {
        _displayTicks = new Boolean(displayTicks);
    }

    public void setTickIncrement(int tickIncrement) {
        _tickIncrement = new Integer(tickIncrement);
    }

    public void setTickIncrement(Integer tickIncrement) {
        _tickIncrement = tickIncrement;
    }
}
