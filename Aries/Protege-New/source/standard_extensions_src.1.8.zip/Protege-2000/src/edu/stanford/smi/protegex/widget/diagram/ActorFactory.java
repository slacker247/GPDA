/*
 * The contents of this file are subject to the Mozilla Public License
 * Version 1.1 (the "License");  you may not use this file except in compliance
 * with the License.  You may obtain a copy of the License at
 * http://www.mozilla.org/MPL/
 *
 * Software distributed under the License is distributed on an "AS IS" basis,
 * WITHOUT WARRANTY OF ANY KIND, either express or implied. See the License for
 * the specific language governing rights and limitations under the License.
 *
 * The Original Code is Protege-2000.
 *
 * The Initial Developer of the Original Code is Stanford University. Portions
 * created by Stanford University are Copyright (C) 2001.  All Rights Reserved.
 *
 * Protege-2000 was developed by Stanford Medical Informatics
 * (http://www.smi.stanford.edu) at the Stanford University School of Medicine
 * with support from the National Library of Medicine, the National Science
 * Foundation, and the Defense Advanced Research Projects Agency.  Current
 * information about Protege can be obtained at http://protege.stanford.edu
 *
 * Contributor(s):
 */

package edu.stanford.smi.protegex.widget.diagram;

import java.awt.*;

import edu.stanford.smi.protegex.layout.*;

/**
 *  Description of the Class
 *
 * @author    William Grosso <grosso@smi.stanford.edu>
 */
public class ActorFactory implements Constants {

    private static WireActorInstance buildWire(
        AnimationContext placeToPutWire,
        String wireSymbol,
        Color wireColor,
        String startingArrow,
        String endingArrow,
        String title,
        DiagramWidget widget,
        WireState state) {
        WireActorInstance returnValue;

        WireGlyph actorWire = new WireGlyph(wireSymbol, wireColor, startingArrow, endingArrow, title, true, true);
        ActorLocation location = new ActorLocation(new Point(0, 0), DEFAULT_NODE_HEIGHT, DEFAULT_NODE_HEIGHT, null);

        returnValue = new WireActorInstance(actorWire, placeToPutWire, location, null, null, null, widget, state);
        StandardActorEventHandler sath =
            new StandardActorEventHandler(returnValue, new WireResizingHandler(returnValue), new WireDraggingHandler(returnValue));

        sath.setIsSelectable(true);
        sath.setIsDraggable(true);
        sath.setIsResizable(true);
        returnValue.setEventHandler(sath);

        returnValue.setMovementHandler(new StandardActorMovementHandler(returnValue));

        returnValue.setControlPointHandler(
            new WireControlPointHandler(WIRE_CONTROLPOINT_PRECISION, WIRE_MINIMUM_SIZE, returnValue));
        placeToPutWire.addActorToTop(returnValue);
        return returnValue;
    }

    public static GlyphActorInstance createIcon(
        NodeState state,
        AnimationContext placeToPutActor,
        String title,
        DiagramWidget widget) {
        GlyphActorInstance returnValue;

        Color objectColor = state.getObjectColor();
        Color textColor = state.getTextColor();
        String whichSymbol = state.getNodeStyle();
        IconGlyph actorImage = new IconGlyph(whichSymbol, objectColor, textColor, true, title);

        ActorLocation location = new ActorLocation(new Point(0, 0), DEFAULT_NODE_WIDTH, DEFAULT_NODE_HEIGHT, null);
        returnValue = new GlyphActorInstance(actorImage, placeToPutActor, location, null, null, null, state, widget);
        returnValue.setEventHandler(new StandardActorEventHandler(returnValue));
        returnValue.setMovementHandler(new StandardActorMovementHandler(returnValue));
        returnValue.setControlPointHandler(
            new ImageControlPointHandler(IMAGE_CONTROLPOINT_PRECISION, IMAGE_MINIMUM_SIZE, returnValue));
        returnValue.setIsSelectable(true);
        returnValue.setIsDraggable(true);
        returnValue.setIsResizable(true);
        placeToPutActor.addActorToTop(returnValue);
        if (placeToPutActor instanceof TilingAnimationFrame) {
            returnValue.setAlwaysDisplayText(true);
        }
        return returnValue;
    }

    public static WireActorInstance createWire(
        WireState state,
        AnimationContext placeToPutWire,
        String title,
        DiagramWidget widget) {
        String wireSymbol = state.getWireType();
        Color wireColor = state.getObjectColor();
        String startingArrow = state.getStartingArrow();
        String endingArrow = state.getEndingArrow();
        WireActorInstance returnValue =
            buildWire(placeToPutWire, wireSymbol, wireColor, startingArrow, endingArrow, title, widget, state);

        returnValue.setBounces(false);
        returnValue.setIsSelectable(true);
        returnValue.setIsDraggable(true);
        returnValue.setIsResizable(true);
        if (placeToPutWire instanceof TilingAnimationFrame) {
            returnValue.setAlwaysDisplayText(true);
        }
        return returnValue;
    }

    public static void main(String[] args) {
        edu.stanford.smi.protege.Application.main(args);
    }
}
