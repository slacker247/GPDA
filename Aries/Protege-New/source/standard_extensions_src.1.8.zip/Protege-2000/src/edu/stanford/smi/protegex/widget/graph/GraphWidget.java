/*
 * The contents of this file are subject to the Mozilla Public License
 * Version 1.1 (the "License");  you may not use this file except in compliance
 * with the License.  You may obtain a copy of the License at
 * http://www.mozilla.org/MPL/
 *
 * Software distributed under the License is distributed on an "AS IS" basis,
 * WITHOUT WARRANTY OF ANY KIND, either express or implied. See the License for
 * the specific language governing rights and limitations under the License.
 *
 * The Original Code is Protege-2000.
 *
 * The Initial Developer of the Original Code is Stanford University. Portions
 * created by Stanford University are Copyright (C) 2001.  All Rights Reserved.
 *
 * Protege-2000 was developed by Stanford Medical Informatics
 * (http://www.smi.stanford.edu) at the Stanford University School of Medicine
 * with support from the National Library of Medicine, the National Science
 * Foundation, and the Defense Advanced Research Projects Agency.  Current
 * information about Protege can be obtained at http://protege.stanford.edu
 *
 * Contributor(s):
 */

package edu.stanford.smi.protegex.widget.graph;

// java
import java.awt.BorderLayout;
import java.awt.Point;
import java.awt.event.ActionEvent;
import java.net.URL;
import javax.swing.ImageIcon;
import javax.swing.JPanel;
import javax.swing.JSplitPane;
import java.util.ArrayList;
import java.util.Collection;
import java.util.Iterator;

// jgo
import com.nwoods.jgo.JGoBrush;
import com.nwoods.jgo.JGoDocument;
import com.nwoods.jgo.JGoListPosition;
import com.nwoods.jgo.JGoObject;
import com.nwoods.jgo.JGoSelection;
import com.nwoods.jgo.JGoViewEvent;
import com.nwoods.jgo.JGoViewListener;
import com.nwoods.jgo.layout.JGoLayeredDigraphAutoLayout;

// stanford
import edu.stanford.smi.protege.model.Cls;
import edu.stanford.smi.protege.model.Facet;
import edu.stanford.smi.protege.model.Instance;
import edu.stanford.smi.protege.model.KnowledgeBase;
import edu.stanford.smi.protege.model.Slot;
import edu.stanford.smi.protege.model.ValueType;
import edu.stanford.smi.protege.resource.Icons;
import edu.stanford.smi.protege.ui.DisplayUtilities;
import edu.stanford.smi.protege.util.AddAction;
import edu.stanford.smi.protege.util.AllowableAction;
import edu.stanford.smi.protege.util.CreateAction;
import edu.stanford.smi.protege.util.LabeledComponent;
import edu.stanford.smi.protege.util.PropertyList;
import edu.stanford.smi.protege.widget.AbstractSlotWidget;
import edu.stanford.smi.protege.widget.WidgetConfigurationPanel;

public class GraphWidget extends AbstractSlotWidget {
    private JPanel mainPanel = new JPanel(new BorderLayout(0, 2));
    private JSplitPane splitPane;

    private GraphPalette palette;
    private GraphView view;
    private GraphDocument doc;

    private KnowledgeBase kb;
    private Instance currentInstance;
    private Slot slot;
    private PropertyList pList;
    private LabeledComponent labeledComponent;

    private boolean paletteStuffed = false;
    private boolean docInitialized = false;

    private AllowableAction createInstanceAction;
    private AllowableAction viewSelectedInstancesAction;
    private AllowableAction addExistingInstancesAction;
    private AllowableAction deleteSelectedInstancesAction;
    private AllowableAction performAutomaticLayoutAction;
    private AllowableAction performAutomaticLayoutRightAction;

    // HACK
    Collection currentValues;

    public GraphWidget() {
        setPreferredColumns(4);
        setPreferredRows(4);
    }

    public void initialize() {
        kb = getKnowledgeBase();
        slot = getSlot();
        pList = getPropertyList();

        palette = new GraphPalette();

        view = new GraphView(pList, getSlot(), getCls());
        view.addViewListener(new JGoViewListener() {
            public void viewChanged(JGoViewEvent e) {
                processViewChange(e);
            }
        });

        if (isDesignTime()) {
            view.getDocument().setModifiable(false);
        }

        // Populate the split pane.
        splitPane = new JSplitPane(JSplitPane.HORIZONTAL_SPLIT, palette, view);

        // Populate the main panel.
        mainPanel.add(splitPane, BorderLayout.CENTER);
        labeledComponent = new LabeledComponent(getLabel(), mainPanel, true);
        addButtons(labeledComponent);
        add(labeledComponent);
    }

    public void addNotify() {
        super.addNotify();

        // Populate the diagram's palette.
        if (!paletteStuffed) {
            stuffPalette();
            paletteStuffed = true;
        }

        // This is part of a temporary hack which is described in detail
        // inside of the setValues method.
        if (!docInitialized) {
            Instance instance = getInstance();
            if (instance != currentInstance) {
                currentInstance = instance;
                doc = new GraphDocument(kb, pList, currentInstance, slot);
                doc.initNodes(currentValues);
                view.setInstance(currentInstance);
                view.setDocument(doc);
            }
            docInitialized = true;
        }
    }

    public void setValues(Collection c) {
        Instance instance = getInstance();

        /** @todo This is a necessary hack.  Can't initialize the document
         *  until the view is showing.  However, sometimes this is the case
         *  when setValues is called, sometimes it's the case when addNotify
         *  is called.  The real fix needs to be elsewhere in the protege
         *  forms code. Ideally, this method wouldn't be called until all the
         *  components are visible. */
        currentValues = c;
        if (view.isShowing()) {
            if (instance != currentInstance) {
                currentInstance = instance;
                doc = new GraphDocument(kb, pList, currentInstance, slot);
                doc.initNodes(c);
                view.setInstance(currentInstance);
                view.setDocument(doc);
            }
            docInitialized = true;
        } else {
            // Need to initialize the document inside of addNotify instead.
            docInitialized = false;
        }

        // This is how the code might look after a solution is found to the
        // problem mentioned above.  (All of the document initialization code
        // would be removed from the addNotify method as well).

        /*if ((view.isShowing()) && (instance != currentInstance)) {
            currentInstance = instance;

            doc = new DiagramDocument(kb, pList, currentInstance, slot);
            doc.initNodes(c);

            view.setInstance(currentInstance);
            view.setDocument(doc);
        }*/
    }

    public static boolean isSuitable(Cls cls, Slot slot, Facet facet) {
        boolean isSuitable;
        if (cls == null || slot == null) {
            isSuitable = false;
        } else {
            boolean isInstance = cls.getTemplateSlotValueType(slot) == ValueType.INSTANCE;
            boolean isMultiple = cls.getTemplateSlotAllowsMultipleValues(slot);
            isSuitable = isInstance && isMultiple;
        }
        return isSuitable;
    }

    public void handleViewSelectedInstances() {
        JGoSelection selectedObjects = view.getSelection();
        JGoListPosition pos = selectedObjects.getFirstObjectPos();
        while (pos != null) {
            Instance instance = null;
            JGoObject obj = selectedObjects.getObjectAtPos(pos);
            if (obj instanceof Node) {
                Node node = (Node) obj;
                instance = node.getInstance();
            } else if (obj instanceof ComplexLink) {
                // Include instances of ComplexLink here since they also
                // represent instances in the kb.
                ComplexLink cl = (ComplexLink) obj;
                instance = cl.getInstance();
            }

            if (instance != null) {
                getProject().show(instance);
            }

            pos = selectedObjects.getNextObjectPosAtTop(pos);
        }
    }

    public void handleCreateInstance() {
        if (slot != null) {
            KnowledgeBase kb = getKnowledgeBase();

            int xPos = view.getGridOrigin().x + 10;
            int yPos = view.getGridOrigin().y + 10;

            Collection c = DisplayUtilities.pickClses(this, slot.getAllowedClses());
            Iterator i = c.iterator();
            while (i.hasNext()) {
                Cls cls = (Cls) i.next();
                if (cls.isConcrete()) {

                    // Add new node to diagram.
                    String name = cls.getName();
                    Node node = makeNewNode(name, new Point(xPos, yPos));
                    Instance instance = kb.createInstance(null, cls);
                    node.setInstance(instance);
                    node.setText(instance.getBrowserText());
                    node.setSize(GraphTypes.NODE_WIDTH, GraphTypes.NODE_HEIGHT);
                    doc.addObjectAtTail(node);

                    currentInstance.addOwnSlotValue(slot, instance);

                    xPos = xPos + 10;
                    yPos = yPos + 10;
                }
            }
        }
    }

    public void handleAddExistingInstance() {
        if (slot != null) {
            int xPos = view.getGridOrigin().x + 10;
            int yPos = view.getGridOrigin().y + 10;

            Collection instances = DisplayUtilities.pickInstances(this, slot.getAllowedClses());
            Iterator i = instances.iterator();
            while (i.hasNext()) {
                Instance instance = (Instance) i.next();

                // Add new node to diagram.
                String name = instance.getDirectType().getName();
                Node node = makeNewNode(name, new Point(xPos, yPos));
                node.setInstance(instance);
                node.setText(instance.getBrowserText());
                node.setSize(GraphTypes.NODE_WIDTH, GraphTypes.NODE_HEIGHT);

                currentInstance.addOwnSlotValue(slot, instance);

                doc.addObjectAtTail(node);
                xPos = xPos + 10;
                yPos = yPos + 10;
            }
        }
    }

    public void handleDeleteSelectedInstances() {
        JGoSelection selectedObjects = view.getSelection();
        JGoListPosition pos = selectedObjects.getFirstObjectPos();
        while (pos != null) {
            JGoObject obj = selectedObjects.getObjectAtPos(pos);
            if (obj instanceof Node) {
                Node node = (Node) obj;
                Instance instance = node.getInstance();
                getKnowledgeBase().deleteInstance(instance);
            }
            pos = selectedObjects.getNextObjectPosAtTop(pos);
        }

        view.deleteSelection();
    }

    public void onPerformAutomaticLayout(int direction) {
        doc.performAutomaticLayout(direction);
    }

    private void addButtons(LabeledComponent lb) {
        // View button.
        viewSelectedInstancesAction = new AllowableAction("View Selected Instances", Icons.getViewIcon(), null) {
            public void actionPerformed(ActionEvent ae) {
                handleViewSelectedInstances();
            }
        };
        lb.addHeaderButton(viewSelectedInstancesAction);

        // Create button.
        createInstanceAction = new CreateAction("Create Instance") {
            public void onCreate() {
                handleCreateInstance();
            }
        };
        lb.addHeaderButton(createInstanceAction);

        // Add button.
        addExistingInstancesAction = new AddAction("Add Existing Instance") {
            public void onAdd() {
                handleAddExistingInstance();
            }
        };
        lb.addHeaderButton(addExistingInstancesAction);

        // Delete button.
        deleteSelectedInstancesAction = new AllowableAction("Delete Selected Instances", Icons.getDeleteIcon(), null) {
            public void actionPerformed(ActionEvent ae) {
                handleDeleteSelectedInstances();
            }
        };
        lb.addHeaderButton(deleteSelectedInstancesAction);

        URL url = GraphWidget.class.getResource("images/Flowchart.gif");
        ImageIcon icon = new ImageIcon(url);
        performAutomaticLayoutAction = new AllowableAction("Perform Automatic Layout", icon, null) {
            public void actionPerformed(ActionEvent ae) {
                onPerformAutomaticLayout(JGoLayeredDigraphAutoLayout.LD_DIRECTION_DOWN);
            }
        };
        lb.addHeaderButton(performAutomaticLayoutAction);

        url = GraphWidget.class.getResource("images/FlowchartRight.gif");
        icon = new ImageIcon(url);
        performAutomaticLayoutRightAction = new AllowableAction("Perform Automatic Layout", icon, null) {
            public void actionPerformed(ActionEvent ae) {
                onPerformAutomaticLayout(JGoLayeredDigraphAutoLayout.LD_DIRECTION_RIGHT);
            }
        };
        lb.addHeaderButton(performAutomaticLayoutRightAction);
    }

    public WidgetConfigurationPanel createWidgetConfigurationPanel() {
        GraphConfigurationPanel dwcp = new GraphConfigurationPanel(this);
        return dwcp;
    }

    private void stuffPalette() {
        ArrayList nodes = new ArrayList();
        ArrayList allowedClses = new ArrayList(slot.getAllowedClses());
        for (int i=0; i<allowedClses.size(); i++) {
            Cls cls = (Cls) allowedClses.get(i);
            if (cls.isConcrete()) {
                nodes.add(cls);
            }

            ArrayList subClses = new ArrayList(cls.getSubclasses());
            for (int j=0; j<subClses.size(); j++) {
                Cls subCls = (Cls) subClses.get(j);
                if (subCls.isConcrete()) {
                    nodes.add(subCls);
                }
            }
        }

        for (int i=0; i<nodes.size(); i++) {
            Cls cls = (Cls) nodes.get(i);
            String clsName = cls.getName();

            Node node = makeNewNode(clsName, new Point());

            JGoDocument doc = palette.getDocument();
            doc.addObjectAtTail(node);
        }

        // Need to call this here - otherwise nodes aren't properly
        // positioned in a couple of obscure cases.
        palette.layoutItems();
    }

    private Node makeNewNode(String name, Point point) {
        Node node = new Node();

        // Initialize.
        NodeProperties props = new NodeProperties(name, pList);
        String shape = props.getShape();
        node.initialize(point, shape, name);

        // Set the node's color.
        node.setBrush(JGoBrush.makeStockBrush(props.getShapeColor()));

        // Set the node's size.
        node.setSize(GraphTypes.NODE_WIDTH, GraphTypes.NODE_HEIGHT);

        // Set the node's text properties.
        node.getLabel().setTextColor(props.getTextColor());
        node.getLabel().setBold(props.isBold());
        node.getLabel().setItalic(props.isItalic());

        // Set the node's connector slot.
        String connectorSlot = props.getConnectorSlot();
        if (connectorSlot != null) {
            node.setConnectorSlot(connectorSlot);
        }

        return node;
    }

    public void processViewChange(JGoViewEvent e) {
        /** @todo See if we can call savePositionInfo() on a subset
         *  of view change events instead of all of them. */

        // DEBUG:
        //System.out.println("JGoViewEvent flag is: " + e.getFlags());
        //System.out.println("JGoViewEvent hint is: " + e.getHint());
        //System.out.println("");

        if (doc != null) { doc.savePositionInfo(); }
    }

    public void setEditable(boolean b) {
        if (doc != null) {
            doc.setModifiable(b);
        }

        setAllowed(createInstanceAction, b);
        setAllowed(addExistingInstancesAction, b);
        setAllowed(deleteSelectedInstancesAction, b);
        setAllowed(performAutomaticLayoutAction, b);
        setAllowed(performAutomaticLayoutRightAction, b);
    }

    public GraphDocument getDocument() {
        return doc;
    }

    public GraphView getView() {
        return view;
    }
}