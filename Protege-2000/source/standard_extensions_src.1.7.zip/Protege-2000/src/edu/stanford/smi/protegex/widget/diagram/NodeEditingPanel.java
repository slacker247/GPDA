/*
 * The contents of this file are subject to the Mozilla Public License
 * Version 1.1 (the "License");  you may not use this file except in compliance
 * with the License.  You may obtain a copy of the License at
 * http://www.mozilla.org/MPL/
 *
 * Software distributed under the License is distributed on an "AS IS" basis,
 * WITHOUT WARRANTY OF ANY KIND, either express or implied. See the License for
 * the specific language governing rights and limitations under the License.
 *
 * The Original Code is Protege-2000.
 *
 * The Initial Developer of the Original Code is Stanford University. Portions
 * created by Stanford University are Copyright (C) 2001.  All Rights Reserved.
 *
 * Protege-2000 was developed by Stanford Medical Informatics
 * (http://www.smi.stanford.edu) at the Stanford University School of Medicine
 * with support from the National Library of Medicine, the National Science
 * Foundation, and the Defense Advanced Research Projects Agency.  Current
 * information about Protege can be obtained at http://protege.stanford.edu
 *
 * Contributor(s):
 */

package edu.stanford.smi.protegex.widget.diagram;

import edu.stanford.smi.protegex.layout.*;

import edu.stanford.smi.protege.model.*;
import javax.swing.event.*;
import javax.swing.*;
import javax.swing.table.*;
import java.awt.event.*;
import java.awt.*;
import java.util.*;

/**
 *  Description of the class
 *
 * @author    William Grosso <grosso@smi.stanford.edu>
 */
public class NodeEditingPanel extends ObjectEditingPanel {
    private JComboBox _shapeComboBox;
    private NodeState _nodeState;

    private class ShapeListener implements ActionListener {
        public void actionPerformed(ActionEvent e) {
            if (!_editUnderWay) {
                _editUnderWay = true;
                _nodeState.setNodeStyle((String) _shapeComboBox.getSelectedItem());
                _tablePanelModel.fireTableChanged(new TableModelEvent(_tablePanelModel));
                _editUnderWay = false;
            }
        }
    }

    public NodeEditingPanel(DiagramWidget widget, TablePanelModel tablePanelModel) {
        super(widget, tablePanelModel, 1);
        addShapePanel();
    }

    private void addShapePanel() {
        JPanel shapePanel = new JPanel(new BorderLayout());

        JLabel label = new JLabel("Shape");
        label.setPreferredSize(new Dimension(80, 30));
        _shapeComboBox = new JComboBox(NodeConstants.STYLE_NAMES);
        _shapeComboBox.setSelectedIndex(0);
        shapePanel.add(label, BorderLayout.WEST);
        shapePanel.add(_shapeComboBox, BorderLayout.CENTER);
        add(shapePanel);
        _shapeComboBox.addActionListener(new ShapeListener());
    }

    protected DiagramObjectState getStateObjectForCls(Cls cls) {
        _nodeState = _widgetState.getStateForNode(cls);
        return _nodeState;
    }

    public void resetDisplay() {
        if (_nodeState == null) {
            return;
        }
        super.resetDisplay();
        _shapeComboBox.setSelectedItem(_nodeState.getNodeStyle());
    }
}
