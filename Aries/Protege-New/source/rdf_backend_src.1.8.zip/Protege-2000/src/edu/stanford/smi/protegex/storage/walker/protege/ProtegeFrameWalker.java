/*
 * The contents of this file are subject to the Mozilla Public License
 * Version 1.1 (the "License");  you may not use this file except in compliance
 * with the License.  You may obtain a copy of the License at
 * http://www.mozilla.org/MPL/
 *
 * Software distributed under the License is distributed on an "AS IS" basis,
 * WITHOUT WARRANTY OF ANY KIND, either express or implied. See the License for
 * the specific language governing rights and limitations under the License.
 *
 * The Original Code is Protege-2000.
 *
 * The Initial Developer of the Original Code is Stanford University. Portions
 * created by Stanford University are Copyright (C) 2001.  All Rights Reserved.
 *
 * Protege-2000 was developed by Stanford Medical Informatics
 * (http://www.smi.stanford.edu) at the Stanford University School of Medicine
 * with support from the National Library of Medicine, the National Science
 * Foundation, and the Defense Advanced Research Projects Agency.  Current
 * information about Protege can be obtained at http://protege.stanford.edu
 *
 * Contributor(s):
 */

package edu.stanford.smi.protegex.storage.walker.protege;

import java.util.*;

import edu.stanford.smi.protege.model.*;
import edu.stanford.smi.protegex.storage.walker.*;


public class ProtegeFrameWalker implements FrameWalker {

  public KnowledgeBase _kb;
  public Namespaces _namespaces;
  public FrameCreator _creator;
  public ProtegeFrames _wframes;

  public ProtegeFrameWalker(KnowledgeBase kb, Namespaces namespaces) {
    _kb = kb;
    _namespaces = namespaces;
  }

  public void walk(FrameCreator frameCreator) {
    _creator = frameCreator;
    _wframes = newProtegeFrames();
    _creator.start();
    walkClasses();
    walkInstances();
    walkSlots();
    walkSlotAttachments();
    walkValues();
    _creator.finish();
  }

  public ProtegeFrames newProtegeFrames() {
    return new ProtegeFrames(_kb, _namespaces, _creator);
  }


  // classes

  void walkClasses() {
    Collection classes = _kb.getClses();
    for (Iterator classIterator = classes.iterator();
         classIterator.hasNext();) {
      Cls cls = (Cls)classIterator.next();
      if (exportFrame(cls) && !rdfSystemFrame(cls)) {
        Cls type = cls.getDirectType();
	if (type == null) { // whould never happen!
	  System.err.println("WARNING: class has no direct type: " + cls);
	  type = _kb.getDefaultClsMetaCls();
	}
        Collection superclasses = cls.getDirectSuperclasses();
	boolean abstrct = cls.isAbstract();
	String documentation = getDocumentation(cls);
        _creator.createCls(wframe(cls), wframes(superclasses), 
	  wframe(type), abstrct, documentation);
      }
    }
  }


  // instances (without own slot values)
  // needed before slots because of template slot and default values

  void walkInstances() {
    Collection instances = _kb.getInstances();
    for (Iterator instanceIterator = instances.iterator();
	 instanceIterator.hasNext();) {
      Instance instance = (Instance)instanceIterator.next();
      if (instance instanceof SimpleInstance // no classes and slots
           // || instance instanceof Facet) // ??? FACET
	  && exportFrame(instance)) {
        Cls type = instance.getDirectType();
	if (type == null) { // whould never happen!
	  System.err.println("WARNING: instance has no direct type: " +
	    instance);
	  type = _kb.getRootCls(); // use :THING
	}
	String documentation = getDocumentation(instance);
	_creator.createInstance(wframe(instance), wframe(type), documentation);
      }
    }
  }


  // slots

  void walkSlots() {
    Collection slots = _kb.getSlots();
    for (Iterator slotIterator = slots.iterator();
         slotIterator.hasNext();) {
      Slot slot = (Slot)slotIterator.next();
      if (exportFrame(slot)) {
        Cls type = slot.getDirectType();
	if (type == null) { // whould never happen!
	  System.err.println("WARNING: slot has no direct type: " + slot);
	  type = _kb.getDefaultSlotMetaCls();
	}
        Collection superslots = slot.getDirectSuperslots();
        Slot inverseSlot = slot.getInverseSlot();
	String documentation = getDocumentation(slot);
	ProtegeSlotRestriction slotRestriction =
	  new ProtegeSlotRestriction(_wframes, slot);
	if (slotRestriction.isInstance() && _creator.singleAllowedClass()) {
	  // _creator wants a single allowed class
	  Collection allowedClasses = slot.getAllowedClses();
	  WalkerFrame commonSuperclass = 
	    wframe(getCommonSuperclass(allowedClasses));
	  slotRestriction.setAllowedClass(commonSuperclass);
	}
	Facet associatedFacet = slot.getAssociatedFacet(); // FACET
        _creator.createSlot(wframe(slot), wframe(type),
          wframes(superslots), wframe(inverseSlot), wframe(associatedFacet),
          slotRestriction, documentation);
      }
    }
  }


  // slot attachments

  void walkSlotAttachments() {
    Collection classes = _kb.getClses();
    for (Iterator classIterator = classes.iterator();
         classIterator.hasNext();) {
      Cls cls = (Cls)classIterator.next();
      if (exportFrame(cls)) {
	Collection templateSlots = cls.getTemplateSlots();
	for (Iterator tsIterator = templateSlots.iterator();
	     tsIterator.hasNext();) {
	  Slot templateSlot = (Slot)tsIterator.next();
	  if (cls.hasDirectTemplateSlot(templateSlot) ||
	      (hasDirectlyOverriddenTemplateSlot(cls, templateSlot))) {
	    if (!exportFrame(templateSlot)) {
	      // this breaks the restrictions of included slots
	      // so do this only for system slots:
	      if (templateSlot.isSystem()) { // e.g., :NAME
		// this slot has not been exported, so do it now;
		// the type is enough, the rest is in the imported project
		Cls type = templateSlot.getDirectType();
		_creator.createSlot(wframe(templateSlot), wframe(type),
		  null, null, null, null, null);
              }
	    }
	    ProtegeSlotRestriction overriddenSlotRestriction = null;
	    String overriddenDocumentation = null;
	    // see above for hasOverriddenTemplateSlot!!!
	    if (hasDirectlyOverriddenTemplateSlot(cls, templateSlot)) {
	      overriddenSlotRestriction = 
		new ProtegeSlotRestriction(_wframes, cls, templateSlot);
	      if (overriddenSlotRestriction.isInstance() 
		  && _creator.singleAllowedClass()) {
		// _creator wants a single allowed class
		Collection allowedClasses = 
		  cls.getTemplateSlotAllowedClses(templateSlot);
		WalkerFrame commonSuperclass = 
		  wframe(getCommonSuperclass(allowedClasses));
		overriddenSlotRestriction.setAllowedClass(commonSuperclass);
	      }
	      Collection docu = cls.getTemplateSlotDocumentation(templateSlot);
	      overriddenDocumentation = getDocumentation(docu);
	    }
            _creator.attachSlot(wframe(cls), wframe(templateSlot), 
	      cls.hasDirectTemplateSlot(templateSlot),
	      overriddenSlotRestriction, overriddenDocumentation);
	  }
	}
      }
    }
  }


  // own slot values (for all instances incl. classes and slots)

  void walkValues() {
    Collection instances = _kb.getInstances();
    for (Iterator instanceIterator = instances.iterator();
	 instanceIterator.hasNext();) {
      Instance instance = (Instance)instanceIterator.next();
      if (exportFrame(instance)) { // ALL instances (even classes etc.)
	WalkerFrame instanceFrame = wframe(instance);
	Collection ownSlots = instance.getOwnSlots();
	for (Iterator osIterator = ownSlots.iterator();
	     osIterator.hasNext();) {
	  Slot slot = (Slot)osIterator.next();
	  // if (!slot.isSystem()) { // not correct ??? !!! XXX
	  if (exportSlotValues(slot)) {
	    // (we have to check for the "missing" system properties
	    // like label and isDefinedBy ... !!!
	    Collection values = instance.getOwnSlotValues(slot);
	    if (values != null && !values.isEmpty())
	      _creator.addOwnSlotValues(
	        instanceFrame, wframe(slot), wframes(values));
	  }
	}
      }
    }
  }


  // auxiliaries

  WalkerFrame wframe(Frame frame) {
    return (WalkerFrame)_wframes.wframe(frame);
  }

  Collection wframes(Collection frames) {
    return _wframes.wframes(frames);
  }

  public boolean exportFrame(Frame frame) {
    return !frame.isIncluded();
  }

  public boolean exportSlotValues(Slot slot) {
    String name = slot.getName();
    return !slot.isSystem()
      // export slots on :STANDARD-FACET  // FACET
      // || name.equals(":ASSOCIATED-SLOT") // ????
      // export slots on :INSTANCE-ANNOTATION
      || name.equals(":ANNOTATED-INSTANCE")
      || name.equals(":ANNOTATION-TEXT")
      || name.equals(":CREATION-TIMESTAMP")
      || name.equals(":CREATOR")
      // export slots for constraints
      || name.equals(":SLOT-CONSTRAINTS")
      || name.startsWith(":PAL-");
  }

  boolean rdfSystemFrame(Frame frame) {
    // this allows us to exclude rdf[s] classes to be exported
    // (esp. those from projects created with the old backend,
    //  but also those created on load like rdfs:Literal)
    String name = frame.getName();
    // we assume that the namespace abbreviations rdf and rdfs are
    // NEVER used as user namespaces!!!
    return name.startsWith("rdf:") || name.startsWith("rdfs:");
      // handle RDF Helper and URI???
  }

  String getDocumentation(Frame frame) {
    Collection docu = frame.getDocumentation();
    return getDocumentation(docu);
  }

  String getDocumentation(Collection docu) {
    if (docu == null || docu.isEmpty())
      return null;
    else if (docu.size() == 1)
      return (String)docu.iterator().next();
    else { // hack??? does this ever happen?
      StringBuffer documentation = new StringBuffer();
      for (Iterator docuIterator = docu.iterator();
	   docuIterator.hasNext();) {
	String docuString = (String)docuIterator.next();
	documentation.append(docuString);
	if (docuIterator.hasNext())
	  documentation.append("\n");
      }
      return documentation.toString();
    }
  }

  Cls getCommonSuperclass(Collection classes) {
    if (classes == null || classes.isEmpty())
      return null;
    else if (classes.size() == 1)
      return (Cls)classes.iterator().next();
    else {
      // 1. find common intersection of superclasses
      HashSet intersection = null;
      for (Iterator classIterator = classes.iterator();
	   classIterator.hasNext();) {
	Cls cls = (Cls)classIterator.next();
	HashSet superclasses = new HashSet(cls.getSuperclasses());
	superclasses.add(cls);
	if (intersection == null)
	  intersection = superclasses;
	else // intersect
	  intersection.retainAll(superclasses);
      }
      // 2. remove all classes that are superclasses of any other class
      if (intersection.size() > 1) {
	HashSet copiedIntersection = (HashSet)intersection.clone();
	for (Iterator classIterator = copiedIntersection.iterator();
	     classIterator.hasNext();) {
	  Cls cls = (Cls)classIterator.next();
	  intersection.removeAll(cls.getSuperclasses());
	  if (intersection.size() == 1) // finished
	    break;
	}
      }
      // 3. pick the first one (or: minimize path length ...)
      if (!intersection.isEmpty())
        return (Cls)intersection.iterator().next();
      else
	return null;
    }
  }


  boolean hasDirectlyOverriddenTemplateSlot(Cls cls, Slot templateSlot) {
    // because of a bug in Protege we have to exclude :ROLE 
    // (and also :DIRECT-TYPE)
    // remove this if bug is fixed ... !!!
    // (we cannot use "&& hasOverriddenTemplateSlot" since this also
    // has a bug when going back to the original slot definition)
    // this is not correct if someone really wants to override :ROLE!!!
    return cls.hasDirectlyOverriddenTemplateSlot(templateSlot)
      && !templateSlot.getName().equals(":ROLE")
      && !templateSlot.getName().equals(":DIRECT-TYPE");
  }


}


