/*
 * The contents of this file are subject to the Mozilla Public License
 * Version 1.1 (the "License");  you may not use this file except in compliance
 * with the License.  You may obtain a copy of the License at
 * http://www.mozilla.org/MPL/
 *
 * Software distributed under the License is distributed on an "AS IS" basis,
 * WITHOUT WARRANTY OF ANY KIND, either express or implied. See the License for
 * the specific language governing rights and limitations under the License.
 *
 * The Original Code is Protege-2000.
 *
 * The Initial Developer of the Original Code is Stanford University. Portions
 * created by Stanford University are Copyright (C) 2001.  All Rights Reserved.
 *
 * Protege-2000 was developed by Stanford Medical Informatics
 * (http://www.smi.stanford.edu) at the Stanford University School of Medicine
 * with support from the National Library of Medicine, the National Science
 * Foundation, and the Defense Advanced Research Projects Agency.  Current
 * information about Protege can be obtained at http://protege.stanford.edu
 *
 * Contributor(s):
 */

package edu.stanford.smi.protegex.widget.instancetable;

import java.util.*;

import edu.stanford.smi.protege.model.*;
import edu.stanford.smi.protegex.widget.abstracttable.*;

/**
 *  Description of the Class
 *
 * @author    William Grosso <grosso@smi.stanford.edu>
 */
public class InstanceTable extends AbstractTable {
    private InstanceTableModel _instanceTableModel;

    public InstanceTable(InstanceTableModel model, AbstractTableWidgetCellEditor editor, boolean highlightSelectedRow) {
        super(model, editor);
        _instanceTableModel = model;
        setDefaultRenderer(Object.class, new GenericTableCellRenderer(highlightSelectedRow));
    }

    public InstanceTable(InstanceTableModel model, boolean highlightSelectedRow) {
        this(model, null, highlightSelectedRow);
    }

    public int getRowForInstance(Instance instance) {
        return _instanceTableModel.getRowForInstance(instance);
    }

    public Collection getSelectedInstances() {
        ArrayList returnValue = new ArrayList();
        int[] selectedRows = getSelectedRows();
        int loop;
        for (loop = 0; loop < selectedRows.length; loop++) {
            returnValue.add(_instanceTableModel.getInstanceAt(selectedRows[loop]));
        }
        return returnValue;
    }

    public boolean isCellEditable(int row, int column) {
        if (null == _editor) {
            return false;
        }
        AbstractTableWidgetValue value = (AbstractTableWidgetValue) _model.getValueAt(row, column);
        Cls cls = (value.instance).getDirectType();
        if (cls.getTemplateSlotAllowsMultipleValues(value.slot)) {
            return false;
        }
        return true;
    }

    public void setEditor(AbstractTableWidgetCellEditor editor) {
        _editor = editor;
        if (_editor != null) {
            setRowSelectionAllowed(false);
            setColumnSelectionAllowed(false);
            setCellSelectionEnabled(true);
            setDefaultEditor(AbstractTableWidgetValue.class, editor);
        } else {
            setRowSelectionAllowed(true);
            setColumnSelectionAllowed(false);
        }
    }
}
