package protegex.prologtab.gnuprolog;

import gnu.prolog.vm.*;
import edu.stanford.smi.protege.model.*;

/**
 * Modify GNU Prolog version for use with PrologTab plugin.
 * Creation date: (4/29/2002 8:58:25 AM)
 * @author: 
 */
public class Environment extends gnu.prolog.vm.Environment {
	protected GNUPrologEngine _engine;
/**
 * Environment constructor comment.
 * @param systemInput java.io.Reader
 * @param systemOutput java.io.Writer
 * @param opSet gnu.prolog.io.OperatorSet
 * @param loadBuiltins boolean
 */
public Environment(java.io.Reader systemInput, java.io.Writer systemOutput, gnu.prolog.io.OperatorSet opSet, boolean loadBuiltins, GNUPrologEngine engine) {
	super(systemInput, systemOutput, opSet, loadBuiltins);
	_engine = engine;
}
/**
 * Insert the method's description here.
 * Creation date: (4/29/2002 10:17:40 AM)
 * @return protegex.gnuprolog.GNUPrologEngine
 */
public GNUPrologEngine getEngine() {
	return _engine;
}
}
