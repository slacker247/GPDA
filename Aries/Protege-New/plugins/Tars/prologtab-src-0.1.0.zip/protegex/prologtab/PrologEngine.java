package protegex.prologtab;

/**
 * Extend TripleDBAdapter to add Prolog engine functionality.
 * Creation date: (3/26/2002 9:52:09 AM)
 * @author: 
 */
public interface PrologEngine extends TripleDB {
/**
 * Return the Prolog source for the default engine built-ins.
 * Creation date: (4/24/2002 12:20:53 PM)
 * @return java.lang.String
 */
String getBuiltIns();
/**
 * Load a source module from an InputStream.
 * Creation date: (4/16/2002 11:38:08 AM)
 * @moduleName java.lang.String
 * @param inputStream java.io.InputStream
 * @exception java.io.IOException.
 */
void loadFrom(String moduleName, java.io.InputStream inputStream) throws java.io.IOException;
/**
 * Read a goal from a Reader.
 * Creation date: (4/11/2002 6:02:05 PM)
 * @return protegex.gnuprolog.PrologGoal
 * @param reader java.io.Reader
 */
PrologGoal readGoal(java.io.Reader reader) throws PrologTabException;
}
