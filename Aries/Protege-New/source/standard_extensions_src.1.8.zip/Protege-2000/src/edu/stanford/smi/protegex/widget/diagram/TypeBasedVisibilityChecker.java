/*
 * The contents of this file are subject to the Mozilla Public License
 * Version 1.1 (the "License");  you may not use this file except in compliance
 * with the License.  You may obtain a copy of the License at
 * http://www.mozilla.org/MPL/
 *
 * Software distributed under the License is distributed on an "AS IS" basis,
 * WITHOUT WARRANTY OF ANY KIND, either express or implied. See the License for
 * the specific language governing rights and limitations under the License.
 *
 * The Original Code is Protege-2000.
 *
 * The Initial Developer of the Original Code is Stanford University. Portions
 * created by Stanford University are Copyright (C) 2001.  All Rights Reserved.
 *
 * Protege-2000 was developed by Stanford Medical Informatics
 * (http://www.smi.stanford.edu) at the Stanford University School of Medicine
 * with support from the National Library of Medicine, the National Science
 * Foundation, and the Defense Advanced Research Projects Agency.  Current
 * information about Protege can be obtained at http://protege.stanford.edu
 *
 * Contributor(s):
 */

package edu.stanford.smi.protegex.widget.diagram;

import java.util.*;

import edu.stanford.smi.protege.model.*;
import edu.stanford.smi.protege.util.*;

/**
 *  Description of the Class
 *
 * @author    William Grosso <grosso@smi.stanford.edu>
 */
public class TypeBasedVisibilityChecker extends BaseVisibilityChecker {
    protected HashMap _hiddenClses;

    public TypeBasedVisibilityChecker() {
        _hiddenClses = new HashMap();
    }

    public TypeBasedVisibilityChecker(PropertyList properties, KnowledgeBase knowledgeBase) {
        resetFromPropertyList(properties, knowledgeBase);
    }

    protected TypeBasedVisibilityChecker(TypeBasedVisibilityChecker original) {
        _hiddenClses = (HashMap) ((original._hiddenClses).clone());
    }

    public Collection getHiddenClses() {
        return _hiddenClses.keySet();
    }

    public void hideCls(Cls cls) {
        _hiddenClses.put(cls, cls);
    }

    public void hideConnectorCls(Cls connectorCls) {
        hideCls(connectorCls);
    }

    public void hideNodeCls(Cls nodeCls) {
        hideCls(nodeCls);
        return;
    }

    public boolean isClsVisible(Cls cls) {
        if (null != _hiddenClses.get(cls)) {
            return false;
        }
        return true;
    }

    public boolean isConnectorClsVisible(Cls connectorCls) {
        return isClsVisible(connectorCls);
    }

    public boolean isConnectorVisible(Instance connectorInstance) {
        Cls cls = connectorInstance.getDirectType();
        if (!isClsVisible(cls)) {
            return false;
        }
        Instance source = DiagramUtilities.getFirstObject(connectorInstance);
        if ((null != source) && (!isNodeVisible(source))) {
            return false;
        }
        Instance target = DiagramUtilities.getSecondObject(connectorInstance);
        if ((null != target) && (!isNodeVisible(target))) {
            return false;
        }
        return true;
    }

    public boolean isNodeClsVisible(Cls nodeCls) {
        return isClsVisible(nodeCls);
    }

    public boolean isNodeVisible(Instance nodeInstance) {
        Cls cls = nodeInstance.getDirectType();
        return isClsVisible(cls);
    }

    public void recursivelyHideCls(Cls cls) {
        hideCls(cls);
        Collection subclasses = cls.getSubclasses();
        Iterator i = subclasses.iterator();
        while (i.hasNext()) {
            Cls nextCls = (Cls) i.next();
            hideCls(nextCls);
        }
        return;
    }

    public void recursivelyHideConnectorCls(Cls connectorCls) {
        recursivelyHideCls(connectorCls);
    }

    // strongly typed, possibly useful methods
    public void recursivelyHideNodeCls(Cls nodeCls) {
        recursivelyHideCls(nodeCls);
    }

    public void recursivelyUnhideCls(Cls cls) {
        hideCls(cls);
        Collection subclasses = cls.getSubclasses();
        Iterator i = subclasses.iterator();
        while (i.hasNext()) {
            Cls nextCls = (Cls) i.next();
            unhideCls(nextCls);
        }
        return;
    }

    public void recursivelyUnhideConnectorCls(Cls connectorCls) {
        recursivelyUnhideCls(connectorCls);
    }

    public void recursivelyUnhideNodeCls(Cls nodeCls) {
        recursivelyUnhideCls(nodeCls);
    }

    public void resetFromPropertyList(PropertyList properties, KnowledgeBase knowledgeBase) {
        _hiddenClses = new HashMap();
        Collection names = properties.getNames();
        Iterator i = names.iterator();
        while (i.hasNext()) {
            String nextName = (String) i.next();
            Cls nextCls = knowledgeBase.getCls(nextName);
            hideCls(nextCls);
        }
    }

    public void unhideCls(Cls cls) {
        _hiddenClses.remove(cls);
    }

    public void unhideConnectorCls(Cls connectorCls) {
        unhideCls(connectorCls);
    }

    public void unhideNodeCls(Cls nodeCls) {
        unhideCls(nodeCls);
        return;
    }

    public void writeToPropertyList(PropertyList properties) {
        properties.clear();
        Iterator i = (_hiddenClses.keySet()).iterator();
        while (i.hasNext()) {
            Cls nextCls = (Cls) i.next();
            properties.setString(nextCls.getName(), nextCls.getName());
        }
    }
}
