/*
 * The contents of this file are subject to the Mozilla Public License
 * Version 1.1 (the "License");  you may not use this file except in compliance
 * with the License.  You may obtain a copy of the License at
 * http://www.mozilla.org/MPL/
 *
 * Software distributed under the License is distributed on an "AS IS" basis,
 * WITHOUT WARRANTY OF ANY KIND, either express or implied. See the License for
 * the specific language governing rights and limitations under the License.
 *
 * The Original Code is Protege-2000.
 *
 * The Initial Developer of the Original Code is Stanford University. Portions
 * created by Stanford University are Copyright (C) 2001.  All Rights Reserved.
 *
 * Protege-2000 was developed by Stanford Medical Informatics
 * (http://www.smi.stanford.edu) at the Stanford University School of Medicine
 * with support from the National Library of Medicine, the National Science
 * Foundation, and the Defense Advanced Research Projects Agency.  Current
 * information about Protege can be obtained at http://protege.stanford.edu
 *
 * Contributor(s):
 */

package edu.stanford.smi.protegex.layout;

import java.awt.*;
import java.awt.event.*;

/**
 *  Description of the Class
 *
 * @author    William Grosso <grosso@smi.stanford.edu>
 */
public abstract class AbstractDragHandler {
    protected Actor _actor;
    protected ActorLocation _location;
    protected Point _oldMouseLocation;
    // location at last mouse event
    protected boolean _canBeActive;
    // is dragable
    protected boolean _isActive;

    // currently dragging
    public AbstractDragHandler(Actor actor) {
        _actor = actor;
        _location = actor.getLocation();
        _oldMouseLocation = new Point();
    }

    public Actor getActor() {
        return _actor;
    }

    public boolean getCanBeActive() {
        return _canBeActive;
    }

    public boolean getIsActive() {
        return _isActive;
    }

    // Only called on single selection.  Process incremental drag is called
    // on multiselects
    public void processDrag(MouseEvent e) {
        if (_isActive) {
            processDragging(e);
        } else {
            if (_canBeActive) {
                startDragging(e);
            }
        }
        return;
    }

    public abstract void processDragging(MouseEvent e);

    public void processIncrementalDrag(int deltaX, int deltaY) {
        _isActive = true;
        _location.translate(deltaX, deltaY);
        if (null != _oldMouseLocation) {
            _oldMouseLocation.x -= deltaX;
            _oldMouseLocation.y -= deltaY;
        }
    }

    public void processMouseRelease(MouseEvent e) {
        if (_isActive) {
            _isActive = false;
            return;
        }
    }

    public void setActor(Actor actor) {
        _actor = actor;
        _location = _actor.getLocation();
    }

    public void setCanBeActive(boolean canBeActive) {
        _canBeActive = canBeActive;
        return;
    }

    protected void startDragging(MouseEvent e) {
        _oldMouseLocation = null;
        _isActive = true;
        (_actor.getAnimationContext()).setSelectedActor(_actor);
        return;
    }

    public abstract boolean wantDrag(MouseEvent e);
}
