/*
 * The contents of this file are subject to the Mozilla Public License
 * Version 1.1 (the "License");  you may not use this file except in compliance
 * with the License.  You may obtain a copy of the License at
 * http://www.mozilla.org/MPL/
 *
 * Software distributed under the License is distributed on an "AS IS" basis,
 * WITHOUT WARRANTY OF ANY KIND, either express or implied. See the License for
 * the specific language governing rights and limitations under the License.
 *
 * The Original Code is Protege-2000.
 *
 * The Initial Developer of the Original Code is Stanford University. Portions
 * created by Stanford University are Copyright (C) 2001.  All Rights Reserved.
 *
 * Protege-2000 was developed by Stanford Medical Informatics
 * (http://www.smi.stanford.edu) at the Stanford University School of Medicine
 * with support from the National Library of Medicine, the National Science
 * Foundation, and the Defense Advanced Research Projects Agency.  Current
 * information about Protege can be obtained at http://protege.stanford.edu
 *
 * Contributor(s):
 */

package edu.stanford.smi.protegex.widget.diagram;

import edu.stanford.smi.protege.model.*;
import javax.swing.*;
import javax.swing.event.*;
import javax.swing.table.*;
import java.awt.event.*;
import java.awt.*;
import java.util.*;

/**
 *  Description of the class
 *
 * @author    William Grosso <grosso@smi.stanford.edu>
 */
public class WireEditingPanel extends ObjectEditingPanel {
    private JComboBox _shapeComboBox;
    private JComboBox _startingArrowBox;
    private JComboBox _endingArrowBox;
    private JCheckBox _anchoringCheckBox;

    private WireState _wireState;

    private class AnchoringListener extends GatedTextListener {
        protected void makeChange() {
            _wireState.setAnchorTextAtUpperLeftCorner(_anchoringCheckBox.isSelected());
        }
    }

    private class StartingArrowListener implements ActionListener {
        public void actionPerformed(ActionEvent e) {
            if (!_editUnderWay) {
                _editUnderWay = true;
                _wireState.setStartingArrow((String) _startingArrowBox.getSelectedItem());
                _tablePanelModel.fireTableChanged(new TableModelEvent(_tablePanelModel));
                _editUnderWay = false;
            }
        }
    }

    private class EndingArrowListener implements ActionListener {
        public void actionPerformed(ActionEvent e) {
            if (!_editUnderWay) {
                _editUnderWay = true;
                _wireState.setEndingArrow((String) _endingArrowBox.getSelectedItem());
                _tablePanelModel.fireTableChanged(new TableModelEvent(_tablePanelModel));
                _editUnderWay = false;
            }
        }
    }

    private class ShapeListener implements ActionListener {
        public void actionPerformed(ActionEvent e) {
            if (!_editUnderWay) {
                _editUnderWay = true;
                _wireState.setWireType((String) _shapeComboBox.getSelectedItem());
                _tablePanelModel.fireTableChanged(new TableModelEvent(_tablePanelModel));
                _editUnderWay = false;
            }
        }
    }

    public WireEditingPanel(DiagramWidget widget, TablePanelModel tablePanelModel) {
        super(widget, tablePanelModel, 4);
        addAnchoringCheckBox();
        addShapePanel();
        addStartingArrowPanel();
        addEndingArrowPanel();
    }

    private void addAnchoringCheckBox() {
        _anchoringCheckBox = addLabeledCheckBox("Anchor at the upper left corner of text");
        _anchoringCheckBox.addActionListener(new AnchoringListener());
    }

    private void addEndingArrowPanel() {
        JPanel endingingArrowPanel = new JPanel(new BorderLayout());
        JLabel label = new JLabel("Ending icon");
        label.setPreferredSize(new Dimension(80, 30));
        _endingArrowBox = new JComboBox(edu.stanford.smi.protegex.layout.WireUtilities.ARROW_NAMES);
        _endingArrowBox.setSelectedIndex(0);
        _endingArrowBox.addActionListener(new EndingArrowListener());
        endingingArrowPanel.add(label, BorderLayout.WEST);
        endingingArrowPanel.add(_endingArrowBox, BorderLayout.CENTER);
        add(endingingArrowPanel);
    }

    private void addShapePanel() {
        JPanel shapePanel = new JPanel(new BorderLayout());

        JLabel label = new JLabel("Shape");
        label.setPreferredSize(new Dimension(80, 30));
        _shapeComboBox = new JComboBox(edu.stanford.smi.protegex.layout.WireUtilities.STYLE_NAMES);
        _shapeComboBox.setSelectedIndex(0);
        shapePanel.add(label, BorderLayout.WEST);
        shapePanel.add(_shapeComboBox, BorderLayout.CENTER);
        add(shapePanel);
        _shapeComboBox.addActionListener(new ShapeListener());
    }

    private void addStartingArrowPanel() {
        JPanel startingArrowPanel = new JPanel(new BorderLayout());
        JLabel label = new JLabel("Starting icon");
        label.setPreferredSize(new Dimension(80, 30));
        _startingArrowBox = new JComboBox(edu.stanford.smi.protegex.layout.WireUtilities.ARROW_NAMES);
        _startingArrowBox.setSelectedIndex(0);
        _startingArrowBox.addActionListener(new StartingArrowListener());
        startingArrowPanel.add(label, BorderLayout.WEST);
        startingArrowPanel.add(_startingArrowBox, BorderLayout.CENTER);
        add(startingArrowPanel);
    }

    protected DiagramObjectState getStateObjectForCls(Cls cls) {
        _wireState = _widgetState.getStateForConnector(cls);
        return _wireState;
    }

    public void resetDisplay() {
        super.resetDisplay();
        if (_wireState == null) {
            return;
        }
        _anchoringCheckBox.setSelected(_wireState.isAnchorTextAtUpperLeftCorner());
        _shapeComboBox.setSelectedItem(_wireState.getWireType());
        _startingArrowBox.setSelectedItem(_wireState.getStartingArrow());
        _endingArrowBox.setSelectedItem(_wireState.getEndingArrow());
    }
}
