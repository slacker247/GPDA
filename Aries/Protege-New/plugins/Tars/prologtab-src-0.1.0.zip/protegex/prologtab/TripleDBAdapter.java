package protegex.prologtab;

import java.util.*;
import edu.stanford.smi.protege.model.*;
/**
 * Interface for updating frame-slot-value triples.
 * Creation date: (3/20/2002 8:57:53 PM)
 * @author: 
 */
public interface TripleDBAdapter {
	// :NAME and :DIRECT-TYPE slots are treated specially. This allows meta-level slots to
	// be treated consistent with instance level slots (no isTemplate value).
    public static final String NAME_SLOT_NAME = ":name";
    public static final String DIRECT_TYPE_SLOT_NAME = ":direct-type";
/**
 * Add new slot-value.
 * @param frame edu.stanford.smi.protege.model.Frame
 * @param slot edu.stanford.smi.protege.model.Slot
 * @param value java.lang.Object
 */
void addSlotValue(Frame frame, String slotName, Object value);
/**
 * Add new slot-values.
 * @param frame edu.stanford.smi.protege.model.Frame
 * @param slot edu.stanford.smi.protege.model.Slot
 * @param value java.lang.Object
 */
void addSlotValues(Frame frame, String slotName, Collection values);
/**
 * Copy knowledgeBase slot values to tripleDB.
 * Creation date: (4/24/2002 2:40:38 PM)
 */
void copyKnowledgeBase();
/**
 * Release listener connections.
 */
void release();
/**
 * Remove a slot and all of its triple-clauses.
 * Creation date: (4/9/2002 10:18:17 AM)
 * @param slotName java.lang.String
 */
void removeSlot(String slotName);
/**
 * Remove a slot-value clause.
 * @param frame edu.stanford.smi.protege.model.Frame
 * @param slot edu.stanford.smi.protege.model.Slot
 * @param value java.lang.Object
 */
void removeSlotValue(Frame frame, String slotName);
/**
 * Remove a slot-values clause.
 * @param frame edu.stanford.smi.protege.model.Frame
 * @param slot edu.stanford.smi.protege.model.Slot
 * @param value java.lang.Object
 */
void removeSlotValues(Frame frame, String slotName);
/**
 * Remove old slot and add new slot.
 * Creation date: (4/9/2002 10:18:17 AM)
 * @param slotName java.lang.String
 */
void renameSlot(String oldSlotName, String newSlotName);
/**
 * Remove existing slot-value and add new slot-value.
 * @param frame edu.stanford.smi.protege.model.Frame
 * @param slot edu.stanford.smi.protege.model.Slot
 * @param value java.lang.Object
 */
void updateSlotValue(Frame frame, String slotName, Object value);
/**
 * Remove existing slot-values and add new slot-values.
 * @param frame edu.stanford.smi.protege.model.Frame
 * @param slot edu.stanford.smi.protege.model.Slot
 * @param value java.lang.Object
 */
void updateSlotValues(Frame frame, String slotName, Collection values);
}
