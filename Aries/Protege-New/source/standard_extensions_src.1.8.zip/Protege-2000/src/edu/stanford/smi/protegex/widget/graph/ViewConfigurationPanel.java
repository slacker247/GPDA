/*
 * The contents of this file are subject to the Mozilla Public License
 * Version 1.1 (the "License");  you may not use this file except in compliance
 * with the License.  You may obtain a copy of the License at
 * http://www.mozilla.org/MPL/
 *
 * Software distributed under the License is distributed on an "AS IS" basis,
 * WITHOUT WARRANTY OF ANY KIND, either express or implied. See the License for
 * the specific language governing rights and limitations under the License.
 *
 * The Original Code is Protege-2000.
 *
 * The Initial Developer of the Original Code is Stanford University. Portions
 * created by Stanford University are Copyright (C) 2001.  All Rights Reserved.
 *
 * Protege-2000 was developed by Stanford Medical Informatics
 * (http://www.smi.stanford.edu) at the Stanford University School of Medicine
 * with support from the National Library of Medicine, the National Science
 * Foundation, and the Defense Advanced Research Projects Agency.  Current
 * information about Protege can be obtained at http://protege.stanford.edu
 *
 * Contributor(s):
 */

package edu.stanford.smi.protegex.widget.graph;

import java.awt.BorderLayout;
import java.awt.Color;
import java.awt.Dimension;
import javax.swing.BorderFactory;
import javax.swing.Box;
import javax.swing.BoxLayout;
import javax.swing.ButtonGroup;
import javax.swing.JLabel;
import javax.swing.JPanel;
import javax.swing.JRadioButton;
import javax.swing.border.TitledBorder;

import edu.stanford.smi.protege.model.Cls;
import edu.stanford.smi.protege.util.PropertyList;

public class ViewConfigurationPanel extends JPanel {
    private JPanel gridPropsPnl = new JPanel();

    // UI for grid style.  Right now this is just for setting the style
    // of the grid (i.e. tick marks, no tick marks, etc.).
    private JLabel lblGridStyle = new JLabel("Grid Style");
    private ButtonGroup group = new ButtonGroup();
    private JRadioButton invisible = new JRadioButton(GraphTypes.GRID_INVISIBLE);
    private JRadioButton dots = new JRadioButton(GraphTypes.GRID_DOTS);
    private JRadioButton crosses = new JRadioButton(GraphTypes.GRID_CROSSES);
    private JRadioButton lines = new JRadioButton(GraphTypes.GRID_LINES);

    private PropertyList props;
    private ViewProperties vProps;
    private Cls cls;

    public ViewConfigurationPanel(Cls cls, PropertyList props) {
        try {
            this.props = props;
            this.cls = cls;
            vProps = new ViewProperties(cls.getName(), props);
            initialize();
        } catch (Exception e) {
            e.printStackTrace();
        }
    }

    private void initialize() throws Exception {
        /* Build Grid Properties panel ****************************************/
        TitledBorder tb0 = new TitledBorder(BorderFactory.createEtchedBorder(Color.white, new Color(148, 145, 140)), "Default Grid Properties");
        gridPropsPnl.setBorder(tb0);

        initRadioButtons();

        gridPropsPnl.setLayout(new BoxLayout(gridPropsPnl, BoxLayout.Y_AXIS));
        gridPropsPnl.add(Box.createRigidArea(new Dimension(0, 10)));
        gridPropsPnl.add(lblGridStyle);
        gridPropsPnl.add(Box.createRigidArea(new Dimension(0, 5)));
        gridPropsPnl.add(invisible);
        gridPropsPnl.add(Box.createRigidArea(new Dimension(0, 5)));
        gridPropsPnl.add(crosses);
        gridPropsPnl.add(Box.createRigidArea(new Dimension(0, 5)));
        gridPropsPnl.add(dots);
        gridPropsPnl.add(Box.createRigidArea(new Dimension(0, 5)));
        gridPropsPnl.add(lines);

        this.setLayout(new BorderLayout(5, 5));
        this.add(gridPropsPnl, BorderLayout.NORTH);
    }

    public void saveContents() {
        vProps.setGridStyle(group.getSelection().getActionCommand());
        vProps.save();
    }

    private void initRadioButtons() {
        crosses.setActionCommand(GraphTypes.GRID_CROSSES);
        dots.setActionCommand(GraphTypes.GRID_DOTS);
        invisible.setActionCommand(GraphTypes.GRID_INVISIBLE);
        lines.setActionCommand(GraphTypes.GRID_LINES);

        group.add(crosses);
        group.add(dots);
        group.add(invisible);
        group.add(lines);

        String s = vProps.getGridStyle();
        if (s.equals(GraphTypes.GRID_CROSSES)) {
            crosses.setSelected(true);
        } else if (s.equals(GraphTypes.GRID_DOTS)) {
            dots.setSelected(true);
        } else if (s.equals(GraphTypes.GRID_INVISIBLE)) {
            invisible.setSelected(true);
        } else if (s.equals(GraphTypes.GRID_LINES)) {
            lines.setSelected(true);
        }
    }
}