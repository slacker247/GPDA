package protegex.prologtab.gnuprolog;

import edu.stanford.smi.protege.model.*;
import gnu.prolog.term.*;
import gnu.prolog.vm.*;
/**
 * Abstract PrologTab builtin that sets reference to GNUPrologEngine.
 * Creation date: (4/29/2002 9:20:04 AM)
 * @author: 
 */
public abstract class GNUPrologTabBuiltin implements gnu.prolog.vm.PrologCode {
	protected GNUPrologEngine _engine;
	
	public static final AtomTerm listAtom = AtomTerm.get("list"); 
	public static final AtomTerm atomAtom = AtomTerm.get("atom"); 
	public static final CompoundTermTag listTag = CompoundTermTag.get(".",2);
/**
 * PrologTabBuiltin constructor comment.
 */
public GNUPrologTabBuiltin() {
	super();
}
/**
 * Insert the method's description here.
 * Creation date: (5/7/2002 9:54:08 AM)
 * @return gnu.prolog.term.AtomTerm
 * @param args gnu.prolog.term.Term[]
 * @param index int
 * @exception gnu.prolog.vm.PrologException The exception description.
 */
public static AtomTerm checkAtom(Term[] args, int index) throws gnu.prolog.vm.PrologException {
	Term term = args[index];
	if (!(term instanceof AtomTerm))
		PrologException.typeError(atomAtom,term);
	return (AtomTerm) term;
}
/**
 * Insert the method's description here.
 * Creation date: (5/7/2002 9:53:36 AM)
 * @return gnu.prolog.term.Term
 * @param args gnu.prolog.term.Term[]
 * @param index int
 * @exception gnu.prolog.vm.PrologException The exception description.
 */
public static Term checkList(Term[] args, int index) throws gnu.prolog.vm.PrologException {
	Term term = args[index];
	if (!GNUPrologEngine.isList(term))
		PrologException.typeError(listAtom,term);
	return term;
}
/**
 * Check that argument at index is not a VariableTerm.
 * Creation date: (5/7/2002 9:47:41 AM)
 * @return gnu.prolog.term.Term
 * @param args gnu.prolog.term.Term[]
 * @param index int
 * @exception gnu.prolog.vm.PrologException The exception description.
 */
public static Term checkNonVar(Term[] args, int index) throws gnu.prolog.vm.PrologException {
	Term term = args[index];
	if (term instanceof VariableTerm)
		PrologException.instantiationError();
	return term;
}
/**
 * Check that argument at index is a VariableTerm.
 * Creation date: (5/7/2002 9:49:46 AM)
 * @return gnu.prolog.term.Term
 * @param args gnu.prolog.term.Term[]
 * @param index int
 * @exception gnu.prolog.vm.PrologException The exception description.
 */
public static Term checkVar(Term[] args, int index) throws gnu.prolog.vm.PrologException {
	Term term = args[index];
	if (!(term instanceof VariableTerm))
		PrologException.instantiationError();
	return term;
}
 /** this method is called when code is installed to the environment
     * code can be installed only for one environment.
     * @param environment environemnt to install the predicate
     */
public void install(gnu.prolog.vm.Environment env) {
	_engine = ((Environment) env).getEngine();
}
 /** this method is called when code is uninstalled from the environment
     * @param environment environemnt to install the predicate
     */
public void uninstall(gnu.prolog.vm.Environment env) {}
}
