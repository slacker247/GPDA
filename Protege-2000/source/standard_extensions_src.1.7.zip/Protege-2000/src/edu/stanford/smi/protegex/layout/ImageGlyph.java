/*
 * The contents of this file are subject to the Mozilla Public License
 * Version 1.1 (the "License");  you may not use this file except in compliance
 * with the License.  You may obtain a copy of the License at
 * http://www.mozilla.org/MPL/
 *
 * Software distributed under the License is distributed on an "AS IS" basis,
 * WITHOUT WARRANTY OF ANY KIND, either express or implied. See the License for
 * the specific language governing rights and limitations under the License.
 *
 * The Original Code is Protege-2000.
 *
 * The Initial Developer of the Original Code is Stanford University. Portions
 * created by Stanford University are Copyright (C) 2001.  All Rights Reserved.
 *
 * Protege-2000 was developed by Stanford Medical Informatics
 * (http://www.smi.stanford.edu) at the Stanford University School of Medicine
 * with support from the National Library of Medicine, the National Science
 * Foundation, and the Defense Advanced Research Projects Agency.  Current
 * information about Protege can be obtained at http://protege.stanford.edu
 *
 * Contributor(s):
 */

package edu.stanford.smi.protegex.layout;

import java.awt.*;

/**
 *  Handles images, including animated ones. Does animation explicitly. Not
 *  used.
 *
 * @author    William Grosso <grosso@smi.stanford.edu>
 */
public final class ImageGlyph implements Glyph {
    private Image _image;
    private int _frameWidth;
    private int _frameHeight;
    private int _totalNumberOfFrames;
    private int _numberOfHorizontalFrames;
    private int _numberOfVerticalFrames;
    private int _currentDisplayFrame;
    private Rectangle _screenLocation;
    private int _upperLeftX;
    private int _upperLeftY;
    private int _lowerRightX;
    private int _lowerRightY;
    private int _currentHorizontalFrame;
    private int _currentVerticalFrame;

    public ImageGlyph(Image image, int numberOfHorizontalFrames, int numberOfVerticleFrames) {
        _screenLocation = new Rectangle();
        setImage(
            image,
            image.getWidth(null) / numberOfHorizontalFrames,
            image.getHeight(null) / numberOfVerticleFrames,
            numberOfHorizontalFrames,
            numberOfVerticleFrames);
    }

    // constructors
    public ImageGlyph(
        Image image,
        int frameWidth,
        int frameHeight,
        int numberOfHorizontalFrames,
        int numberOfVerticleFrames) {
        _screenLocation = new Rectangle();
        setImage(image, frameWidth, frameHeight, numberOfHorizontalFrames, numberOfVerticleFrames);
    }

    private void computeImageBoundaries() {
        _currentHorizontalFrame = _currentDisplayFrame % _numberOfHorizontalFrames;
        _currentVerticalFrame = _currentDisplayFrame / _numberOfVerticalFrames;
        _upperLeftX = _currentHorizontalFrame * _frameWidth;
        _upperLeftY = _currentVerticalFrame * _frameHeight;
        _lowerRightX = _upperLeftX + _frameWidth;
        _lowerRightY = _upperLeftY + _frameHeight;
    }

    private void computeIncrementalImageBoundaries() {
        if (0 == _currentDisplayFrame) {
            _upperLeftX = 0;
            _upperLeftY = 0;
            _lowerRightX = _frameWidth;
            _lowerRightY = _frameHeight;
            _currentHorizontalFrame = 0;
            _currentVerticalFrame = 0;
            return;
        } else {
            _currentHorizontalFrame++;
            if (_currentHorizontalFrame > _numberOfHorizontalFrames - 1) {
                _currentHorizontalFrame = 0;
                _currentVerticalFrame++;
                _upperLeftX = 0;
                _upperLeftY += _frameHeight;
                _lowerRightX = _frameWidth;
                _lowerRightY += _frameHeight;
            } else {
                _upperLeftX += _frameWidth;
                _lowerRightX += _frameWidth;
            }
        }
    }

    // The Copyable Interface
    public Object copy() {
        return new ImageGlyph(_image, _frameWidth, _frameHeight, _numberOfHorizontalFrames, _numberOfVerticalFrames);
    }

    // and some internal helper functions
    private void displayFrame(Rectangle screenLocation, Graphics g) {
        g.drawImage(
            _image,
            screenLocation.x,
            screenLocation.y,
            screenLocation.x + screenLocation.width,
            screenLocation.y + screenLocation.height,
            _upperLeftX,
            _upperLeftY,
            _lowerRightX,
            _lowerRightY,
            null);
        return;
    }

    //  The Glyph Interface
    public void displayImage(ActorLocation location, Graphics g) {
        location.getBounds(_screenLocation);
        displayFrame(_screenLocation, g);
        return;
    }

    public void displayImage(Rectangle location, Graphics g) {
        displayFrame(location, g);
        return;
    }

    public void displaySelectedImage(ActorLocation location, Graphics g) {
        location.getBounds(_screenLocation);
        displayFrame(_screenLocation, g);
        g.setColor(Color.black);
        g.drawRect(_screenLocation.x, _screenLocation.y, _screenLocation.width, _screenLocation.height);
        return;
    }

    public void displaySelectedImage(Rectangle location, Graphics g) {
        displayFrame(location, g);
        g.setColor(Color.black);
        g.drawRect(location.x, location.y, location.width, location.height);
        return;
    }

    public Point getBoundaryPointForLine(Line line) {
        throw new Error("Implement me");
    }

    public int getFrameNumber() {
        return _currentDisplayFrame;
    }

    public Image getImage() {
        return _image;
    }

    public int getNumberOfFrames() {
        return _totalNumberOfFrames;
    }

    public int getPreferredHeight() {
        return _frameHeight;
    }

    public int getPreferredWidth() {
        return _frameWidth;
    }

    public void incrementFrameNumber() {
        _currentDisplayFrame++;
        validateFrameNumber();
        computeIncrementalImageBoundaries();
    }

    // random crap
    public void setFrameNumber(int frameNumber) {
        _currentDisplayFrame = frameNumber;
        validateFrameNumber();
        computeImageBoundaries();
    }

    // The Image API
    public void setImage(
        Image image,
        int frameWidth,
        int frameHeight,
        int numberOfHorizontalFrames,
        int numberOfVerticleFrames) {
        _frameWidth = frameWidth;
        _frameHeight = frameHeight;
        _totalNumberOfFrames = numberOfVerticleFrames * numberOfHorizontalFrames;
        _numberOfHorizontalFrames = numberOfHorizontalFrames;
        _numberOfVerticalFrames = numberOfVerticleFrames;
        _currentDisplayFrame = 0;
        _image = image;
        return;
    }

    // this does not do anything for now
    public void setTitle(String title) {

    }

    private void validateFrameNumber() {
        if (_currentDisplayFrame > _totalNumberOfFrames - 1) {
            _currentDisplayFrame = 0;
        }
    }
}
