package protegex.prologtab;

import edu.stanford.smi.protege.event.*;
/**
 * Combine Protege Event Listener interfaces.
 * Creation date: (4/3/2002 11:13:27 AM)
 * @author: 
 */
public interface KBListener extends KnowledgeBaseListener,FrameListener,ClsListener {
}
