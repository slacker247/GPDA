/*
 * The contents of this file are subject to the Mozilla Public License
 * Version 1.1 (the "License");  you may not use this file except in compliance
 * with the License.  You may obtain a copy of the License at
 * http://www.mozilla.org/MPL/
 *
 * Software distributed under the License is distributed on an "AS IS" basis,
 * WITHOUT WARRANTY OF ANY KIND, either express or implied. See the License for
 * the specific language governing rights and limitations under the License.
 *
 * The Original Code is Protege-2000.
 *
 * The Initial Developer of the Original Code is Stanford University. Portions
 * created by Stanford University are Copyright (C) 2001.  All Rights Reserved.
 *
 * Protege-2000 was developed by Stanford Medical Informatics
 * (http://www.smi.stanford.edu) at the Stanford University School of Medicine
 * with support from the National Library of Medicine, the National Science
 * Foundation, and the Defense Advanced Research Projects Agency.  Current
 * information about Protege can be obtained at http://protege.stanford.edu
 *
 * Contributor(s):
 */

package edu.stanford.smi.protegex.widget.diagram;

import edu.stanford.smi.protegex.layout.*;

import edu.stanford.smi.protege.model.*;
import edu.stanford.smi.protege.action.*;
import edu.stanford.smi.protege.util.*;

import java.awt.*;
import java.util.*;
import javax.swing.*;

/**
 *  Description of the Class
 *
 * @author    William Grosso <grosso@smi.stanford.edu>
 */
public abstract class DiagramsPanel extends JPanel implements Constants, MainDiagramArea {
    protected Project _project;
    protected DiagramWidget _widget;
    protected DiagramWidgetState _state;

    protected Dimension _mainDrawingPanelMinimumSize;
    protected MainDrawingPanel _mainDrawingPanel;
    protected DiagramsAnimationContext _mainDrawingArea;
    protected DiagramScrollPane _mainDrawingAreaScrollPane;

    public DiagramsPanel(DiagramWidget widget) {
        super(new BorderLayout());
        _widget = widget;
        _state = _widget.getState();
        _project = widget.getProject();
        _mainDrawingPanelMinimumSize = new Dimension();
        _mainDrawingPanelMinimumSize.width = _widget.getLogicalDrawingAreaWidth();
        _mainDrawingPanelMinimumSize.height = _widget.getLogicalDrawingAreaHeight();
        createMainDrawingArea();
        finishInitialization();
        validate();
    }

    public StandardWireActor buildActorForConnector(Instance connector, WireState specification) {
        StandardWireActor actor = ActorFactory.createWire(specification, _mainDrawingArea, "", _widget);
        ((ActorInstance) actor).setInstance(connector);
        //  new ListensToWireMovements(_project ,actor, connector, _widget.getNetworkInstance());
        return actor;
    }

    public Actor buildActorForNode(Instance node, NodeState specification) {
        Actor actor = ActorFactory.createIcon(specification, _mainDrawingArea, "", _widget);
        ((ActorInstance) actor).setInstance(node);
        new ListensToActorMovements(_project, actor, node, _widget.getNetworkInstance());
        return actor;
    }

    public void computeAttachmentsForConnector(Instance connector, final StandardWireActor actor) {
        final Instance firstObjectInstance = (Instance) ModelUtilities.getOwnSlotValue(connector, FIRST_OBJECT_SLOT_NAME);
        final Instance secondObjectInstance = (Instance) ModelUtilities.getOwnSlotValue(connector, SECOND_OBJECT_SLOT_NAME);

        boolean firstObjectAttached = false;

        boolean secondObjectAttached = false;

        if (firstObjectInstance != null) {
            firstObjectAttached = true;
        }
        if (secondObjectInstance != null) {
            secondObjectAttached = true;
        }
        if (firstObjectAttached || secondObjectAttached) {
            ZOrder zOrder = _mainDrawingArea.getZOrder();

            zOrder.performAction(0, new ActorAction() {
                public void performMethod(Actor a) {
                    ActorInstance actIns = (ActorInstance) a;
                    if (actIns.getInstance() == firstObjectInstance) {
                        ActorAttachment firstAttachment = new ActorAttachment(a, ControlPoints.BEGINNING, ControlPoints.MIDDLE);
                        ((StandardWireActor) actor).setStartingAttachment(firstAttachment);
                    }
                    if (actIns.getInstance() == secondObjectInstance) {
                        ActorAttachment secondAttachment = new ActorAttachment(a, ControlPoints.END, ControlPoints.MIDDLE);
                        ((StandardWireActor) actor).setEndingAttachment(secondAttachment);
                    }
                }
            });
        }
    }

    protected void createActorsForConnectors() {
        Collection connectorInstances = _widget.getConnectors();
        if (null == connectorInstances) {
            return;
        }
        Iterator i = connectorInstances.iterator();
        while (i.hasNext()) {
            Instance nextInstance = (Instance) i.next();
            WireState wireState = _state.getStateForConnector(nextInstance);
            StandardWireActor associatedActor = buildActorForConnector(nextInstance, wireState);
            placeConnectorOnScreen(nextInstance, associatedActor);
            computeAttachmentsForConnector(nextInstance, associatedActor);
        }
    }

    protected void createActorsForNodes() {
        Collection nodeInstances = _widget.getNodes();
        if (null == nodeInstances) {
            return;
        }
        Iterator i = nodeInstances.iterator();
        while (i.hasNext()) {
            Instance nextInstance = (Instance) i.next();
            NodeState nodeState = _state.getStateForNode(nextInstance);
            if (nodeState == null) {
                Log.error("no state for node " + nextInstance, this, "createActorsForNodes");
            } else {
                Actor associatedActor = buildActorForNode(nextInstance, nodeState);
                placeNodeOnScreen(nextInstance, associatedActor);
            }
        }
        return;
    }

    protected void createMainDrawingArea() {
        _mainDrawingPanel = new MainDrawingPanel(null);
        _mainDrawingPanel.setBackground(Color.white);
        _mainDrawingPanel.setPreferredSize(_mainDrawingPanelMinimumSize);

        _mainDrawingArea =
            new DiagramsAnimationContext(
                true,
                null,
                new Rectangle(0, 0, _mainDrawingPanelMinimumSize.width, _mainDrawingPanelMinimumSize.height),
                _mainDrawingPanel,
                new DiagramsAnimationContextMouseEventHandler());
        _mainDrawingPanel.setAnimationContext(_mainDrawingArea);
        _mainDrawingArea.setBackgroundManager(new NoCleanupBackgroundManager());

        _mainDrawingPanel.setMinimumSize(_mainDrawingPanelMinimumSize);
        _mainDrawingAreaScrollPane =
            new DiagramScrollPane(
                _mainDrawingPanel,
                JScrollPane.VERTICAL_SCROLLBAR_AS_NEEDED,
                JScrollPane.HORIZONTAL_SCROLLBAR_AS_NEEDED);
        _mainDrawingPanel.setScrollPane(_mainDrawingAreaScrollPane);
    }

    public abstract void finishInitialization();

    public AnimationContext getMainDrawingArea() {
        return _mainDrawingArea;
    }

    public MainDrawingPanel getMainDrawingPanel() {
        return _mainDrawingPanel;
    }

    public void placeConnectorOnScreen(Instance connector, Actor actor) {
        // needs refactoring ala placeNodeOnScreen
        Instance networkInstance = _widget.getNetworkInstance();
        Instance rectInstance = DiagramUtilities.getInstanceRectangleForObject(connector, networkInstance);
        Instance tmpInstance = (Instance) ModelUtilities.getOwnSlotValue(rectInstance, UPPER_LEFT_CORNER_SLOT);
        Integer x = (Integer) ModelUtilities.getOwnSlotValue(tmpInstance, POINT_X_SLOT);
        Integer y = (Integer) ModelUtilities.getOwnSlotValue(tmpInstance, POINT_Y_SLOT);
        int basex = x.intValue();
        int basey = y.intValue();
        Point basePoint = new Point(basex, basey);

        tmpInstance = (Instance) ModelUtilities.getOwnSlotValue(rectInstance, LOWER_RIGHT_CORNER_SLOT);

        x = (Integer) ModelUtilities.getOwnSlotValue(tmpInstance, POINT_X_SLOT);
        y = (Integer) ModelUtilities.getOwnSlotValue(tmpInstance, POINT_Y_SLOT);

        int endx = x.intValue();
        int endy = y.intValue();
        int width = Math.abs(endx - basePoint.x);
        int height = Math.abs(endy - basePoint.y);

        ActorLocation loc = new ActorLocation(basePoint, width, height, _mainDrawingArea.getCoordinateSystem());
        actor.move(basePoint.x, basePoint.y);
        actor.getLocation().setWidth(width);
        actor.getLocation().setHeight(height);

        ((StandardWireActor) actor).setEndingPoint(new Point(endx, endy));
        ((StandardWireActor) actor).setBeginningPoint(basePoint);
    }

    public void placeNodeOnScreen(Instance node, Actor actor) {
        Instance networkInstance = _widget.getNetworkInstance();
        Rectangle locationRectangle = DiagramUtilities.getLocationRectangleForObject(node, networkInstance);
        actor.move(locationRectangle.x, locationRectangle.y);
        actor.getLocation().setWidth(locationRectangle.width);
        actor.getLocation().setHeight(locationRectangle.height);
    }

    public void refreshConnectors() {
        removeCurrentConnections();
        createActorsForConnectors();
        repaint();
    }

    public void refreshNodes() {
        removeEverything();
        createActorsForNodes();
        createActorsForConnectors();
        resizeDiagram();
        repaint();
    }

    protected void removeCurrentConnections() {
        ZOrder zOrder = _mainDrawingArea.getZOrder();
        ResettableIterator iterator = zOrder.getIterator(ZOrder.TOPDOWN);

        while (iterator.hasNext()) {
            ActorInstance actor = (ActorInstance) iterator.next();
            if (((Actor) actor).isWire()) {
                iterator.remove();
            }
        }
        zOrder.returnIterator(iterator);
    }

    protected void removeCurrentNodes() {
        ZOrder zOrder = _mainDrawingArea.getZOrder();
        ResettableIterator iterator = zOrder.getIterator(0);

        while (iterator.hasNext()) {
            Actor actor = (Actor) iterator.next();
            if (false == actor.isWire()) {
                iterator.remove();
            }
        }
        zOrder.returnIterator(iterator);
    }

    protected void removeEverything() {
        ZOrder zOrder = _mainDrawingArea.getZOrder();
        ResettableIterator iterator = zOrder.getIterator(ZOrder.TOPDOWN);
        while (iterator.hasNext()) {
            iterator.next();
            iterator.remove();
        }
        zOrder.returnIterator(iterator);
    }

    public void resizeDiagram() {
        int logicalWidth = _widget.getLogicalDrawingAreaWidth();
        int logicalHeight = _widget.getLogicalDrawingAreaHeight();
        _mainDrawingArea.enlargeToWidth(logicalWidth);
        _mainDrawingArea.enlargeToHeight(logicalHeight);
    }

    public void setSize(int width, int height) {
        super.setSize(width, height);
        if (width > _mainDrawingPanelMinimumSize.width) {
            _mainDrawingPanelMinimumSize.width = width;
            _mainDrawingArea.enlargeToWidth(_mainDrawingPanelMinimumSize.width);
            _mainDrawingPanel.setPreferredSize(_mainDrawingPanelMinimumSize);
            _widget.setLogicalDrawingAreaWidth(_mainDrawingPanelMinimumSize.width);
        }
        if (height > _mainDrawingPanelMinimumSize.height) {
            _mainDrawingPanelMinimumSize.height = height;
            _mainDrawingArea.enlargeToHeight(_mainDrawingPanelMinimumSize.height);
            _mainDrawingPanel.setPreferredSize(_mainDrawingPanelMinimumSize);
            _widget.setLogicalDrawingAreaHeight(_mainDrawingPanelMinimumSize.height);
        }
    }
}
