/*
 * The contents of this file are subject to the Mozilla Public License
 * Version 1.1 (the "License");  you may not use this file except in compliance
 * with the License.  You may obtain a copy of the License at
 * http://www.mozilla.org/MPL/
 *
 * Software distributed under the License is distributed on an "AS IS" basis,
 * WITHOUT WARRANTY OF ANY KIND, either express or implied. See the License for
 * the specific language governing rights and limitations under the License.
 *
 * The Original Code is Protege-2000.
 *
 * The Initial Developer of the Original Code is Stanford University. Portions
 * created by Stanford University are Copyright (C) 2001.  All Rights Reserved.
 *
 * Protege-2000 was developed by Stanford Medical Informatics
 * (http://www.smi.stanford.edu) at the Stanford University School of Medicine
 * with support from the National Library of Medicine, the National Science
 * Foundation, and the Defense Advanced Research Projects Agency.  Current
 * information about Protege can be obtained at http://protege.stanford.edu
 *
 * Contributor(s):
 */

package edu.stanford.smi.protegex.layout;

import java.awt.*;

/**
 *  "Fancy Rectangle"
 *
 * @author    William Grosso <grosso@smi.stanford.edu>
 */
public final class ActorLocation implements Copyable {
    // The primary values in a location are the base, the height, and the width
    // All the other ones are derived.
    private Point _basePoint;
    private int _height;
    private int _width;
    private Rectangle _bounds;
    private Point _centerPoint;
    private Point _extensionPoint;

    protected Rectangle _coordinateSystem;

    public ActorLocation(Point basePoint, int height, int width, Rectangle coordinateSystem) {
        _basePoint = new Point(basePoint);
        _centerPoint = new Point();
        _extensionPoint = new Point();
        _bounds = new Rectangle();
        setHeight(height);
        setWidth(width);
        _coordinateSystem = coordinateSystem;
        synchronizeLocationData();
    }

    public boolean contains(Point point) {
        return _bounds.contains(point);
    }

    // The Copyable Interface
    public Object copy() {
        return new ActorLocation(_basePoint, _height, _width, _coordinateSystem);
    }

    public void getBasePoint(Point returnValue) {
        returnValue.x = (int) _basePoint.x;
        returnValue.y = (int) _basePoint.y;
        return;
    }

    public int getBaseX() {
        return _basePoint.x;
    }

    public int getBaseY() {
        return _basePoint.y;
    }

    // Accessors
    public void getBounds(Rectangle returnValue) {
        returnValue.x = (int) _bounds.x;
        returnValue.y = (int) _bounds.y;
        returnValue.height = (int) _bounds.height;
        returnValue.width = (int) _bounds.width;
        return;
    }

    public void getCenterPoint(Point returnValue) {
        returnValue.x = (int) _centerPoint.x;
        returnValue.y = (int) _centerPoint.y;
        return;
    }

    public int getCenterX() {
        return _centerPoint.x;
    }

    public int getCenterY() {
        return _centerPoint.y;
    }

    public void getExtensionPoint(Point returnValue) {
        returnValue.x = (int) _extensionPoint.x;
        returnValue.y = (int) _extensionPoint.y;
        return;
    }

    public int getExtensionX() {
        return _extensionPoint.x;
    }

    public int getExtensionY() {
        return _extensionPoint.y;
    }

    public int getHeight() {
        return _height;
    }

    public int getWidth() {
        return _width;
    }

    public boolean intersects(ActorLocation location) {
        return location.intersects(_bounds);
    }

    public boolean intersects(Rectangle location) {
        return _bounds.intersects(location);
    }

    public boolean isInside(Rectangle rectangle) {
        if (rectangle.contains(_basePoint)) {
            return rectangle.contains(_extensionPoint);
        }
        return false;
    }

    public boolean isInsideCoordinateSystem() {
        return isInside(_coordinateSystem);
    }

    // ways to move the location around
    public void move(int x, int y) {
        _basePoint.x = x;
        _basePoint.y = y;
        synchronizeLocationData();
    }

    public void moveInsideCoordinateSystem() {
        if (_basePoint.x < _coordinateSystem.x) {
            _basePoint.x = _coordinateSystem.x;
        } else {
            int maxX = _coordinateSystem.x + _coordinateSystem.width;
            if (_extensionPoint.x > maxX) {
                _basePoint.x = maxX - _width;
            }
        }
        if (_basePoint.y < _coordinateSystem.y) {
            _basePoint.y = _coordinateSystem.y;
        } else {
            int maxY = _coordinateSystem.y + _coordinateSystem.height;
            if (_extensionPoint.y > maxY) {
                _basePoint.y = maxY - _height;
            }
        }
        synchronizeLocationData();
        return;
    }

    public void reflectIntoCoordinateSystem() {
        int maxX = _coordinateSystem.x + _coordinateSystem.width;
        if (_extensionPoint.x > maxX) {
            _basePoint.x = maxX + maxX - _extensionPoint.x - _width;
        } else {
            if (_basePoint.x < _coordinateSystem.x) {
                _basePoint.x = _coordinateSystem.x + _coordinateSystem.x - _basePoint.x;
            }
        }
        int maxY = _coordinateSystem.y + _coordinateSystem.height;
        if (_extensionPoint.y > maxY) {
            _basePoint.y = maxY + maxY - _extensionPoint.y - _height;
        } else {
            if (_basePoint.y < _coordinateSystem.y) {
                _basePoint.y = _coordinateSystem.y + _coordinateSystem.y - _basePoint.y;
            }
        }
    }

    // mutators
    public void setBasePoint(Point basePoint) {
        int deltaX = basePoint.x - _basePoint.x;
        int deltaY = basePoint.y - _basePoint.y;
        _basePoint.x = basePoint.x;
        _basePoint.y = basePoint.y;
        setHeight(_height + deltaY);
        setWidth(_width + deltaX);
    }

    public void setCoordinateSystem(Rectangle coordinateSystem) {
        _coordinateSystem = coordinateSystem;
    }

    public void setExtensionPoint(Point extensionPoint) {
        int deltaX = extensionPoint.x - _extensionPoint.x;
        int deltaY = extensionPoint.y - _extensionPoint.y;
        setHeight(_height + deltaY);
        setWidth(_width + deltaX);
    }

    public void setHeight(int height) {
        if (height < 0) {
            _basePoint.y += height;
            _height = -height;
        } else {
            _height = height;
        }
        synchronizeLocationData();
    }

    public void setWidth(int width) {
        if (width < 0) {
            _basePoint.x += width;
            _width = -width;
        } else {
            _width = width;
        }
        synchronizeLocationData();
    }

    // internal helper method
    private void synchronizeLocationData() {
        int halfWidth = _width / 2;
        int halfHeight = _height / 2;
        _centerPoint.x = _basePoint.x + halfWidth;
        _centerPoint.y = _basePoint.y + halfHeight;
        _extensionPoint.x = _basePoint.x + _width;
        _extensionPoint.y = _basePoint.y + _height;
        _bounds.x = _basePoint.x;
        _bounds.width = _width;
        _bounds.y = _basePoint.y;
        _bounds.height = _height;
    }

    public String toString() {
        return "Base point " + _basePoint + " with width " + _width + " and height " + _height;
    }

    public void translate(int deltaX, int deltaY) {
        _basePoint.x += deltaX;
        _basePoint.y += deltaY;
        synchronizeLocationData();
    }

    public boolean translationStaysInCoordinateSystem(int deltaX, int deltaY) {
        boolean containsBasePoint;
        boolean containsExtensionPoint;
        containsBasePoint = _coordinateSystem.contains(_basePoint.x + deltaX, _basePoint.y + deltaY);
        containsExtensionPoint = _coordinateSystem.contains(_extensionPoint.x + deltaX, _extensionPoint.y + deltaY);
        return (containsBasePoint && containsExtensionPoint);
    }

    public void wrapIntoCoordinateSystem() {
        int maxX = _coordinateSystem.x + _coordinateSystem.width;
        if (_basePoint.x > maxX) {
            _basePoint.x = _coordinateSystem.x;
        } else {
            if (_extensionPoint.x < _coordinateSystem.x) {
                _basePoint.x = maxX;
            }
        }
        int maxY = _coordinateSystem.y + _coordinateSystem.height;
        if (_basePoint.y > maxY) {
            _basePoint.y = _coordinateSystem.y;
        } else {
            if (_extensionPoint.y < _coordinateSystem.y) {
                _basePoint.y = maxY;
            }
        }
    }
}
