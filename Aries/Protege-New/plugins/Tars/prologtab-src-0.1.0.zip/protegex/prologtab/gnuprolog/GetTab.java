package protegex.prologtab.gnuprolog;

import gnu.prolog.term.*;
import gnu.prolog.vm.*;
/**
 * Insert the type's description here.
 * Creation date: (4/29/2002 2:42:53 PM)
 * @author: 
 */
public class GetTab extends GNUPrologTabBuiltin {
/**
 * GetKnowledgeBase constructor comment.
 */
public GetTab() {
	super();
}
 /** this method is used for execution of code
     * @param interpreter interpreter in which context code is executed 
     * @param backtrackMode true if predicate is called on backtracking and false otherwise
     * @param args arguments of code
     * @return either SUCCESS, SUCCESS_LAST, or FAIL.
     */
public int execute(gnu.prolog.vm.Interpreter interpreter, boolean backtrackMode, gnu.prolog.term.Term[] args) throws gnu.prolog.vm.PrologException {
	Term resultTerm = args[0];
	if (!(resultTerm instanceof VariableTerm))
		PrologException.instantiationError();
	return interpreter.unify(resultTerm,_engine.getTerm(_engine.getTab()));
}
}
