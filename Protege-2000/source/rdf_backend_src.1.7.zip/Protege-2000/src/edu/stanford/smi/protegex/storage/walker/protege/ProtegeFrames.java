/*
 * The contents of this file are subject to the Mozilla Public License
 * Version 1.1 (the "License");  you may not use this file except in compliance
 * with the License.  You may obtain a copy of the License at
 * http://www.mozilla.org/MPL/
 *
 * Software distributed under the License is distributed on an "AS IS" basis,
 * WITHOUT WARRANTY OF ANY KIND, either express or implied. See the License for
 * the specific language governing rights and limitations under the License.
 *
 * The Original Code is Protege-2000.
 *
 * The Initial Developer of the Original Code is Stanford University. Portions
 * created by Stanford University are Copyright (C) 2001.  All Rights Reserved.
 *
 * Protege-2000 was developed by Stanford Medical Informatics
 * (http://www.smi.stanford.edu) at the Stanford University School of Medicine
 * with support from the National Library of Medicine, the National Science
 * Foundation, and the Defense Advanced Research Projects Agency.  Current
 * information about Protege can be obtained at http://protege.stanford.edu
 *
 * Contributor(s):
 */

package edu.stanford.smi.protegex.storage.walker.protege;

import java.util.*;
import edu.stanford.smi.protegex.storage.walker.*;
import edu.stanford.smi.protege.model.*;

public class ProtegeFrames {

  public KnowledgeBase _kb;
  public Namespaces _namespaces;
  public Hashtable _wframes; // Frame -> ProtegeFrame (WalkerFrame)
  public FrameCreator _creator;

  public ProtegeFrames(KnowledgeBase kb, Namespaces namespaces, 
      FrameCreator creator) {
    _kb = kb;
    _namespaces = namespaces;
    _wframes = new Hashtable();
    _creator = creator;
  }

  public ProtegeFrame getProtegeFrame(Frame frame) {
    ProtegeFrame protegeFrame = (ProtegeFrame)_wframes.get(frame);
    if (protegeFrame == null) { // we need a new one
      protegeFrame = newProtegeFrame(frame);
      _wframes.put(frame, protegeFrame);
    }
    return protegeFrame;
  }

  public ProtegeFrame newProtegeFrame(Frame frame) {
    return new ProtegeFrame(frame, _kb, _namespaces, _creator);
  }

  Object wframe(Object value) { // "walker" frame
    if (value == null)
      return null;
    else if (value instanceof Frame)
      return getProtegeFrame((Frame)value);
    else
      return value;
  }

  Collection wframes(Collection values) {
    ArrayList wframes = new ArrayList();
    for (Iterator vIterator = values.iterator(); vIterator.hasNext();) {
      Object value = vIterator.next();
      wframes.add(wframe(value));
    }
    return wframes;
  }

}


