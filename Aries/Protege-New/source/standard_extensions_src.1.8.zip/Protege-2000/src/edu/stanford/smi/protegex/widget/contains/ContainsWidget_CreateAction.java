/*
 * The contents of this file are subject to the Mozilla Public License
 * Version 1.1 (the "License");  you may not use this file except in compliance
 * with the License.  You may obtain a copy of the License at
 * http://www.mozilla.org/MPL/
 *
 * Software distributed under the License is distributed on an "AS IS" basis,
 * WITHOUT WARRANTY OF ANY KIND, either express or implied. See the License for
 * the specific language governing rights and limitations under the License.
 *
 * The Original Code is Protege-2000.
 *
 * The Initial Developer of the Original Code is Stanford University. Portions
 * created by Stanford University are Copyright (C) 2001.  All Rights Reserved.
 *
 * Protege-2000 was developed by Stanford Medical Informatics
 * (http://www.smi.stanford.edu) at the Stanford University School of Medicine
 * with support from the National Library of Medicine, the National Science
 * Foundation, and the Defense Advanced Research Projects Agency.  Current
 * information about Protege can be obtained at http://protege.stanford.edu
 *
 * Contributor(s):
 */

package edu.stanford.smi.protegex.widget.contains;

import java.awt.event.*;
import java.util.*;

import javax.swing.*;

import edu.stanford.smi.protege.model.*;
import edu.stanford.smi.protege.resource.*;
import edu.stanford.smi.protege.ui.*;

/**
 *  Description of the class
 *
 * @author    William Grosso <grosso@smi.stanford.edu>
 */
public class ContainsWidget_CreateAction extends ContainsWidget_AbstractAction {
    private String _dialogTitle;

    public ContainsWidget_CreateAction(ContainsWidget widget) {
        this(widget, (widget.getState()).getCreateInstanceButtonTooltip(), Icons.getCreateIcon());
        _dialogTitle = (widget.getState()).getCreateInstanceDialogTitle();
    }

    public ContainsWidget_CreateAction(ContainsWidget widget, String tooltipString, Icon icon) {
        super(widget, tooltipString, icon);
    }

    public void actionPerformed(ActionEvent e) {
        Instance newInstance = _kb.createInstance(null, getClsForInstance());
        _widget.addInstance(newInstance);
        if (_state.isCreateFormForNewInstances()) {
            _project.show(newInstance);
        }
    }

    private Cls getClsForInstance() {
        Collection allowedClasses = getAllowedClasses();
        if (allowedClasses.size() == 0) {
            allowedClasses.add(_kb.getRootCls());
        }
        return DisplayUtilities.pickConcreteCls((JComponent) _widget, allowedClasses, _dialogTitle);
    }

    protected void updateActivation() {
        boolean enabled = _widget.getValues().size() == 0 || _widget.allowsMultipleValues();
        setEnabled(enabled);
    }
}
