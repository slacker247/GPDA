/*
 * The contents of this file are subject to the Mozilla Public License
 * Version 1.1 (the "License");  you may not use this file except in compliance
 * with the License.  You may obtain a copy of the License at
 * http://www.mozilla.org/MPL/
 *
 * Software distributed under the License is distributed on an "AS IS" basis,
 * WITHOUT WARRANTY OF ANY KIND, either express or implied. See the License for
 * the specific language governing rights and limitations under the License.
 *
 * The Original Code is Protege-2000.
 *
 * The Initial Developer of the Original Code is Stanford University. Portions
 * created by Stanford University are Copyright (C) 2001.  All Rights Reserved.
 *
 * Protege-2000 was developed by Stanford Medical Informatics
 * (http://www.smi.stanford.edu) at the Stanford University School of Medicine
 * with support from the National Library of Medicine, the National Science
 * Foundation, and the Defense Advanced Research Projects Agency.  Current
 * information about Protege can be obtained at http://protege.stanford.edu
 *
 * Contributor(s):
 */

package edu.stanford.smi.protegex.widget.diagram;

import java.awt.*;
import java.awt.event.*;

import javax.swing.*;
import javax.swing.event.*;

import edu.stanford.smi.protege.util.*;

/**
 *  Description of the class
 *
 * @author    William Grosso <grosso@smi.stanford.edu>
 */
public class SizeConfigurationPanel extends JPanel {
    private JTextField _minimumWidthTextField;
    private JTextField _minimumHeightTextField;
    private JCheckBox _paletteCheckBox;

    private DiagramWidgetState _widgetState;

    private class DisplayPaletteListener implements ActionListener {
        public void actionPerformed(ActionEvent e) {
            _widgetState.setPaletteDisplayed(_paletteCheckBox.isSelected());
        }
    }

    private class MinimumHeightListener implements DocumentListener {
        public void insertUpdate(DocumentEvent e) {
            setHeight();
        }

        public void removeUpdate(DocumentEvent e) {
            setHeight();
        }

        public void changedUpdate(DocumentEvent e) {
            setHeight();
        }

        private void setHeight() {
            try {
                Integer value = new Integer(_minimumWidthTextField.getText());
                _widgetState.setLowerBoundOnDiagramHeight(value.intValue());
            } catch (Exception e) {
            }
        }
    }

    private class MinimumWidthListener implements DocumentListener {
        public void insertUpdate(DocumentEvent e) {
            setWidth();
        }

        public void removeUpdate(DocumentEvent e) {
            setWidth();
        }

        public void changedUpdate(DocumentEvent e) {
            setWidth();
        }

        private void setWidth() {
            try {
                Integer value = new Integer(_minimumWidthTextField.getText());
                _widgetState.setLowerBoundOnDiagramWidth(value.intValue());
            } catch (Exception e) {
            }
        }
    }

    public SizeConfigurationPanel(DiagramWidgetState widgetState) {
        super(new GridLayout(3, 1));
        _widgetState = widgetState;
        buildGUI();
    }

    private void addMinimumHeightPanel() {
        _minimumHeightTextField = new JTextField();
        (_minimumHeightTextField.getDocument()).addDocumentListener(new MinimumHeightListener());
        add(new LabeledComponent("Minimum (Logical) Height For Diagram", _minimumHeightTextField));
        return;
    }

    private void addMinimumWidthPanel() {
        _minimumWidthTextField = new JTextField();
        (_minimumWidthTextField.getDocument()).addDocumentListener(new MinimumWidthListener());
        add(new LabeledComponent("Minimum (Logical) Width For Diagram", _minimumWidthTextField));
        return;
    }

    /*
         * private void addDraggablePanel()
         * {
         * _draggablePanelCheckBox = new JCheckBox();
         * _draggablePanelCheckBox.addActionListener(new DraggableListener());
         * add(new LabeledComponent("Can Widget Panel be Dragged", _draggablePanelCheckBox));
         * return;
         * }
         */

    private void addPalettePanel() {
        _paletteCheckBox = new JCheckBox();
        _paletteCheckBox.addActionListener(new DisplayPaletteListener());
        add(new LabeledComponent("Should Object Palette be Displayed", _paletteCheckBox));
        return;
    }

    private void buildGUI() {
        addMinimumWidthPanel();
        addMinimumHeightPanel();
        addPalettePanel();
        configurefromStateObject();
    }

    private void configurefromStateObject() {
        _minimumWidthTextField.setText(String.valueOf(_widgetState.getLowerBoundOnDiagramWidth()));
        _minimumHeightTextField.setText(String.valueOf(_widgetState.getLowerBoundOnDiagramHeight()));
        _paletteCheckBox.setSelected(_widgetState.isPaletteDisplayed());
    }
}
