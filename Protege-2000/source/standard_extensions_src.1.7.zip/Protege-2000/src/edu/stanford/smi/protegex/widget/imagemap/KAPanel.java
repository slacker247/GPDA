/*
 * The contents of this file are subject to the Mozilla Public License
 * Version 1.1 (the "License");  you may not use this file except in compliance
 * with the License.  You may obtain a copy of the License at
 * http://www.mozilla.org/MPL/
 *
 * Software distributed under the License is distributed on an "AS IS" basis,
 * WITHOUT WARRANTY OF ANY KIND, either express or implied. See the License for
 * the specific language governing rights and limitations under the License.
 *
 * The Original Code is Protege-2000.
 *
 * The Initial Developer of the Original Code is Stanford University. Portions
 * created by Stanford University are Copyright (C) 2001.  All Rights Reserved.
 *
 * Protege-2000 was developed by Stanford Medical Informatics
 * (http://www.smi.stanford.edu) at the Stanford University School of Medicine
 * with support from the National Library of Medicine, the National Science
 * Foundation, and the Defense Advanced Research Projects Agency.  Current
 * information about Protege can be obtained at http://protege.stanford.edu
 *
 * Contributor(s):
 */

package edu.stanford.smi.protegex.widget.imagemap;

import java.awt.*;
import java.awt.event.*;
import javax.swing.*;
import javax.swing.event.*;
import java.util.*;

import javax.swing.*;

import edu.stanford.smi.protege.widget.*;
import edu.stanford.smi.protege.model.*;
import edu.stanford.smi.protege.ui.*;
import edu.stanford.smi.protege.util.*;
import edu.stanford.smi.protegex.util.*;

/**
 *  Wraps an ImageMapPanel and does stuff. Mainly by listening.
 *
 * @author    William Grosso <grosso@smi.stanford.edu>
 */
public class KAPanel extends JPanel {
    private ImageMapPanel _imageMapPanel;
    private ImageMapWidget _widget;
    private ImageMapState _state;
    private JComboBox _activeSymbolChooser;
    private String _chosenSymbol;
    private Rectangle _highlightedRectangle;
    private Color _selectionColor;
    private Color _tooltipColor;
    private static String NULL_STRING = "<No Value>";

    private class KAPanelListener extends ImageMapPanelAdapter {
        public void logicalPress(Point where) {
            _widget.userClicked(where);
        }
    }

    public KAPanel(ImageMapWidget widget) {
        super(new BorderLayout());
        _widget = widget;
        _state = _widget.getState();
        createImageMap();
        createComboBox();
    }

    public void clearSelection() {
        _imageMapPanel.removeAllRectangles();
        _activeSymbolChooser.setSelectedItem(NULL_STRING);
    }

    private void createComboBox() {
        ArrayList widgetSymbols = new ArrayList(_widget.getSymbols());
        widgetSymbols.add(NULL_STRING);
        _activeSymbolChooser = new JComboBox(new AlphabeticalComboBoxModel(widgetSymbols));
        _activeSymbolChooser.setEditable(false);
        LabeledComponent comboBoxWrapper = new LabeledComponent("Currently Selected Symbol", _activeSymbolChooser);
        _activeSymbolChooser.setEnabled(false);
        add(comboBoxWrapper, BorderLayout.SOUTH);
    }

    private void createImageMap() {
        _imageMapPanel = new ImageMapPanel(_state);
        LabeledComponent imageWrapper = new LabeledComponent(_widget.getLabel(), new JScrollPane(_imageMapPanel));
        _imageMapPanel.addImageMapPanelListener(new KAPanelListener());
        add(imageWrapper, BorderLayout.CENTER);
    }

    public void display(Rectangle rect, Color color, String symbol) {
        displayRect(rect, color);
        displaySymbol(symbol);
    }

    public void displayRect(Rectangle rect, Color color) {
        _imageMapPanel.removeAllRectangles();
        if (rect != null) {
            _imageMapPanel.addRectangle(rect, color);
        }
    }

    public void displaySymbol(String symbol) {
        if (symbol != null) {
            _activeSymbolChooser.setSelectedItem(symbol);
        } else {
            _activeSymbolChooser.setSelectedItem(NULL_STRING);
        }
    }
}
