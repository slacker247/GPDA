/*
 * The contents of this file are subject to the Mozilla Public License
 * Version 1.1 (the "License");  you may not use this file except in compliance
 * with the License.  You may obtain a copy of the License at
 * http://www.mozilla.org/MPL/
 *
 * Software distributed under the License is distributed on an "AS IS" basis,
 * WITHOUT WARRANTY OF ANY KIND, either express or implied. See the License for
 * the specific language governing rights and limitations under the License.
 *
 * The Original Code is Protege-2000.
 *
 * The Initial Developer of the Original Code is Stanford University. Portions
 * created by Stanford University are Copyright (C) 2001.  All Rights Reserved.
 *
 * Protege-2000 was developed by Stanford Medical Informatics
 * (http://www.smi.stanford.edu) at the Stanford University School of Medicine
 * with support from the National Library of Medicine, the National Science
 * Foundation, and the Defense Advanced Research Projects Agency.  Current
 * information about Protege can be obtained at http://protege.stanford.edu
 *
 * Contributor(s):
 */

package edu.stanford.smi.protegex.widget.graph;

import java.awt.Point;

import com.nwoods.jgo.JGoDocument;
import com.nwoods.jgo.JGoDocumentEvent;
import com.nwoods.jgo.JGoGridView;
import com.nwoods.jgo.JGoListPosition;
import com.nwoods.jgo.JGoObject;
import com.nwoods.jgo.JGoPort;

public class GraphPalette extends JGoGridView {

    public GraphPalette() {
        super();
        // Don't want user to be able to modify objects in the palette.
        getDocument().setModifiable(false);
        setGridWidth(20);
        setGridHeight(20);
        setGridSpot(JGoGridView.GridInvisible);
        setGridOrigin(new Point(0, 5));
        setHidingDisabledScrollbars(true);
    }

    public void layoutItems() {
        int xPos = getGridOrigin().x + getPaddingX();
        int yPos = getGridOrigin().y;

        JGoListPosition pos = getDocument().getFirstObjectPos();
        while (pos != null) {
            JGoObject obj = getDocument().getObjectAtPos(pos);
            if (obj instanceof Node) {
                Node node = (Node) obj;
                node.setSize(40, 40);
                node.changePortStyle(JGoPort.StyleHidden);
                node.setTopLeft(xPos, yPos);

                // Do we need y padding?
                node.getLabel().setCustomWrapWidth();
                int labelHeight = node.getLabel().getHeight();
                int availableHeight = (node.getDrawable().getHeight() / 2) - (node.getPort().getHeight() / 2);
                if (labelHeight > availableHeight) {
                    int padding = labelHeight - availableHeight;
                    node.setTop(yPos + padding);
                    yPos = yPos + node.getHeight() + padding + 5;
                } else {
                    yPos = yPos + node.getHeight() + 5;
                }

            }
            pos = getDocument().getNextObjectPosAtTop(pos);
        }
    }

    private int getPaddingX() {
        int xPad = 0;
        JGoListPosition pos = getDocument().getFirstObjectPos();
        while (pos != null) {
            JGoObject obj = getDocument().getObjectAtPos(pos);
            if (obj instanceof Node) {
                Node node = (Node) obj;
                int labelWidth = node.getLabel().getCustomWrapWidth() / 2;
                int availableWidth = node.getWidth() / 2 - node.getPort().getWidth() / 2;
                if (labelWidth > availableWidth) {
                    int difference = labelWidth - availableWidth;
                    if (difference > xPad) {
                        xPad = difference;
                    }
                }
            }
            pos = getDocument().getNextObjectPosAtTop(pos);
        }
        return xPad;
    }

    public void documentChanged(JGoDocumentEvent evt) {
        super.documentChanged(evt);
        if (evt.isBeforeChanging()) {
            return;
        }
        if (evt.getHint() == JGoDocumentEvent.INSERTED ||
            evt.getHint() == JGoDocumentEvent.REMOVED) {
            layoutItems();
        }
    }

    public void addNotify() {
        super.addNotify();
        setDropEnabled(false);
        layoutItems();
    }

    public void doLayout() {
        super.doLayout();
        layoutItems();
    }

    public void onGridChange(int what) {
        super.onGridChange(what);
        if (what == JGoGridView.ChangedDimensions ||
            what == JGoGridView.ChangedOrigin) {
            layoutItems();
        }
    }
}