/*
 * The contents of this file are subject to the Mozilla Public License
 * Version 1.1 (the "License");  you may not use this file except in compliance
 * with the License.  You may obtain a copy of the License at
 * http://www.mozilla.org/MPL/
 *
 * Software distributed under the License is distributed on an "AS IS" basis,
 * WITHOUT WARRANTY OF ANY KIND, either express or implied. See the License for
 * the specific language governing rights and limitations under the License.
 *
 * The Original Code is Protege-2000.
 *
 * The Initial Developer of the Original Code is Stanford University. Portions
 * created by Stanford University are Copyright (C) 2001.  All Rights Reserved.
 *
 * Protege-2000 was developed by Stanford Medical Informatics
 * (http://www.smi.stanford.edu) at the Stanford University School of Medicine
 * with support from the National Library of Medicine, the National Science
 * Foundation, and the Defense Advanced Research Projects Agency.  Current
 * information about Protege can be obtained at http://protege.stanford.edu
 *
 * Contributor(s):
 */

package edu.stanford.smi.protegex.widget.diagram;

import edu.stanford.smi.protegex.layout.*;

import edu.stanford.smi.protege.model.*;

import java.awt.*;
import java.text.*;
import java.awt.event.*;

import javax.swing.*;

/**
 *  Description of the Class
 *
 * @author    William Grosso <grosso@smi.stanford.edu>
 */
public class GlyphActorInstance extends StandardGlyphActor implements ActorInstance {
    protected Instance _instance;
    protected TextualOverlay _textRenderer;
    protected Rectangle _textRectangle;
    protected NodeState _nodeState;
    protected DiagramWidget _widget;

    public GlyphActorInstance(
        Glyph glyph,
        AnimationContext animationContext,
        ActorLocation location,
        ActorEventHandler eventHandler,
        ActorMovementHandler movementHandler,
        ActorControlPointHandler controlPointHandler,
        NodeState nodeState,
        DiagramWidget widget) {
        super(glyph, animationContext, location, eventHandler, movementHandler, controlPointHandler);
        _widget = widget;
        _textRectangle = new Rectangle();
        _nodeState = nodeState;
        _textRenderer = new TextualOverlay(_nodeState);
    }

    public Object copy() {
        Glyph copyOfGlyph = (Glyph) _glyph.copy();
        ActorLocation copyOfLocation = (ActorLocation) _location.copy();
        ActorEventHandler copyOfEventHandler = (ActorEventHandler) _eventHandler.copy();
        ActorMovementHandler copyOfMovementHandler = (ActorMovementHandler) _movementHandler.copy();
        ActorControlPointHandler copyOfControlPointHandler = (ActorControlPointHandler) _controlPointHandler.copy();
        GlyphActorInstance returnValue =
            new GlyphActorInstance(
                copyOfGlyph,
                _animationContext,
                copyOfLocation,
                copyOfEventHandler,
                copyOfMovementHandler,
                copyOfControlPointHandler,
                _nodeState,
                _widget);
        return returnValue;
    }

    public Rectangle draw(Graphics g) {
        if ((null == _instance) || (_widget.isNodeVisible(_instance))) {
            Rectangle returnValue = super.draw(g);
            drawText(g, returnValue);
            return returnValue;
        }
        return null;
    }

    private void drawText(Graphics g, Rectangle boundsForText) {
        if (null != _instance) {
            String browserText = _instance.getBrowserText();
            if (!browserText.equals(_textRenderer.getString())) {
                _textRenderer.setString(browserText);
            }
            _location.getBounds(_textRectangle);
            _textRenderer.draw(g, _textRectangle, getIsSelected());
        }
    }

    public Instance getInstance() {
        return _instance;
    }

    public boolean isAlwaysDisplayText() {
        return _textRenderer.isAlwaysDisplayText();
    }

    public void setAlwaysDisplayText(boolean alwaysDisplayText) {
        _textRenderer.setAlwaysDisplayText(alwaysDisplayText);
    }

    public void setInstance(Instance instance) {
        _instance = instance;
    }
}
