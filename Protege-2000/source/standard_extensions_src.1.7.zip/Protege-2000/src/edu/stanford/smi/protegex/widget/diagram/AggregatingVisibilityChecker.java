/*
 * The contents of this file are subject to the Mozilla Public License
 * Version 1.1 (the "License");  you may not use this file except in compliance
 * with the License.  You may obtain a copy of the License at
 * http://www.mozilla.org/MPL/
 *
 * Software distributed under the License is distributed on an "AS IS" basis,
 * WITHOUT WARRANTY OF ANY KIND, either express or implied. See the License for
 * the specific language governing rights and limitations under the License.
 *
 * The Original Code is Protege-2000.
 *
 * The Initial Developer of the Original Code is Stanford University. Portions
 * created by Stanford University are Copyright (C) 2001.  All Rights Reserved.
 *
 * Protege-2000 was developed by Stanford Medical Informatics
 * (http://www.smi.stanford.edu) at the Stanford University School of Medicine
 * with support from the National Library of Medicine, the National Science
 * Foundation, and the Defense Advanced Research Projects Agency.  Current
 * information about Protege can be obtained at http://protege.stanford.edu
 *
 * Contributor(s):
 */

package edu.stanford.smi.protegex.widget.diagram;

import edu.stanford.smi.protege.model.*;
import java.util.*;

/**
 *  Description of the class
 *
 * @author    William Grosso <grosso@smi.stanford.edu>
 */
public class AggregatingVisibilityChecker extends BaseVisibilityChecker implements Observer {
    private Object _yes = new Object();
    private Object _no = new Object();
    private ArrayList _visibilityCheckers;
    private HashMap _namesToVisibilityCheckers;
    private HashMap _nodeInstancesToVisibility;
    private HashMap _nodesClsesToVisibility;
    private HashMap _connectorInstancesToVisibility;
    private HashMap _connectorClsesToVisibility;

    public AggregatingVisibilityChecker() {
        reset();
    }

    public void addVisibilityChecker(String name, VisibilityChecker newVisibilityChecker) {
        if (null != _namesToVisibilityCheckers.get(name)) {
            return;
        }
        _visibilityCheckers.add(newVisibilityChecker);
        _namesToVisibilityCheckers.put(name, newVisibilityChecker);
        if (newVisibilityChecker instanceof BaseVisibilityChecker) {
            BaseVisibilityChecker baseVisibilityChecker = (BaseVisibilityChecker) newVisibilityChecker;
            baseVisibilityChecker.addObserver(this);
        }
        clearCache();
    }

    private void clearCache() {
        _nodeInstancesToVisibility = new HashMap();
        _nodesClsesToVisibility = new HashMap();
        _connectorInstancesToVisibility = new HashMap();
        _connectorClsesToVisibility = new HashMap();
    }

    private Object computeConnectorVisibility(Cls connectorCls) {
        Iterator i = _visibilityCheckers.iterator();
        while (i.hasNext()) {
            VisibilityChecker nextChecker = (VisibilityChecker) i.next();
            if (false == nextChecker.isConnectorClsVisible(connectorCls)) {
                return _no;
            }
        }
        return _yes;
    }

    public Object computeConnectorVisibility(Instance connectorInstance) {
        Iterator i = _visibilityCheckers.iterator();
        while (i.hasNext()) {
            VisibilityChecker nextChecker = (VisibilityChecker) i.next();
            if (false == nextChecker.isConnectorVisible(connectorInstance)) {
                return _no;
            }
        }
        return _yes;
    }

    private Object computeNodeVisibility(Cls nodeCls) {
        Iterator i = _visibilityCheckers.iterator();
        while (i.hasNext()) {
            VisibilityChecker nextChecker = (VisibilityChecker) i.next();
            if (false == nextChecker.isNodeClsVisible(nodeCls)) {
                return _no;
            }
        }
        return _yes;
    }

    private Object computeNodeVisibility(Instance nodeInstance) {
        Iterator i = _visibilityCheckers.iterator();
        while (i.hasNext()) {
            VisibilityChecker nextChecker = (VisibilityChecker) i.next();
            if (false == nextChecker.isNodeVisible(nodeInstance)) {
                return _no;
            }
        }
        return _yes;
    }

    public VisibilityChecker getVisibilityChecker(String name) {
        return (VisibilityChecker) _namesToVisibilityCheckers.get(name);
    }

    public boolean isConnectorClsVisible(Cls connectorCls) {
        Object truthValue = _connectorClsesToVisibility.get(connectorCls);
        if (null == truthValue) {
            truthValue = computeConnectorVisibility(connectorCls);
            _connectorClsesToVisibility.put(connectorCls, truthValue);
        }
        return (truthValue == _yes);
    }

    public boolean isConnectorVisible(Instance connectorInstance) {
        Object truthValue = _connectorInstancesToVisibility.get(connectorInstance);
        if (null == truthValue) {
            truthValue = computeConnectorVisibility(connectorInstance);
            _connectorInstancesToVisibility.put(connectorInstance, truthValue);
        }
        return (truthValue == _yes);
    }

    public boolean isNodeClsVisible(Cls nodeCls) {
        Object truthValue = _nodesClsesToVisibility.get(nodeCls);
        if (null == truthValue) {
            truthValue = computeNodeVisibility(nodeCls);
            _nodesClsesToVisibility.put(nodeCls, truthValue);
        }
        return (truthValue == _yes);
    }

    public boolean isNodeVisible(Instance nodeInstance) {
        Object truthValue = _nodeInstancesToVisibility.get(nodeInstance);
        if (null == truthValue) {
            truthValue = computeNodeVisibility(nodeInstance);
            _nodeInstancesToVisibility.put(nodeInstance, truthValue);
        }
        return (truthValue == _yes);
    }

    public void removeVisibilityChecker(String name) {
        VisibilityChecker oldVisibilityChecker = getVisibilityChecker(name);
        if (null != oldVisibilityChecker) {
            _namesToVisibilityCheckers.remove(name);
            _visibilityCheckers.remove(oldVisibilityChecker);
            if (oldVisibilityChecker instanceof BaseVisibilityChecker) {
                BaseVisibilityChecker baseVisibilityChecker = (BaseVisibilityChecker) oldVisibilityChecker;
                baseVisibilityChecker.deleteObserver(this);
            }
        }
        clearCache();
    }

    public void reset() {
        _visibilityCheckers = new ArrayList();
        _namesToVisibilityCheckers = new HashMap();
        clearCache();
    }

    public void update(Observable observable, Object arg) {
        clearCache();
    }
}
