/*
 * The contents of this file are subject to the Mozilla Public License
 * Version 1.1 (the "License");  you may not use this file except in compliance
 * with the License.  You may obtain a copy of the License at
 * http://www.mozilla.org/MPL/
 *
 * Software distributed under the License is distributed on an "AS IS" basis,
 * WITHOUT WARRANTY OF ANY KIND, either express or implied. See the License for
 * the specific language governing rights and limitations under the License.
 *
 * The Original Code is Protege-2000.
 *
 * The Initial Developer of the Original Code is Stanford University. Portions
 * created by Stanford University are Copyright (C) 2001.  All Rights Reserved.
 *
 * Protege-2000 was developed by Stanford Medical Informatics
 * (http://www.smi.stanford.edu) at the Stanford University School of Medicine
 * with support from the National Library of Medicine, the National Science
 * Foundation, and the Defense Advanced Research Projects Agency.  Current
 * information about Protege can be obtained at http://protege.stanford.edu
 *
 * Contributor(s):
 */

package edu.stanford.smi.protegex.widget.instancetable;

import java.awt.*;

import edu.stanford.smi.protege.model.*;
import edu.stanford.smi.protege.util.*;

/**
 *  Wrapper around all the information that describes how a slot appears.
 *
 * @author    William Grosso <grosso@smi.stanford.edu>
 */
public class VisibleSlotDescription {
    public Slot slot;
    public String columnName;
    public Color color;
    public int preferredSize;
    private final static String COLUMN_NAME_DESCRIPTOR = ":COLUMN:NAME:DESCRIPTOR";
    private final static String COLOR_RGB_DESCRIPTOR = ":COLOR:RGB:DESCRIPTOR";
    private final static String PREFERRED_SIZE_DESCRIPTOR = ":PREFERRED:SIZE:DESCRIPTOR";

    public VisibleSlotDescription(KnowledgeBase kb, PropertyList plist, String slotName) {
        slot = kb.getSlot(slotName);
        columnName = plist.getString(COLUMN_NAME_DESCRIPTOR + slotName);
        Integer rGB = plist.getInteger(COLOR_RGB_DESCRIPTOR + slotName);
        if (null != rGB) {
            color = new Color(rGB.intValue());
        } else {
            color = Color.black;
        }
        Integer prefSize = plist.getInteger(PREFERRED_SIZE_DESCRIPTOR + slotName);
        if (null != prefSize) {
            preferredSize = prefSize.intValue();
        } else {
            preferredSize = 20;
        }
    }

    public VisibleSlotDescription(Slot theSlot) {
        slot = theSlot;
        columnName = slot.getBrowserText();
        color = Color.black;
        preferredSize = 20;
    }

    public VisibleSlotDescription(Slot theSlot, Color theColor, String theColumnName, int thePreferredSize) {
        slot = theSlot;
        columnName = theColumnName;
        color = theColor;
        preferredSize = thePreferredSize;
    }

    public void writeToPropertyList(PropertyList plist) {
        String slotName = slot.getName();
        plist.setString(COLUMN_NAME_DESCRIPTOR + slotName, columnName);
        plist.setInteger(COLOR_RGB_DESCRIPTOR + slotName, color.getRGB());
        plist.setInteger(PREFERRED_SIZE_DESCRIPTOR + slotName, preferredSize);
    }
}
