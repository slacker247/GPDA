package protegex.prologtab;

import java.io.*;
import java.util.*;

/** **********************************************************************
 * A very simple reader, something like StringBufferReader but
 * you can add text to it. Useful for creating GUIs in which you want Jess to
 * continually read input from a text widget.
 * <P>
 * (C) 1998 E.J. Friedman-Hill and the Sandia Corporation
 * @author Ernest J. Friedman-Hill
 ********************************************************************** */

public class TextReader extends Reader implements Serializable
{
	private StringBuffer _buffer = new StringBuffer(256);
	private StringBuffer _termBuffer = new StringBuffer(256);
	private int _ptr = 0;
	
	private Vector _history = new Vector();
    private int _history_index = 0;
    
	private IdleHandler _idleHandler;
/**
 * Insert the method's description here.
 * Creation date: (4/28/2002 4:25:40 PM)
 */
public TextReader() {
	_history.add("");  // Sentinel
}
/**
 * 
 * @param text java.lang.String
 */
public void addHistory() {
	_history.add(_history.size()-1, getTermString().trim());
	_history_index = _history.size()-1;
	resetTermBuffer();
}
  /**
   * Add text to the internal buffer. The text will become available for reading
   * via read().
   * @param s New text to add to the buffer
   * @see #read
   */
  public synchronized void appendText(String s)
  {
    _buffer.append(s);
    notifyAll();
  }
  /**
   * Find out if any input is waiting to be read.
   * @return True if internal buffer is not empty.
   */

  public int available()
  {
    return _buffer.length() - _ptr;
  }
  /**
   * Remove all text from the internal buffer.
   */

  public synchronized void clear()
  {
    _buffer.setLength(0);
    _ptr = 0;
  }
  /**
   * Does nothing.
   */
  public void close() {}
/**
 * Insert the method's description here.
 * Creation date: (4/28/2002 4:41:45 PM)
 * @param delta int
 */
public String getHistory(int delta) {
	_history_index += delta;
	if (_history_index < 0)
		_history_index = 0;
	if (_history_index >= _history.size())
		_history_index = _history.size()-1;
	return (String) _history.get(_history_index);
}
/**
 * Insert the method's description here.
 * Creation date: (4/26/2002 2:16:51 PM)
 * @return java.lang.String
 */
public String getTermString() {
	return _termBuffer.toString();
}
  /**
   * Read a character from the internal buffer. Depending on the value of the
   * dontWait parameter passed to the constructor, this method may block if no input
   * is available.
   * @return The character or EOF (-1)
   */
public synchronized int read() {
	if (_ptr >= _buffer.length())
		return -1;
   
	int c = _buffer.charAt(_ptr++);
	_termBuffer.append((char) c);
        
    if (_ptr >= _buffer.length())
      clear();
    
    return c;
  }
  /**
   * Read an array of characters from the internal buffer. Depending on the value of the
   * dontWait parameter passed to the constructor, this method may block if no input
   * is available.
   * @return The number of characters read.
   */

  public int read(char[] c) throws IOException
  { return read(c, 0, c.length); }
  /**
   * Read part of an array of characters from the internal
   * buffer. Depending on the value of the dontWait parameter passed
   * to the constructor, this method may block if no input is
   * available. 
   * @return The number of characters read. 
   * @see java.io.Writer#read
   */

  public int read(char[] c, int start, int count) throws IOException
  {
    for (int i=start; i<start+count; i++)
      {
        int ch = read();
        if (ch == -1) {
	        if (i == start) {
				waitUntilAvailable();
				ch = read();
	        } else
	        	return i - start;
		}
		c[i] = (char) ch;
      }
    return count;
  }
/**
 * Insert the method's description here.
 * Creation date: (4/26/2002 2:15:11 PM)
 */
public void resetTermBuffer() {
	_termBuffer = new StringBuffer(256);
}
/**
 * Insert the method's description here.
 * Creation date: (4/28/2002 4:25:24 PM)
 * @param idleHandler protegex.prologtab.IdleHandler
 */
public void setIdleHandler(IdleHandler idleHandler) {
	_idleHandler = idleHandler;
}
/**
 * 
 * @param text java.lang.String
 */
public void startHistory() {
	resetTermBuffer();
}
/**
 * 
 */
public synchronized void waitUntilAvailable() {
	while (available() == 0) {
		try {
			wait(100);
			if (_idleHandler != null)
				_idleHandler.idle();
		} catch (InterruptedException ie) {}
	}
}
}
