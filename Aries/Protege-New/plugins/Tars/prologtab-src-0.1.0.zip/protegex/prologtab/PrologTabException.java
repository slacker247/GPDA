package protegex.prologtab;

/**
 * PrologTab wrapper exception.
 * Creation date: (4/11/2002 6:07:31 PM)
 * @author: 
 */
public class PrologTabException extends Exception {
	private Exception _exception;
/**
 * PrologTabException constructor comment.
 */
public PrologTabException() {
	super();
}
/**
 * Construct with wrapped exception.
 * Creation date: (4/11/2002 6:08:30 PM)
 * @param exception java.lang.Exception
 */
public PrologTabException(Exception exception) {
	_exception = exception;
}
/**
 * PrologTabException constructor comment.
 * @param s java.lang.String
 */
public PrologTabException(String s) {
	super(s);
}
/**
 * Return the wrapped exception.
 * Creation date: (4/24/2002 9:58:40 AM)
 * @return java.lang.Exception
 */
public Exception getWrappedException() {
	return _exception;
}
}
