/*
 * The contents of this file are subject to the Mozilla Public License
 * Version 1.1 (the "License");  you may not use this file except in compliance
 * with the License.  You may obtain a copy of the License at
 * http://www.mozilla.org/MPL/
 *
 * Software distributed under the License is distributed on an "AS IS" basis,
 * WITHOUT WARRANTY OF ANY KIND, either express or implied. See the License for
 * the specific language governing rights and limitations under the License.
 *
 * The Original Code is Protege-2000.
 *
 * The Initial Developer of the Original Code is Stanford University. Portions
 * created by Stanford University are Copyright (C) 2001.  All Rights Reserved.
 *
 * Protege-2000 was developed by Stanford Medical Informatics
 * (http://www.smi.stanford.edu) at the Stanford University School of Medicine
 * with support from the National Library of Medicine, the National Science
 * Foundation, and the Defense Advanced Research Projects Agency.  Current
 * information about Protege can be obtained at http://protege.stanford.edu
 *
 * Contributor(s):
 */

package edu.stanford.smi.protegex.layout;

import java.util.*;

/**
 *  Record zorder of actors inside a single animation context Keeps a pool of
 *  iterators over actors
 *
 * @author    William Grosso <grosso@smi.stanford.edu>
 */
public class ZOrder {

    private ArrayList _topDown;
    private ArrayList _bottomUp;
    private int _numberOfElementsMinusOne;
    private IteratorPool _iteratorPool;
    public final static int TOPDOWN = 0;
    public final static int BOTTOMUP = 1;

    private class ResettableListIterator implements ResettableIterator {
        private ArrayList _underlyingList;
        private int _currentPosition;

        public ResettableListIterator(ArrayList underlyingList) {
            _underlyingList = underlyingList;
            reset();
        }

        public void reset() {
            _currentPosition = 0;
        }

        public boolean hasNext() {
            if (_currentPosition <= _numberOfElementsMinusOne) {
                return true;
            }
            return false;
        }

        public Object next() {
            return _underlyingList.get(_currentPosition++);
        }

        public void remove() {
            (ZOrder.this).removeActor((Actor) _underlyingList.get(--_currentPosition));
        }

        public void setUnderlyingList(ArrayList underlyingList) {
            _underlyingList = underlyingList;
            _currentPosition = 0;
        }
    }

    private class IteratorPool {
        private ArrayList _iterators;

        public IteratorPool() {
            _iterators = new ArrayList();
        }

        public void returnIterator(ResettableIterator iterator) {
            _iterators.add(iterator);
        }

        public ResettableIterator getIterator(ArrayList underlyingList) {
            int size = _iterators.size();
            if (size == 0) {
                return new ResettableListIterator(underlyingList);
            }
            size--;
            ResettableListIterator returnValue = (ResettableListIterator) _iterators.remove(size);
            returnValue.setUnderlyingList(underlyingList);
            return returnValue;
        }
    }

    public ZOrder() {
        _topDown = new ArrayList();
        _bottomUp = new ArrayList();
        _numberOfElementsMinusOne = -1;
        _iteratorPool = new IteratorPool();
    }

    public void addActorToBottom(Actor actor) {
        _topDown.add(actor);
        if (-1 == _numberOfElementsMinusOne) {
            _bottomUp.add(actor);
        } else {
            _bottomUp.add(0, actor);
        }
        _numberOfElementsMinusOne++;
    }

    public void addActorToTop(Actor actor) {
        if (-1 == _numberOfElementsMinusOne) {
            _topDown.add(actor);
        } else {
            _topDown.add(0, actor);
        }
        _bottomUp.add(actor);
        _numberOfElementsMinusOne++;
    }

    public ResettableIterator getIterator(int direction) {
        if (direction == TOPDOWN) {
            return _iteratorPool.getIterator(_topDown);
        } else {
            return _iteratorPool.getIterator(_bottomUp);
        }
    }

    public void moveActorToBottom(Actor actor) {
        removeActor(actor);
        addActorToBottom(actor);
    }

    public void moveActorToTop(Actor actor) {
        removeActor(actor);
        addActorToTop(actor);
    }

    public int numberOfActors() {
        return _topDown.size();
    }

    public void performAction(int direction, ActorAction action) {
        ResettableIterator iterator = getIterator(direction);
        while (iterator.hasNext()) {
            Actor actor = (Actor) iterator.next();
            action.performMethod(actor);
        }
        returnIterator(iterator);
        return;
    }

    public List performCollectiveTest(int direction, ActorTest test) {
        ArrayList returnValue = new ArrayList();
        ResettableIterator iterator = getIterator(direction);
        while (iterator.hasNext()) {
            Actor actor = (Actor) iterator.next();
            if (test.performTest(actor)) {
                returnValue.add(actor);
            }
        }
        returnIterator(iterator);
        return returnValue;
    }

    public Actor performSingleTest(int direction, ActorTest test) {
        ResettableIterator iterator = getIterator(direction);
        while (iterator.hasNext()) {
            Actor actor = (Actor) iterator.next();
            if (test.performTest(actor)) {
                returnIterator(iterator);
                return actor;
            }
        }
        returnIterator(iterator);
        return null;
    }

    public void removeActor(Actor actor) {
        int topDownIndex = _topDown.indexOf(actor);
        if (-1 < topDownIndex) {
            _topDown.remove(topDownIndex);
            _bottomUp.remove(_numberOfElementsMinusOne - topDownIndex);
            _numberOfElementsMinusOne--;
        }
        return;
    }

    public void returnIterator(ResettableIterator iterator) {
        _iteratorPool.returnIterator(iterator);
    }
}
