/*
 * The contents of this file are subject to the Mozilla Public License
 * Version 1.1 (the "License");  you may not use this file except in compliance
 * with the License.  You may obtain a copy of the License at
 * http://www.mozilla.org/MPL/
 *
 * Software distributed under the License is distributed on an "AS IS" basis,
 * WITHOUT WARRANTY OF ANY KIND, either express or implied. See the License for
 * the specific language governing rights and limitations under the License.
 *
 * The Original Code is Protege-2000.
 *
 * The Initial Developer of the Original Code is Stanford University. Portions
 * created by Stanford University are Copyright (C) 2001.  All Rights Reserved.
 *
 * Protege-2000 was developed by Stanford Medical Informatics
 * (http://www.smi.stanford.edu) at the Stanford University School of Medicine
 * with support from the National Library of Medicine, the National Science
 * Foundation, and the Defense Advanced Research Projects Agency.  Current
 * information about Protege can be obtained at http://protege.stanford.edu
 *
 * Contributor(s):
 */

package edu.stanford.smi.protegex.widget.abstracttable;

import edu.stanford.smi.protege.widget.*;
import edu.stanford.smi.protege.model.*;
import edu.stanford.smi.protege.ui.*;
import edu.stanford.smi.protege.util.*;
import edu.stanford.smi.protege.resource.*;
import java.awt.*;
import java.awt.event.*;
import javax.swing.*;
import javax.swing.event.*;
import java.util.*;

/**
 *  Description of the Class
 *
 * @author    William Grosso <grosso@smi.stanford.edu>
 */
public class InPlaceEditingConfigurationPanel extends AbstractTableWidgetConfigurationSubPanel implements Validatable {
    private UseDialogPanel _useDialogForClasses;
    private UseDialogPanel _useDialogForInstances;
    private JCheckBox _inPlaceEditingCheckBox;

    private class InPlaceEditCheckBoxListener implements ActionListener {
        public void actionPerformed(ActionEvent e) {
            _state.setEditInPlace(_inPlaceEditingCheckBox.isSelected());
        }
    }

    private class UseDialogForClassesListener implements ActionListener {
        public void actionPerformed(ActionEvent e) {
            _state.setUseDialogToSelectClasses(_useDialogForClasses.isUseDialog());
            _state.setDialogTitleForSelectingClasses(_useDialogForClasses.getDialogTitle());
        }
    }

    private class UseDialogForInstancesListener implements ActionListener {
        public void actionPerformed(ActionEvent e) {
            _state.setUseDialogToSelectInstances(_useDialogForInstances.isUseDialog());
            _state.setDialogTitleForSelectingInstances(_useDialogForInstances.getDialogTitle());
        }
    }

    public InPlaceEditingConfigurationPanel(AbstractTableWidgetState state) {
        super(state);
    }

    protected void buildGUI() {
        buildInPlaceEditingCheckBox(0);
        buildUseDialogForClasses(1);
        buildUseDialogForInstances(2);
        addVerticalSpace(3);
    }

    protected void buildInPlaceEditingCheckBox(int yPosition) {
        _inPlaceEditingCheckBox = createCheckBox("Use in place editing", yPosition);
        _inPlaceEditingCheckBox.setSelected(_state.isEditInPlace());
        _inPlaceEditingCheckBox.addActionListener(new InPlaceEditCheckBoxListener());
    }

    protected void buildUseDialogForClasses(int yPosition) {
        _useDialogForClasses =
            new UseDialogPanel(
                "classes",
                "Selecting Classes",
                _state.isUseDialogToSelectClasses(),
                _state.getDialogTitleForSelectingClasses());
        _useDialogForClasses.addActionListener(new UseDialogForClassesListener());
        add(_useDialogForClasses, buildComponentGridBagConstraints(yPosition));
    }

    protected void buildUseDialogForInstances(int yPosition) {
        _useDialogForInstances =
            new UseDialogPanel(
                "instances",
                "Selecting Instances",
                _state.isUseDialogToSelectInstances(),
                _state.getDialogTitleForSelectingInstances());
        _useDialogForInstances.addActionListener(new UseDialogForInstancesListener());
        add(_useDialogForInstances, buildComponentGridBagConstraints(yPosition));
    }

    public void saveContents() {
        _state.save();
    }

    public boolean validateContents() {
        return true;
    }
}
