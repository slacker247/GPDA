/*
 * The contents of this file are subject to the Mozilla Public License
 * Version 1.1 (the "License");  you may not use this file except in compliance
 * with the License.  You may obtain a copy of the License at
 * http://www.mozilla.org/MPL/
 *
 * Software distributed under the License is distributed on an "AS IS" basis,
 * WITHOUT WARRANTY OF ANY KIND, either express or implied. See the License for
 * the specific language governing rights and limitations under the License.
 *
 * The Original Code is Protege-2000.
 *
 * The Initial Developer of the Original Code is Stanford University. Portions
 * created by Stanford University are Copyright (C) 2001.  All Rights Reserved.
 *
 * Protege-2000 was developed by Stanford Medical Informatics
 * (http://www.smi.stanford.edu) at the Stanford University School of Medicine
 * with support from the National Library of Medicine, the National Science
 * Foundation, and the Defense Advanced Research Projects Agency.  Current
 * information about Protege can be obtained at http://protege.stanford.edu
 *
 * Contributor(s):
 */

package edu.stanford.smi.protegex.widget.diagram;

import edu.stanford.smi.protegex.layout.*;

import java.awt.*;

/**
 *  Description of the class
 *
 * @author    William Grosso <grosso@smi.stanford.edu>
 */
public class TilingAnimationFrame extends AnimationContext {
    private final static int ACTOR_SPACING = 20;
    // distance between two actors
    private final static int SHIFT_OFFSET = 20;
    // distance between two actors
    private boolean _actorListHasChanged;
    private boolean _retilingNeeded;
    private ResettableIterator _actorIterator;
    private Actor _selectedActor;
    private boolean _needToRetile;

    public TilingAnimationFrame(
        boolean visibleToEvents,
        BackgroundManager backgroundManager,
        Rectangle coordinateSystem,
        Component owner) {
        super(visibleToEvents, backgroundManager, coordinateSystem, owner, new DiagramsAnimationContextMouseEventHandler());
    }

    public void addActorToBottom(Actor actor) {
        super.addActorToBottom(actor);
        _actorListHasChanged = true;
    }

    public void addActorToTop(Actor actor) {
        super.addActorToTop(actor);
        _actorListHasChanged = true;
    }

    public void enlargeToHeight(int newHeight) {
        if (_coordinateSystem.height < newHeight) {
            _coordinateSystem.height = newHeight;
        }
    }

    public void enlargeToWidth(int newWidth) {
        if (_coordinateSystem.width < newWidth) {
            _coordinateSystem.width = newWidth;
        }
    }

    public void moveActorToBottom(Actor actor) {
        super.moveActorToBottom(actor);
        _actorListHasChanged = false;
    }

    public void moveActorToTop(Actor actor) {
        super.moveActorToTop(actor);
        _actorListHasChanged = false;
    }

    private boolean needToRetile() {
        // hook for more complicated logic
        return _actorListHasChanged || _needToRetile;
    }

    public void paint(Graphics g) {
        if (needToRetile()) {
            tile();
        }
        super.paint(g);
    }

    public void removeActor(Actor actor) {
        super.removeActor(actor);
        _actorListHasChanged = true;
    }

    public void retile() {
        _needToRetile = true;
    }

    public void setSelectedActor(Actor actor) {
        if (null != _selectedActor) {
            _selectedActor.setIsSelected(false);
        }
        if (null == actor) {
            _selectedActor = null;
        } else {
            if (actor.getIsSelectable()) {
                _selectedActor = actor;
                actor.setIsSelected(true);
            }
        }
    }

    private void tile() {
        int leftOfLine;
        int rightLineOffset;
        int topEdge;
        int maxY;
        int currentShiftOffset = SHIFT_OFFSET;

        _actorIterator = _zOrder.getIterator(ZOrder.TOPDOWN);
        _actorListHasChanged = false;
        _needToRetile = false;
        leftOfLine = _coordinateSystem.x;
        rightLineOffset = 0;
        topEdge = _coordinateSystem.y;
        maxY = _coordinateSystem.y + _coordinateSystem.height;

        while (_actorIterator.hasNext()) {
            Actor actor = (Actor) _actorIterator.next();
            ActorLocation location = actor.getLocation();
            location.move(leftOfLine, topEdge);

            int locationHeight = location.getHeight();
            int locationWidth = location.getWidth();
            topEdge += locationHeight + ACTOR_SPACING;
            if (topEdge > maxY) {
                topEdge = _coordinateSystem.y + currentShiftOffset;
                currentShiftOffset = (currentShiftOffset == SHIFT_OFFSET) ? 0 : SHIFT_OFFSET;
                leftOfLine += rightLineOffset + ACTOR_SPACING;
                rightLineOffset = 0;
            }
            if (locationWidth > rightLineOffset) {
                rightLineOffset = locationWidth;
            }
        }
        enlargeToWidth(leftOfLine + rightLineOffset);
    }
}
