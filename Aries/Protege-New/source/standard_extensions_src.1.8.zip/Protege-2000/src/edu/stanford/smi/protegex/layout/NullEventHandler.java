/*
 * The contents of this file are subject to the Mozilla Public License
 * Version 1.1 (the "License");  you may not use this file except in compliance
 * with the License.  You may obtain a copy of the License at
 * http://www.mozilla.org/MPL/
 *
 * Software distributed under the License is distributed on an "AS IS" basis,
 * WITHOUT WARRANTY OF ANY KIND, either express or implied. See the License for
 * the specific language governing rights and limitations under the License.
 *
 * The Original Code is Protege-2000.
 *
 * The Initial Developer of the Original Code is Stanford University. Portions
 * created by Stanford University are Copyright (C) 2001.  All Rights Reserved.
 *
 * Protege-2000 was developed by Stanford Medical Informatics
 * (http://www.smi.stanford.edu) at the Stanford University School of Medicine
 * with support from the National Library of Medicine, the National Science
 * Foundation, and the Defense Advanced Research Projects Agency.  Current
 * information about Protege can be obtained at http://protege.stanford.edu
 *
 * Contributor(s):
 */

package edu.stanford.smi.protegex.layout;

import java.awt.event.*;

/**
 *  Pretty much a null object
 *
 * @author    William Grosso <grosso@smi.stanford.edu>
 */
public class NullEventHandler extends ActorDelegateImpl implements ActorEventHandler {

    public NullEventHandler(Actor actor) {
        super(actor);
    }

    public boolean canPerformIncrementalDrag(int deltaX, int deltaY) {
        return false;
    }

    public Object copy() {
        return this;
    }

    public boolean getIsDraggable() {
        return false;
    }

    public boolean getIsDragging() {
        return false;
    }

    public boolean getIsResizable() {
        return false;
    }

    public boolean getIsResizing() {
        return false;
    }

    public boolean getIsSelectable() {
        return false;
    }

    public boolean getIsSelected() {
        return false;
    }

    public void processClick(MouseEvent e) {
        return;
    }

    public void processDrag(MouseEvent e) {
        return;
    }

    public void processIncrementalDrag(int deltaX, int deltaY) {
        return;
    }

    public void processMousePress(MouseEvent e) {
        return;
    }

    public void processMouseRelease(MouseEvent e) {
        return;
    }

    public void setIsDraggable(boolean isDraggable) {
        return;
    }

    public void setIsResizable(boolean isResizable) {
        return;
    }

    public void setIsSelectable(boolean isSelectable) {
        return;
    }

    public void setIsSelected(boolean isSelected) {
        throw new Error("Someone tried to select an actor which cannot be selected");
    }

    public boolean wantEvent(MouseEvent e) {
        return false;
    }
}
