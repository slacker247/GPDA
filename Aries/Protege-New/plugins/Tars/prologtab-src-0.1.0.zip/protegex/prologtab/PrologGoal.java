package protegex.prologtab;

/**
 * Wrapper for Prolog engine goal and results.
 * Creation date: (4/11/2002 5:57:51 PM)
 * @author: 
 */
public interface PrologGoal {
	public static final int SUCCESS = 0;
	public static final int SUCCESS_LAST = 1;
	public static final int FAIL = -1;
/**
 * Evaluate the goal.
 * Creation date: (4/11/2002 5:58:59 PM)
 * @return int
 */
int evaluate() throws PrologTabException;
/**
 * Print results to a PrintWriter.
 * Creation date: (4/11/2002 6:02:34 PM)
 * @param writer java.io.PrintWriter
 */
void printResults(java.io.PrintWriter writer);
/**
 * Restart the goal from the beginning.
 * Creation date: (4/11/2002 6:46:41 PM)
 */
void restart() throws PrologTabException;
/**
 * Stop evaluation of the goal.
 * Creation date: (4/11/2002 6:54:29 PM)
 */
void stop();
}
