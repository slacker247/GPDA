package protegex.prologtab;

import java.io.*;
import java.awt.*;
import javax.swing.JTextArea;
import javax.swing.JScrollPane;

/** **********************************************************************
 * TextAreaWriter: a simple Writer, suitable for constructing
 * a PrintWriter, which uses a TextArea as its output. This class is a
 * convenient way to write a GUI in which Jess prints its output to a
 * text widget. Contents are kept to a maximum of 32000 characters,
 * assuming that no other code appends to this TextArea.
 * The JTextAreaWriter is a Swing implementation of TextAreaWriter.
 * (Converted to Swing by Henrik Eriksson.)
 * (Modified for PrologTab by Troy Caldwell)
 * <P>
 * (C) 1998 E.J. Friedman-Hill and the Sandia Corporation
 * @author Ernest J. Friedman-Hill
 */

public class JTextAreaWriter extends Writer implements Serializable
{

    private StringBuffer _buffer;
    private JTextArea _textArea;
    private JScrollPane _scrollPane;
    private int _size = 0;
    private static final int MAXSIZE = 30000;


    /**
     * Call this with an already constructed TextArea
     * object, which you can put wherever you'd like.
     * @param area The text area
     * @param so The scroll pane
     */
    public JTextAreaWriter(JTextArea area, JScrollPane scrollPane)
    {
        _buffer = new StringBuffer(100);
        _textArea = area;
        _scrollPane = scrollPane;
        _size = _textArea.getText().length();
    }
    /**
     * Clear the text.
     */

    public synchronized void clear()
    {
        _textArea.setText("");
        _size = 0;
    }
    /**
     * Does nothing.
     */

    public void close()
    {
    }
    /**
     * Flushes pending output to the TextArea.
     */

public synchronized void flush() {
        int len = _buffer.length();
        if (_size > MAXSIZE)
            {
                _textArea.replaceRange("", 0, len);
                _size -= len;
            }

        String str = _buffer.toString();
        _textArea.append(str);
        _size += len;


        if (_textArea.getHeight() > _scrollPane.getHeight())
            _textArea.scrollRectToVisible(new Rectangle(0,_textArea.getHeight(),0,50));

        _buffer.setLength(0);
}
/**
 * Scroll window to end of text.
 * Creation date: (5/7/2002 12:12:36 PM)
 */
public void scrollToEnd() {
	new Thread() {
		public void run() {
			try { sleep(200); } catch (InterruptedException e) { }
			if (_textArea.getHeight() > _scrollPane.getHeight())
				_textArea.scrollRectToVisible(new Rectangle(0,_textArea.getHeight(),0,50));
		}
	}.start();
}
    /**
     * Writes a portion of an array of characters to the TextArea. No
     * output is actually done until flush() is called.
     *
     * @param b The array of characters
     * @param off The first character in the array to write
     * @param len The number of characters form the array to write
     * @see #flush
     */

    public synchronized void write(char b[], int off, int len)
    {
        for (int i=off; i< len; i++)
            _buffer.append( b[i]);
    }
}
