package protegex.prologtab;

/**
 * Insert the type's description here.
 * Creation date: (5/3/2002 1:00:35 PM)
 * @author: 
 */
public interface PrologConsole {
/**
 * Insert the method's description here.
 * Creation date: (5/3/2002 1:03:48 PM)
 * @param listener java.awt.event.ActionListener
 */
void addTerminateActionListener(java.awt.event.ActionListener listener);
/**
 * Insert the method's description here.
 * Creation date: (5/3/2002 1:02:22 PM)
 * @return protegex.prologtab.TextReader
 */
TextReader getReader();
/**
 * Insert the method's description here.
 * Creation date: (5/3/2002 1:02:46 PM)
 * @return java.io.PrintWriter
 */
java.io.PrintWriter getWriter();
/**
 * Scroll to end of text.
 * Creation date: (5/7/2002 12:16:31 PM)
 */
void scrollToEnd();
/**
 * Insert the method's description here.
 * Creation date: (5/3/2002 1:02:58 PM)
 */
void setFocus();
}
