package protegex.prologtab;

import java.net.URL;
import java.util.*;
import java.awt.event.*;
import javax.swing.*;
import java.awt.*;
import java.io.*;
import edu.stanford.smi.protege.resource.*;
import edu.stanford.smi.protege.widget.*;
import edu.stanford.smi.protege.model.*;
import edu.stanford.smi.protege.ui.*;
import edu.stanford.smi.protege.util.*;
/**
 * Abstract PrologTab widget.
 * Creation date: (3/26/2002 1:14:02 PM)
 * @author: 
 */
public abstract class PrologTab extends AbstractTabWidget {
    // The display panel
    protected JConsolePanel _console_panel;
    
    protected InstanceDisplay _instanceDisplay;
    protected DirectInstancesList _prologModuleInstancesList;
    protected InstancesList _instancesList;

    protected PrologShell _shell;
/**
 * PrologTab constructor comment.
 */
public PrologTab() {
	super();
}
/**
 * Insert the method's description here.
 * Creation date: (4/28/2002 6:18:13 PM)
 * @return javax.swing.JComponent
 */
private JConsolePanel createConsolePanel() {
	_console_panel = new JConsolePanel();
	// Add listener for the terminate button...
	_console_panel.addTerminateActionListener(new ActionListener() {
		public void actionPerformed(ActionEvent ae) {
			_shell.restart();
		}
	});
	return _console_panel;
}
    private JComponent createInstanceDisplay() {
        _instanceDisplay = new InstanceDisplay(getProject());
        return _instanceDisplay;
    }
    private JComponent createInstancesPanel() {
        JPanel panel = ComponentFactory.createPanel();
        panel.setLayout(new BorderLayout());
        // panel.add(createClsDisplay(), BorderLayout.NORTH);
        panel.add(createPrologModuleInstancesList(), BorderLayout.CENTER);
        return panel;
    }
    private JComponent createInstanceSplitter() {
        JSplitPane pane = createLeftRightSplitPane("PrologTab.right.left_right", 250);
        pane.setLeftComponent(createInstancesPanel());
        pane.setRightComponent(createInstanceDisplay());
        return pane;
    }
private JComponent createPrologModuleInstancesList() {
	
	_prologModuleInstancesList = new DirectInstancesList(getProject());
	
	_prologModuleInstancesList.addSelectionListener(new SelectionListener() {
		public void selectionChanged(SelectionEvent event) {
			Collection selection = _prologModuleInstancesList.getSelection();
			Instance selectedInstance;
			if (selection.size() == 1) {
				selectedInstance = (Instance) CollectionUtilities.getFirstItem(selection);
			} else {
				selectedInstance = null;
			}
			_instanceDisplay.setInstance(selectedInstance);
		}
	});
	
	_prologModuleInstancesList.getDragComponent().addMouseListener(new PopupMenuMouseListener(_prologModuleInstancesList.getDragComponent()) {
		public JPopupMenu getPopupMenu() {
			JPopupMenu menu = null;
			Collection selection = _prologModuleInstancesList.getSelection();
			if (selection.size() == 1) {
				menu = new JPopupMenu();
				menu.add(new AbstractAction ("Consult") {
					public void actionPerformed(ActionEvent event) {
						Collection selection = _prologModuleInstancesList.getSelection();
						if (selection.size() == 1) {
							_shell.requestConsult((Instance) selection.toArray()[0]);
						}
					}
				});
        	}
			return menu;
		}

		public void setSelection(JComponent c, int x, int y) {
		}

	});
	
	return _prologModuleInstancesList;
}
/**
 * Insert the method's description here.
 * Creation date: (5/3/2002 10:23:39 AM)
 * @return protegex.prologtab.PrologShell
 * @param console protegex.prologtab.PrologConsole
 */
public abstract PrologShell createPrologShell(PrologConsole console);
/**
 * 
 */
public void dispose() {
	super.dispose();
	_shell.close();
}
/**
 * Initialize the PrologTab.
 */
public void initialize() {
	setIcon(Icons.getYesIcon());
	setLabel("GNU Prolog");
	setShortDescription("GNU Prolog Tab");

	PrologTabSystemClasses.addSystemClasses(getKnowledgeBase());

	// Create the subtabs for PrologTab
	JTabbedPane tabbedPane = new JTabbedPane();
	// Create the console tab...
	setLayout(new BorderLayout());
	tabbedPane.addTab("Console", null, createConsolePanel(), "Prolog console window");
	tabbedPane.addTab("Modules",null,createInstanceSplitter(), "Prolog Code window");
	add(tabbedPane, BorderLayout.CENTER);

	// Ensure we get the focus when the tab is selected...
	addComponentListener(new ComponentAdapter() {
		public void componentShown(ComponentEvent e) { _console_panel.setFocus(); }
	});
	
	_console_panel.addComponentListener(new ComponentAdapter() {
		public void componentShown(ComponentEvent e) { _console_panel.setFocus(); }
	});
	
	_prologModuleInstancesList.setClses(PrologTabSystemClasses.getPrologCodeClses(getKnowledgeBase()));

	_shell = createPrologShell(_console_panel);
	_shell.start();
}
}
