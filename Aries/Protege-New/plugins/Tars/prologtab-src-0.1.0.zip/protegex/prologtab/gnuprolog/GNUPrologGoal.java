package protegex.prologtab.gnuprolog;

import gnu.prolog.term.*;
import gnu.prolog.io.*;
import java.util.*;
import gnu.prolog.vm.*;
import protegex.prologtab.*;
/**
 * PrologGoal interface for GNU Prolog.
 * Creation date: (4/11/2002 6:04:48 PM)
 * @author: 
 */
public class GNUPrologGoal implements PrologGoal {
    protected Interpreter _interpreter;
    protected Interpreter.Goal _goal;
    protected Term _goalTerm;
    protected ReadOptions _readOptions;
/**
 * GNUPrologGoal constructor comment.
 */
public GNUPrologGoal(Term goalTerm, Interpreter interpreter, ReadOptions readOptions) throws PrologException {
	super();
	_readOptions = readOptions;
	_interpreter = interpreter;
	_goalTerm = goalTerm;
	_goal = _interpreter.prepareGoal(_goalTerm);
}
/**
 * Evaluate the goal.
 * Creation date: (4/11/2002 6:05:07 PM)
 * @return int
 */
public int evaluate() throws PrologTabException {
	try {
		return _interpreter.execute(_goal);
	} catch (PrologException e) {
		throw new PrologTabException(e);
	}
}
/**
 * Insert the method's description here.
 * Creation date: (4/11/2002 6:05:07 PM)
 * @param writer java.io.PrintWriter
 */
public void printResults(java.io.PrintWriter writer) {
	TermWriter out = new TermWriter(writer);
	WriteOptions options = new WriteOptions();
	options.operatorSet = new OperatorSet();
	Iterator ivars = _readOptions.variableNames.keySet().iterator();
	while (ivars.hasNext()) {
		String name = (String)ivars.next();
		out.print(name+" = ");
		out.print(options,((Term)_readOptions.variableNames.get(name)).dereference());
		out.print("; ");
	}
	out.println();
}
/**
 * Restart the goal.
 * Creation date: (4/11/2002 6:47:34 PM)
 */
public void restart() throws PrologTabException {
	try {
		_interpreter.stop(_goal);
		_goal = _interpreter.prepareGoal(_goalTerm);
	} catch (PrologException e) {
		throw new PrologTabException(e);
	}
}
/**
 * Stop the goal.
 * Creation date: (4/11/2002 6:46:23 PM)
 */
public void stop() {
	_interpreter.stop(_goal);
}
}
