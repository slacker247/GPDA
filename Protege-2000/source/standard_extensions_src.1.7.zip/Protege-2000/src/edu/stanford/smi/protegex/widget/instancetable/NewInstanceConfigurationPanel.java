/*
 * The contents of this file are subject to the Mozilla Public License
 * Version 1.1 (the "License");  you may not use this file except in compliance
 * with the License.  You may obtain a copy of the License at
 * http://www.mozilla.org/MPL/
 *
 * Software distributed under the License is distributed on an "AS IS" basis,
 * WITHOUT WARRANTY OF ANY KIND, either express or implied. See the License for
 * the specific language governing rights and limitations under the License.
 *
 * The Original Code is Protege-2000.
 *
 * The Initial Developer of the Original Code is Stanford University. Portions
 * created by Stanford University are Copyright (C) 2001.  All Rights Reserved.
 *
 * Protege-2000 was developed by Stanford Medical Informatics
 * (http://www.smi.stanford.edu) at the Stanford University School of Medicine
 * with support from the National Library of Medicine, the National Science
 * Foundation, and the Defense Advanced Research Projects Agency.  Current
 * information about Protege can be obtained at http://protege.stanford.edu
 *
 * Contributor(s):
 */

package edu.stanford.smi.protegex.widget.instancetable;

import edu.stanford.smi.protegex.widget.abstracttable.*;
import edu.stanford.smi.protege.widget.*;
import edu.stanford.smi.protege.model.*;
import edu.stanford.smi.protege.ui.*;
import edu.stanford.smi.protege.util.*;
import edu.stanford.smi.protege.resource.*;
import java.awt.*;
import java.awt.event.*;
import javax.swing.*;
import javax.swing.event.*;
import java.util.*;

/**
 *  Description of the Class
 *
 * @author    William Grosso <grosso@smi.stanford.edu>
 */
public class NewInstanceConfigurationPanel extends AbstractTableWidgetConfigurationSubPanel {

    private class SelectNewlyCreatedOrAddedInstanceCheckBoxListener implements ActionListener {
        public void actionPerformed(ActionEvent e) {
            ((InstanceTableWidgetState) _state).setAutoSelectInsertions(((JCheckBox) e.getSource()).isSelected());
        }
    }

    private class HighlightSelectedRowCheckBoxListener implements ActionListener {
        public void actionPerformed(ActionEvent e) {
            ((InstanceTableWidgetState) _state).setHighlightSelectedRow(((JCheckBox) e.getSource()).isSelected());
        }
    }

    private class DisplayNewInstanceFormsCheckBoxListener implements ActionListener {
        public void actionPerformed(ActionEvent e) {
            ((InstanceTableWidgetState) _state).setCreateFormForNewInstances(((JCheckBox) e.getSource()).isSelected());
        }
    }

    private class DisplayCreateInstanceButtonListener implements ActionListener {
        public void actionPerformed(ActionEvent e) {
            ((InstanceTableWidgetState) _state).setDisplayCreateInstanceButton(((JCheckBox) e.getSource()).isSelected());
        }
    }

    private class DisplayAddInstanceButtonListener implements ActionListener {
        public void actionPerformed(ActionEvent e) {
            ((InstanceTableWidgetState) _state).setDisplayAddInstanceButton(((JCheckBox) e.getSource()).isSelected());
        }
    }

    private class DisplayRemoveInstanceButtonListener implements ActionListener {
        public void actionPerformed(ActionEvent e) {
            ((InstanceTableWidgetState) _state).setDisplayRemoveInstanceButton(((JCheckBox) e.getSource()).isSelected());
        }
    }

    private class DisplayViewInstanceButtonListener implements ActionListener {
        public void actionPerformed(ActionEvent e) {
            ((InstanceTableWidgetState) _state).setDisplayViewInstanceButton(((JCheckBox) e.getSource()).isSelected());
        }
    }

    private class DisplayPrototypeButtonListener implements ActionListener {
        public void actionPerformed(ActionEvent e) {
            ((InstanceTableWidgetState) _state).setDisplayPrototypeButton(((JCheckBox) e.getSource()).isSelected());
        }
    }

    private class PrototypeButton implements ActionListener {
        private int _depth;

        private PrototypeButton(int depth) {
            _depth = depth;
        }

        public void actionPerformed(ActionEvent e) {
            JRadioButton caller = (JRadioButton) e.getSource();
            if (caller.isSelected()) {
                ((InstanceTableWidgetState) _state).setPrototypeDepth(_depth);
            }
        }
    }

    public NewInstanceConfigurationPanel(InstanceTableWidgetState state) {
        super(state);
        buildGUI();
    }

    private void addRadioButton(ButtonGroup buttonGroup, JPanel panel, String description, int depth) {
        int prototypeDepth = ((InstanceTableWidgetState) _state).getPrototypeDepth();
        JRadioButton newButton = new JRadioButton(description);
        newButton.addActionListener(new PrototypeButton(depth));
        panel.add(newButton);
        buttonGroup.add(newButton);
        if (depth == prototypeDepth) {
            newButton.setSelected(true);
        }
    }

    private void buildDisplayNewInstanceFormsCheckbox(int yPosition) {
        JCheckBox displayNewInstanceForms;
        displayNewInstanceForms = createCheckBox("Display forms for newly created instances", yPosition);
        displayNewInstanceForms.setSelected(((InstanceTableWidgetState) _state).isCreateFormForNewInstances());
        displayNewInstanceForms.addActionListener(new DisplayNewInstanceFormsCheckBoxListener());
    }

    protected void buildGUI() {
        buildDisplayNewInstanceFormsCheckbox(0);
        buildSelectNewlyCreatedOrAddedInstanceCheckBox(1);
        buildHighlightSelectedRowCheckbox(2);
        buildPrototypeDepthRadioButton(3);
        addVerticalSpace(4);
    }

    private void buildHighlightSelectedRowCheckbox(int yPosition) {
        JCheckBox highlightSelectedRows;
        highlightSelectedRows = createCheckBox("Always highlight selected row", yPosition);
        highlightSelectedRows.setSelected(((InstanceTableWidgetState) _state).isHighlightSelectedRow());
        highlightSelectedRows.addActionListener(new HighlightSelectedRowCheckBoxListener());
    }

    private void buildPrototypeDepthRadioButton(int yPosition) {
        JPanel buttonPanel = new JPanel(new GridLayout(3, 1));
        ButtonGroup buttonGroup = new ButtonGroup();
        addRadioButton(buttonGroup, buttonPanel, "Shallow Copy", 0);
        addRadioButton(buttonGroup, buttonPanel, "Depth 1 Copy", 1);
        addRadioButton(buttonGroup, buttonPanel, "Deep Copy", -1);
        buttonPanel.setBorder(BorderFactory.createEtchedBorder());
        LabeledComponent componentToAdd = new LabeledComponent("Prototype Depth", buttonPanel);
        add(componentToAdd, buildComponentGridBagConstraints(yPosition));
    }

    private void buildSelectNewlyCreatedOrAddedInstanceCheckBox(int yPosition) {
        JCheckBox selectNewlyCreatedOrAddedInstanceCheckBox;
        selectNewlyCreatedOrAddedInstanceCheckBox =
            createCheckBox("Automatically select newly created or added rows", yPosition);
        selectNewlyCreatedOrAddedInstanceCheckBox.setSelected(((InstanceTableWidgetState) _state).isAutoSelectInsertions());
        selectNewlyCreatedOrAddedInstanceCheckBox.addActionListener(new SelectNewlyCreatedOrAddedInstanceCheckBoxListener());
    }

    public void saveContents() {
        ((InstanceTableWidgetState) _state).save();
    }

    public boolean validateContents() {
        return true;
    }
}
