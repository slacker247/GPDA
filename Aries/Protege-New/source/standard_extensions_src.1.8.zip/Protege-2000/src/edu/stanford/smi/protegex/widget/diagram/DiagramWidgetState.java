/*
 * The contents of this file are subject to the Mozilla Public License
 * Version 1.1 (the "License");  you may not use this file except in compliance
 * with the License.  You may obtain a copy of the License at
 * http://www.mozilla.org/MPL/
 *
 * Software distributed under the License is distributed on an "AS IS" basis,
 * WITHOUT WARRANTY OF ANY KIND, either express or implied. See the License for
 * the specific language governing rights and limitations under the License.
 *
 * The Original Code is Protege-2000.
 *
 * The Initial Developer of the Original Code is Stanford University. Portions
 * created by Stanford University are Copyright (C) 2001.  All Rights Reserved.
 *
 * Protege-2000 was developed by Stanford Medical Informatics
 * (http://www.smi.stanford.edu) at the Stanford University School of Medicine
 * with support from the National Library of Medicine, the National Science
 * Foundation, and the Defense Advanced Research Projects Agency.  Current
 * information about Protege can be obtained at http://protege.stanford.edu
 *
 * Contributor(s):
 */

package edu.stanford.smi.protegex.widget.diagram;

import java.util.*;

import edu.stanford.smi.protege.model.*;
import edu.stanford.smi.protege.util.*;
import edu.stanford.smi.protegex.util.*;

/**
 *  Description of the Class
 *
 * @author    William Grosso <grosso@smi.stanford.edu>
 */
public class DiagramWidgetState extends ButtonRelatedWidgetState implements Constants {
    private DiagramWidget _widget;
    private KnowledgeBase _kb;
    private HashMap _nodeClassNamesToDescriptions;
    private HashMap _connectorClassNamesToDescriptions;
    private Collection _connectorClses;
    private Collection _nodeClses;
    private int _lowerBoundOnDiagramWidth;
    private int _lowerBoundOnDiagramHeight;
    private boolean _paletteDisplayed;
    private TypeBasedVisibilityChecker _defaultVisibilityChecker;

    private final static String LOWER_BOUND_ON_DIAGRAM_LOGICAL_WIDTH = ":LOWER:BOUND:ON:DIAGRAM:WIDTH";
    private final static String LOWER_BOUND_ON_DIAGRAM_LOGICAL_HEIGHT = ":LOWER:BOUND:ON:DIAGRAM:HEIGHT";
    private final static String IS_PALETTE_DISPLAYED = ":IS:PALETTE:DISPLAYED";
    private final static String DEFAULT_VISIBILITY_CHECKER = ":DEFAULT:VISIBIITY:CHECKER";

    protected final static String DISPLAY_CLASS_BASED_HIDER_BUTTON = "DISPLAY:CLASS:BASED:HIDER:BUTTON";
    protected final static String DISPLAY_REUSABLE_FORM_BUTTON = "DISPLAY:REUSABLE:FORM:BUTTON";
    protected final static String DISPLAY_LEGEND_BUTTON = "DISPLAY:LEGEND:BUTTON";
    protected final static String DISPLAY_THUMBNAIL_BUTTON = "DISPLAY:THUMBNAIL:BUTTON";
    protected final static String DISPLAY_WIRE_BUILDER_BUTTON = "DISPLAY:WIREBUILDER:BUTTON";
    protected final static String DISPLAY_FLOWCHART_BUTTON = "DISPLAY:FLOWCHART:BUTTON";

    protected final static String CLASS_BASED_HIDER_BUTTON_TOOLTIP = "CLASS:BASED:HIDER:BUTTON:TOOLTIP";
    protected final static String REUSABLE_FORM_BUTTON_TOOLTIP = "REUSABLE:FORM:BUTTON:TOOLTIP";
    protected final static String LEGEND_BUTTON_TOOLTIP = "LEGEND:BUTTON:TOOLTIP";
    protected final static String THUMBNAIL_BUTTON_TOOLTIP = "THUMBNAIL:BUTTON:TOOLTIP";
    protected final static String WIRE_BUILDER_BUTTON_TOOLTIP = "WIRE:BUILDER:BUTTON:TOOLTIP";
    protected final static String FLOWCHART_BUTTON_TOOLTIP = "FLOWCHART:BUTTON:TOOLTIP";

    protected final static String CLASS_BASED_HIDER_BUTTON_TOOLTIP_DEFAULT = "Alter Visibility by Class";
    protected final static String REUSABLE_FORM_BUTTON_TOOLTIP_DEFAULT = "View form for object selected in diagram";
    protected final static String LEGEND_BUTTON_TOOLTIP_DEFAULT = "View Legend";
    protected final static String THUMBNAIL_BUTTON_TOOLTIP_DEFAULT = "View thumbnail map";
    protected final static String WIRE_BUILDER_BUTTON_TOOLTIP_DEFAULT = "View wire builder";
    protected final static String FLOWCHART_BUTTON_TOOLTIP_DEFAULT = "View diagram as flowchart";

    protected boolean _displayClassBasedHiderButton;
    protected boolean _displayReusableFormButton;
    protected boolean _displayLegendButton;
    protected boolean _displayThumbnailButton;
    protected boolean _displayWirebuilderButton;
    protected boolean _displayFlowchartButton;

    protected String _classBasedHiderButtonTooltip;
    protected String _reusableFormButtonTooltip;
    protected String _legendButtonTooltip;
    protected String _thumbnailButtonTooltip;
    protected String _wirebuilderButtonTooltip;
    protected String _flowchartButtonTooltip;

    public DiagramWidgetState(DiagramWidget widget, PropertyList properties) {
        super(properties);
        _widget = widget;
        _kb = _widget.getKnowledgeBase();
        initializeFromNetworkDescription();
    }

    private void findConnectorClassesAndDescriptions() {
        _connectorClassNamesToDescriptions = new HashMap();
        Slot connectorsSlot = _kb.getSlot(CONNECTORS_SLOT);
        Cls networkCls = _widget.getCls();
        Collection connectorSuperClses = networkCls.getTemplateSlotAllowedClses(connectorsSlot);
        _connectorClses = getAllConcreteSubclasses(connectorSuperClses);
        Iterator i = _connectorClses.iterator();
        while (i.hasNext()) {
            Cls nextCls = (Cls) i.next();
            String clsName = nextCls.getName();
            PropertyList configInfo = _properties.getPropertyList(clsName);
            _connectorClassNamesToDescriptions.put(clsName, new WireState(configInfo));
        }
        return;
    }

    private void findNodeClassesAndDescriptions() {
        _nodeClassNamesToDescriptions = new HashMap();
        Cls networkCls = _widget.getCls();
        Collection nodeSuperClses = networkCls.getTemplateSlotAllowedClses(_widget.getSlot());
        _nodeClses = getAllConcreteSubclasses(nodeSuperClses);
        Iterator i = _nodeClses.iterator();
        while (i.hasNext()) {
            Cls nextCls = (Cls) i.next();
            String clsName = nextCls.getName();
            PropertyList configInfo = _properties.getPropertyList(clsName);
            _nodeClassNamesToDescriptions.put(clsName, new NodeState(configInfo));
        }
        return;
    }

    private Collection getAllConcreteSubclasses(Collection clses) {
        Collection result = new HashSet();
        Iterator i = clses.iterator();
        while (i.hasNext()) {
            Cls cls = (Cls) i.next();
            if (cls.isConcrete()) {
                result.add(cls);
            }
            result.addAll(getConcreteSubclasses(cls));
        }
        return result;
    }

    // tooltips
    public String getClassBasedHiderButtonTooltip() {
        return _classBasedHiderButtonTooltip;
    }

    private Collection getConcreteSubclasses(Cls cls) {
        Collection result = new HashSet();
        Iterator i = cls.getSubclasses().iterator();
        while (i.hasNext()) {
            Cls subclass = (Cls) i.next();
            if (subclass.isConcrete()) {
                result.add(subclass);
            }
        }
        return result;
    }

    public Collection getConnectorClses() {
        return _connectorClses;
    }

    public TypeBasedVisibilityChecker getDefaultVisibilityChecker() {
        return _defaultVisibilityChecker;
    }

    //PM
    public String getFlowchartButtonTooltip() {
        return _flowchartButtonTooltip;
    }

    public String getLegendButtonTooltip() {
        return _legendButtonTooltip;
    }

    public int getLowerBoundOnDiagramHeight() {
        return _lowerBoundOnDiagramHeight;
    }

    public int getLowerBoundOnDiagramWidth() {
        return _lowerBoundOnDiagramWidth;
    }

    public Collection getNodeClses() {
        return _nodeClses;
    }

    public boolean getPaletteDisplayed() {
        return _paletteDisplayed;
    }

    public String getReusableFormButtonTooltip() {
        return _reusableFormButtonTooltip;
    }

    public WireState getStateForConnector(Cls connectorClass) {
        return getStateForConnector(connectorClass.getName());
    }

    public WireState getStateForConnector(Instance connectorInstance) {
        return getStateForConnector(connectorInstance.getDirectType());
    }

    public WireState getStateForConnector(String connectorClassName) {
        return (WireState) _connectorClassNamesToDescriptions.get(connectorClassName);
    }

    public NodeState getStateForNode(Cls nodeClass) {
        return getStateForNode(nodeClass.getName());
    }

    public NodeState getStateForNode(Instance nodeInstance) {
        return getStateForNode(nodeInstance.getDirectType());
    }

    public NodeState getStateForNode(String nodeClassName) {
        return (NodeState) _nodeClassNamesToDescriptions.get(nodeClassName);
    }

    public String getThumbnailButtonTooltip() {
        return _thumbnailButtonTooltip;
    }

    //end
    public String getWirebuilderButtonTooltip() {
        return _wirebuilderButtonTooltip;
    }

    private void initializeFromNetworkDescription() {
        if (null == _widget) {
            return;
        }
        findNodeClassesAndDescriptions();
        findConnectorClassesAndDescriptions();
    }

    // buttons
    public boolean isDisplayClassBasedHiderButton() {
        return _displayClassBasedHiderButton;
    }

    //PM
    public boolean isDisplayFlowchartButton() {
        return _displayFlowchartButton;
    }

    public boolean isDisplayLegendButton() {
        return _displayLegendButton;
    }

    public boolean isDisplayReusableFormButton() {
        return _displayReusableFormButton;
    }

    public boolean isDisplayThumbnailButton() {
        return _displayThumbnailButton;
    }

    //end
    public boolean isDisplayWirebuilderButton() {
        return _displayWirebuilderButton;
    }

    public boolean isPaletteDisplayed() {
        return _paletteDisplayed;
    }

    public void restore() {
        super.restore();
        initializeFromNetworkDescription();
        PropertyList visibilityDescriptionPList = _properties.getPropertyList(DEFAULT_VISIBILITY_CHECKER);
        _defaultVisibilityChecker = new TypeBasedVisibilityChecker(visibilityDescriptionPList, _kb);

        _displayClassBasedHiderButton = readBoolean(DISPLAY_CLASS_BASED_HIDER_BUTTON, true);
        _displayReusableFormButton = readBoolean(DISPLAY_REUSABLE_FORM_BUTTON, true);
        _displayLegendButton = readBoolean(DISPLAY_LEGEND_BUTTON, true);
        _displayThumbnailButton = readBoolean(DISPLAY_THUMBNAIL_BUTTON, true);
        _displayWirebuilderButton = readBoolean(DISPLAY_WIRE_BUILDER_BUTTON, true);
        _displayFlowchartButton = readBoolean(DISPLAY_FLOWCHART_BUTTON, true);
        //PM
        _classBasedHiderButtonTooltip = readString(CLASS_BASED_HIDER_BUTTON_TOOLTIP, CLASS_BASED_HIDER_BUTTON_TOOLTIP_DEFAULT);
        _reusableFormButtonTooltip = readString(REUSABLE_FORM_BUTTON_TOOLTIP, REUSABLE_FORM_BUTTON_TOOLTIP_DEFAULT);
        _legendButtonTooltip = readString(LEGEND_BUTTON_TOOLTIP, LEGEND_BUTTON_TOOLTIP_DEFAULT);
        _thumbnailButtonTooltip = readString(THUMBNAIL_BUTTON_TOOLTIP, THUMBNAIL_BUTTON_TOOLTIP_DEFAULT);
        _wirebuilderButtonTooltip = readString(WIRE_BUILDER_BUTTON_TOOLTIP, WIRE_BUILDER_BUTTON_TOOLTIP_DEFAULT);
        _flowchartButtonTooltip = readString(FLOWCHART_BUTTON_TOOLTIP, FLOWCHART_BUTTON_TOOLTIP_DEFAULT);
        //PM
        _lowerBoundOnDiagramWidth = readInt(LOWER_BOUND_ON_DIAGRAM_LOGICAL_WIDTH, DEFAULT_LOWER_BOUND_ON_DIAGRAM_LOGICAL_WIDTH);
        _lowerBoundOnDiagramHeight =
            readInt(LOWER_BOUND_ON_DIAGRAM_LOGICAL_HEIGHT, DEFAULT_LOWER_BOUND_ON_DIAGRAM_LOGICAL_HEIGHT);
        _paletteDisplayed = readBoolean(IS_PALETTE_DISPLAYED, true);
    }

    public void save() {
        writeOutHashMap(_nodeClassNamesToDescriptions);
        writeOutHashMap(_connectorClassNamesToDescriptions);
        if (null != _defaultVisibilityChecker) {
            PropertyList visibilityDescriptionPList = _properties.getPropertyList(DEFAULT_VISIBILITY_CHECKER);
            _defaultVisibilityChecker.writeToPropertyList(visibilityDescriptionPList);
        }
        _properties.setBoolean(DISPLAY_CLASS_BASED_HIDER_BUTTON, _displayClassBasedHiderButton);
        _properties.setBoolean(DISPLAY_REUSABLE_FORM_BUTTON, _displayReusableFormButton);
        _properties.setBoolean(DISPLAY_LEGEND_BUTTON, _displayLegendButton);
        _properties.setBoolean(DISPLAY_THUMBNAIL_BUTTON, _displayThumbnailButton);
        _properties.setBoolean(DISPLAY_WIRE_BUILDER_BUTTON, _displayWirebuilderButton);
        _properties.setBoolean(DISPLAY_FLOWCHART_BUTTON, _displayFlowchartButton);

        _properties.setString(CLASS_BASED_HIDER_BUTTON_TOOLTIP, _classBasedHiderButtonTooltip);
        _properties.setString(REUSABLE_FORM_BUTTON_TOOLTIP, _reusableFormButtonTooltip);
        _properties.setString(LEGEND_BUTTON_TOOLTIP, _legendButtonTooltip);
        _properties.setString(THUMBNAIL_BUTTON_TOOLTIP, _thumbnailButtonTooltip);
        _properties.setString(WIRE_BUILDER_BUTTON_TOOLTIP, _wirebuilderButtonTooltip);

        _properties.setInteger(LOWER_BOUND_ON_DIAGRAM_LOGICAL_WIDTH, _lowerBoundOnDiagramWidth);
        _properties.setInteger(LOWER_BOUND_ON_DIAGRAM_LOGICAL_HEIGHT, _lowerBoundOnDiagramHeight);
        _properties.setBoolean(IS_PALETTE_DISPLAYED, _paletteDisplayed);
        super.save();
    }

    public void setClassBasedHiderButtonTooltip(String classBasedHiderButtonTooltip) {
        _classBasedHiderButtonTooltip = classBasedHiderButtonTooltip;
    }

    public void setDefaultVisibilityChecker(TypeBasedVisibilityChecker defaultVisibilityChecker) {
        _defaultVisibilityChecker = defaultVisibilityChecker;
    }

    public void setDisplayClassBasedHiderButton(Boolean displayClassBasedHiderButton) {
        _displayClassBasedHiderButton = displayClassBasedHiderButton.booleanValue();
    }

    public void setDisplayClassBasedHiderButton(boolean displayClassBasedHiderButton) {
        _displayClassBasedHiderButton = displayClassBasedHiderButton;
    }

    public void setDisplayFlowchartButton(Boolean displayFlowchartButton) {
        _displayFlowchartButton = displayFlowchartButton.booleanValue();
    }

    public void setDisplayFlowchartButton(boolean displayFlowchartButton) {
        _displayFlowchartButton = displayFlowchartButton;
    }

    public void setDisplayLegendButton(Boolean displayLegendButton) {
        _displayLegendButton = displayLegendButton.booleanValue();
    }

    public void setDisplayLegendButton(boolean displayLegendButton) {
        _displayLegendButton = displayLegendButton;
    }

    public void setDisplayReusableFormButton(Boolean displayReusableFormButton) {
        _displayReusableFormButton = displayReusableFormButton.booleanValue();
    }

    public void setDisplayReusableFormButton(boolean displayReusableFormButton) {
        _displayReusableFormButton = displayReusableFormButton;
    }

    public void setDisplayThumbnailButton(Boolean displayThumbnailButton) {
        _displayThumbnailButton = displayThumbnailButton.booleanValue();
    }

    public void setDisplayThumbnailButton(boolean displayThumbnailButton) {
        _displayThumbnailButton = displayThumbnailButton;
    }

    public void setDisplayWirebuilderButton(Boolean displayWirebuilderButton) {
        _displayWirebuilderButton = displayWirebuilderButton.booleanValue();
    }

    public void setDisplayWirebuilderButton(boolean displayWirebuilderButton) {
        _displayWirebuilderButton = displayWirebuilderButton;
    }

    public void setFlowchartButtonTooltip(String flowchartButtonTooltip) {
        _flowchartButtonTooltip = flowchartButtonTooltip;
    }

    public void setLegendButtonTooltip(String legendButtonTooltip) {
        _legendButtonTooltip = legendButtonTooltip;
    }

    public void setLowerBoundOnDiagramHeight(int lowerBoundOnDiagramHeight) {
        _lowerBoundOnDiagramHeight = lowerBoundOnDiagramHeight;
    }

    public void setLowerBoundOnDiagramWidth(int lowerBoundOnDiagramWidth) {
        _lowerBoundOnDiagramWidth = lowerBoundOnDiagramWidth;
    }

    public void setPaletteDisplayed(boolean paletteDisplayed) {
        _paletteDisplayed = paletteDisplayed;
    }

    public void setReusableFormButtonTooltip(String reusableFormButtonTooltip) {
        _reusableFormButtonTooltip = reusableFormButtonTooltip;
    }

    public void setThumbnailButtonTooltip(String thumbnailButtonTooltip) {
        _thumbnailButtonTooltip = thumbnailButtonTooltip;
    }

    public void setWirebuilderButtonTooltip(String wirebuilderButtonTooltip) {
        _wirebuilderButtonTooltip = wirebuilderButtonTooltip;
    }

    private void writeOutHashMap(HashMap hashMapToDiagramObjectStates) {
        Iterator i = (hashMapToDiagramObjectStates.keySet()).iterator();
        while (i.hasNext()) {
            String clsName = (String) i.next();
            DiagramObjectState diagramObjectState = (DiagramObjectState) hashMapToDiagramObjectStates.get(clsName);
            PropertyList configInfo = _properties.getPropertyList(clsName);
            diagramObjectState.writeToPropertyList(configInfo);
        }
    }
}
