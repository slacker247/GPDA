/*
 * The contents of this file are subject to the Mozilla Public License
 * Version 1.1 (the "License");  you may not use this file except in compliance
 * with the License.  You may obtain a copy of the License at
 * http://www.mozilla.org/MPL/
 *
 * Software distributed under the License is distributed on an "AS IS" basis,
 * WITHOUT WARRANTY OF ANY KIND, either express or implied. See the License for
 * the specific language governing rights and limitations under the License.
 *
 * The Original Code is Protege-2000.
 *
 * The Initial Developer of the Original Code is Stanford University. Portions
 * created by Stanford University are Copyright (C) 2001.  All Rights Reserved.
 *
 * Protege-2000 was developed by Stanford Medical Informatics
 * (http://www.smi.stanford.edu) at the Stanford University School of Medicine
 * with support from the National Library of Medicine, the National Science
 * Foundation, and the Defense Advanced Research Projects Agency.  Current
 * information about Protege can be obtained at http://protege.stanford.edu
 *
 * Contributor(s):
 */

package edu.stanford.smi.protegex.layout;

import java.awt.event.*;
import java.awt.*;
import java.util.*;
import javax.swing.*;

/**
 *  Description of the Class
 *
 * @author    William Grosso <grosso@smi.stanford.edu>
 */
public abstract class AbstractActor implements Actor {
    protected AnimationContext _animationContext;
    protected ActorLocation _location;
    protected ActorEventHandler _eventHandler;
    protected ActorMovementHandler _movementHandler;
    protected ActorControlPointHandler _controlPointHandler;
    protected Rectangle _lastDrawingLocation;
    protected ActorEventBroadcaster _broadcaster;

    public AbstractActor(
        AnimationContext animationContext,
        ActorLocation location,
        ActorEventHandler eventHandler,
        ActorMovementHandler movementHandler,
        ActorControlPointHandler controlPointHandler) {
        _animationContext = animationContext;
        _location = location;
        _eventHandler = eventHandler;
        _movementHandler = movementHandler;
        _controlPointHandler = controlPointHandler;
        _lastDrawingLocation = new Rectangle();
        _broadcaster = new ActorEventBroadcasterImpl(this);
        synchronizeAggregates();
    }

    // Broadcasting (semantic) events
    public void addActorListener(ActorListener actorListener) {
        _broadcaster.addActorListener(actorListener);
    }

    public void broadcastActorDoubleClickedEvent() {
        _broadcaster.broadcastActorDoubleClickedEvent();
    }

    public void broadcastActorMovedEvent() {
        _broadcaster.broadcastActorMovedEvent();
    }

    public void broadcastActorResizedEvent() {
        _broadcaster.broadcastActorResizedEvent();
    }

    public void broadcastActorSelectedEvent() {
        _broadcaster.broadcastActorSelectedEvent();
    }

    public void broadcastActorStartedMovingEvent() {
        _broadcaster.broadcastActorStartedMovingEvent();
    }

    public void broadcastActorStoppedMovingEvent() {
        _broadcaster.broadcastActorStoppedMovingEvent();
    }

    public boolean canPerformIncrementalDrag(int deltaX, int deltaY) {
        return _eventHandler.canPerformIncrementalDrag(deltaX, deltaY);
    }

    public boolean collidesWithActor(Actor actor) {
        return _movementHandler.collidesWithActor(actor);
    }

    public void collideWithActor(Actor actor) {
        _movementHandler.collideWithActor(actor);
    }

    // Left to subclasses
    public abstract Object copy();

    public abstract Rectangle draw(Graphics g);

    /*
         * These next two are here as a hack
         */

    public Actor getActor() {
        return this;
    }

    public AnimationContext getAnimationContext() {
        return _animationContext;
    }

    // Movement Handling
    public boolean getBounces() {
        return _movementHandler.getBounces();
    }

    public void getControlPoint(int controlPoint, Point returnValue) {
        _controlPointHandler.getControlPoint(controlPoint, returnValue);
    }

    public int getControlPointForPoint(Point inputLocation) {
        return _controlPointHandler.getControlPointForPoint(inputLocation);
    }

    public boolean getIsDraggable() {
        return _eventHandler.getIsDraggable();
    }

    public boolean getIsDragging() {
        return _eventHandler.getIsDragging();
    }

    public boolean getIsResizable() {
        return _eventHandler.getIsResizable();
    }

    public boolean getIsResizing() {
        return _eventHandler.getIsResizing();
    }

    public boolean getIsSelectable() {
        return _eventHandler.getIsSelectable();
    }

    // Event Handling
    public boolean getIsSelected() {
        return _eventHandler.getIsSelected();
    }

    public ActorLocation getLocation() {
        return _location;
    }

    public int getMinimumSize() {
        return _controlPointHandler.getMinimumSize();
    }

    public int getPrecision() {
        return _controlPointHandler.getPrecision();
    }

    public double getXVelocity() {

        return _movementHandler.getXVelocity();
    }

    public double getYVelocity() {
        return _movementHandler.getYVelocity();
    }

    public boolean isInside(Rectangle location) {
        return _location.isInside(location);
    }

    // Interactions with the AnimationFrame
    public boolean isLocatedAt(Point location) {
        return _location.contains(location);
    }

    public abstract boolean isWire();

    public void move(int x, int y) {
        _location.move(x, y);
    }

    public void moveControlPoint(int controlPoint, Point destinationPoint) {
        _controlPointHandler.moveControlPoint(controlPoint, destinationPoint);
    }

    public void processClick(MouseEvent e) {
        _eventHandler.processClick(e);
    }

    public void processDrag(MouseEvent e) {
        _eventHandler.processDrag(e);
    }

    public void processIncrementalDrag(int deltaX, int deltaY) {
        _eventHandler.processIncrementalDrag(deltaX, deltaY);
    }

    public void processMousePress(MouseEvent e) {

        _eventHandler.processMousePress(e);

    }

    public void processMouseRelease(MouseEvent e) {
        _eventHandler.processMouseRelease(e);
    }

    public void removeActorListener(ActorListener actorListener) {
        _broadcaster.removeActorListener(actorListener);
    }

    public void setActor(Actor actor) {
        throw new Error("setActor called on Actor");
    }

    public void setAnimationContext(AnimationContext animationContext) {
        _animationContext = animationContext;
    }

    public void setBounces(boolean bounces) {
        _movementHandler.setBounces(bounces);
    }

    public void setControlPointHandler(ActorControlPointHandler controlPointHandler) {
        _controlPointHandler = controlPointHandler;
        _controlPointHandler.setActor(this);
    }

    public void setCoordinateSystem(Rectangle rectangle) {
        _location.setCoordinateSystem(rectangle);
        _location.moveInsideCoordinateSystem();
    }

    public void setEventHandler(ActorEventHandler actorEventHandler) {
        _eventHandler = actorEventHandler;
        _eventHandler.setActor(this);
    }

    public void setIsDraggable(boolean isDraggable) {
        _eventHandler.setIsDraggable(isDraggable);
    }

    public void setIsResizable(boolean isResizable) {
        _eventHandler.setIsResizable(isResizable);
    }

    public void setIsSelectable(boolean isSelectable) {
        _eventHandler.setIsSelectable(isSelectable);
    }

    public void setIsSelected(boolean isSelected) {
        _eventHandler.setIsSelected(isSelected);
    }

    // Setup and Basic Properties
    public void setLocation(ActorLocation location) {
        _location = location;
        synchronizeLocation();
    }

    public void setMinimumSize(int minimumSize) {
        _controlPointHandler.setMinimumSize(minimumSize);
    }

    public void setMovementHandler(ActorMovementHandler actorMovementHandler) {
        _movementHandler = actorMovementHandler;
        _movementHandler.setActor(this);
    }

    // ControlPoint Functionality
    public void setPrecision(int precision) {
        _controlPointHandler.setPrecision(precision);
    }

    public abstract void setTitle(String title);

    public void setXVelocity(double xVelocity) {
        _movementHandler.setXVelocity(xVelocity);
    }

    public void setYVelocity(double yVelocity) {
        _movementHandler.setYVelocity(yVelocity);
    }

    private void synchronizeAggregates() {
        if (null != _eventHandler) {
            _eventHandler.setActor(this);
        }
        if (null != _movementHandler) {
            _movementHandler.setActor(this);
        }
        if (null != _controlPointHandler) {
            _controlPointHandler.setActor(this);
        }
    }

    private void synchronizeLocation() {
        _eventHandler.setLocation(_location);
        _movementHandler.setLocation(_location);
        _controlPointHandler.setLocation(_location);
    }

    public abstract void tick(int currentTime);

    public void translate(int x, int y) {
        _location.translate(x, y);
    }

    public void translateControlPoint(int controlPoint, int deltaX, int deltaY) {
        _controlPointHandler.translateControlPoint(controlPoint, deltaX, deltaY);
    }

    public boolean wantEvent(MouseEvent e) {

        return _controlPointHandler.wantEvent(e);
    }
}
