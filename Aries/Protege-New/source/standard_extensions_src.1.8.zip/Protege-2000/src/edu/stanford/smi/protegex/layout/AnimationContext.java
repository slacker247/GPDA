/*
 * The contents of this file are subject to the Mozilla Public License
 * Version 1.1 (the "License");  you may not use this file except in compliance
 * with the License.  You may obtain a copy of the License at
 * http://www.mozilla.org/MPL/
 *
 * Software distributed under the License is distributed on an "AS IS" basis,
 * WITHOUT WARRANTY OF ANY KIND, either express or implied. See the License for
 * the specific language governing rights and limitations under the License.
 *
 * The Original Code is Protege-2000.
 *
 * The Initial Developer of the Original Code is Stanford University. Portions
 * created by Stanford University are Copyright (C) 2001.  All Rights Reserved.
 *
 * Protege-2000 was developed by Stanford Medical Informatics
 * (http://www.smi.stanford.edu) at the Stanford University School of Medicine
 * with support from the National Library of Medicine, the National Science
 * Foundation, and the Defense Advanced Research Projects Agency.  Current
 * information about Protege can be obtained at http://protege.stanford.edu
 *
 * Contributor(s):
 */

package edu.stanford.smi.protegex.layout;

import java.awt.*;
import java.awt.event.*;
import java.util.*;

/**
 *  Description of the Class
 *
 * @author    William Grosso <grosso@smi.stanford.edu>
 */
public class AnimationContext {
    protected ZOrder _zOrder;
    protected BackgroundManager _backgroundManager;
    // handles drawing of wallpaper
    protected Rectangle _coordinateSystem;
    protected Component _owner;
    protected AnimationContextMouseEventHandler _animationContextMouseEventHandler;
    protected TickAction _tickAction;
    protected PaintAction _paintAction;
    protected AnimationContextSelectionHandler _selectionHandler;

    private class TickAction implements ActorAction {
        private int _currentTime;

        public void performMethod(Actor target) {
            target.tick(_currentTime);
        }

        public void setTime(int currentTime) {
            _currentTime = currentTime;
        }
    }

    private class PaintAction implements ActorAction {
        private Graphics _g;

        public void performMethod(Actor target) {
            _backgroundManager.addDirtyRect(target.draw(_g));
        }

        public void setGraphics(Graphics g) {
            _g = g;
        }
    }

    public AnimationContext(
        boolean visibleToEvents,
        BackgroundManager backgroundManager,
        Rectangle coordinateSystem,
        Component owner,
        AnimationContextMouseEventHandler animationContextMouseEventHandler) {
        _zOrder = new ZOrder();
        _animationContextMouseEventHandler = animationContextMouseEventHandler;
        _animationContextMouseEventHandler.setAnimationContext(this);
        _selectionHandler = new AnimationContextSelectionHandler(this);
        setVisibleToEvents(visibleToEvents);
        _backgroundManager = backgroundManager;
        _coordinateSystem = coordinateSystem;
        if (_coordinateSystem == null) {
            _coordinateSystem = owner.getBounds();
        }
        _tickAction = new TickAction();
        _paintAction = new PaintAction();
        _owner = owner;
    }

    public void addActorToBottom(Actor actor) {
        _zOrder.addActorToBottom(actor);
        configureActor(actor);
    }

    // ZOrder stuff
    public void addActorToTop(Actor actor) {
        _zOrder.addActorToTop(actor);
        configureActor(actor);
    }

    public void addAnimationContextSelectionListener(AnimationContextSelectionListener newListener) {
        _selectionHandler.addAnimationContextSelectionListener(newListener);
    }

    private void configureActor(Actor actor) {
        actor.setAnimationContext(this);
        actor.setCoordinateSystem(_coordinateSystem);
    }

    public Rectangle getActiveRectangle() {
        return _selectionHandler.getActiveRectangle();
    }

    public Rectangle getActiveRectangle(Rectangle returnValue) {
        return _selectionHandler.getActiveRectangle(returnValue);
    }

    public Rectangle getCoordinateSystem() {
        return new Rectangle(_coordinateSystem);
    }

    public Rectangle getCoordinateSystem(Rectangle returnValue) {
        returnValue.x = _coordinateSystem.x;
        returnValue.y = _coordinateSystem.y;
        returnValue.height = _coordinateSystem.height;
        returnValue.width = _coordinateSystem.width;
        return returnValue;
    }

    public Actor getLeadSelection() {
        return _selectionHandler.getLeadSelection();
    }

    public Component getOwner() {
        return _owner;
    }

    public Collection getSelectedActors() {
        return _selectionHandler.getSelections();
    }

    public boolean getVisibleToEvents() {
        return _animationContextMouseEventHandler.getVisibleToEvents();
    }

    public ZOrder getZOrder() {
        return _zOrder;
    }

    public boolean isSingleSelection() {
        return _selectionHandler.isSingleSelection();
    }

    public void moveActorToBottom(Actor actor) {
        _zOrder.removeActor(actor);
        addActorToBottom(actor);
    }

    public void moveActorToTop(Actor actor) {
        _zOrder.removeActor(actor);
        addActorToTop(actor);
    }

    public void paint(Graphics g) {
        _paintAction.setGraphics(g);
        _backgroundManager.refreshBackground(g);
        _zOrder.performAction(ZOrder.BOTTOMUP, _paintAction);
    }

    public void processMouseEvent(MouseEvent e) {
        _animationContextMouseEventHandler.processMouseEvent(e);
    }

    public void processMouseMotionEvent(MouseEvent e) {
        _animationContextMouseEventHandler.processMouseMotionEvent(e);
    }

    public void removeActor(Actor actor) {
        _zOrder.removeActor(actor);
    }

    public void removeAnimationContextSelectionListener(AnimationContextSelectionListener oldListener) {
        _selectionHandler.removeAnimationContextSelectionListener(oldListener);
    }

    public void selectActor(Actor actor) {
        _selectionHandler.selectActor(actor);
    }

    public void setBackgroundManager(BackgroundManager backgroundManager) {
        _backgroundManager = backgroundManager;
        _backgroundManager.backgroundHasChangedSize();
    }

    public void setCoordinateSystem(Rectangle coordinateSystem) {
        _coordinateSystem = coordinateSystem;
        _backgroundManager.backgroundHasChangedSize();
        _zOrder.performAction(ZOrder.TOPDOWN, new ActorAction() {
            public void performMethod(Actor target) {
                target.setCoordinateSystem(_coordinateSystem);
            }
        });
    }

    public void setSelectedActor(Actor actor) {
        _selectionHandler.setSelectedActor(actor);
    }

    // Mouse-based Event Handling
    public void setVisibleToEvents(boolean visibleToEvents) {
        _animationContextMouseEventHandler.setVisibleToEvents(visibleToEvents);
    }

    public void takeSnapshot(Graphics g) {
        _backgroundManager.drawEntireBackground(g);
        _paintAction.setGraphics(g);
        _zOrder.performAction(ZOrder.BOTTOMUP, _paintAction);
    }

    public void unselectActor(Actor actor) {
        _selectionHandler.unselectActor(actor);
    }

    public boolean wantEvent(MouseEvent e) {
        return _animationContextMouseEventHandler.wantEvent(e);
    }
}
