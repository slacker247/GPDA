/*
 * The contents of this file are subject to the Mozilla Public License
 * Version 1.1 (the "License");  you may not use this file except in compliance
 * with the License.  You may obtain a copy of the License at
 * http://www.mozilla.org/MPL/
 *
 * Software distributed under the License is distributed on an "AS IS" basis,
 * WITHOUT WARRANTY OF ANY KIND, either express or implied. See the License for
 * the specific language governing rights and limitations under the License.
 *
 * The Original Code is Protege-2000.
 *
 * The Initial Developer of the Original Code is Stanford University. Portions
 * created by Stanford University are Copyright (C) 2001.  All Rights Reserved.
 *
 * Protege-2000 was developed by Stanford Medical Informatics
 * (http://www.smi.stanford.edu) at the Stanford University School of Medicine
 * with support from the National Library of Medicine, the National Science
 * Foundation, and the Defense Advanced Research Projects Agency.  Current
 * information about Protege can be obtained at http://protege.stanford.edu
 *
 * Contributor(s):
 */

package edu.stanford.smi.protege.widget;

import javax.swing.*;

import edu.stanford.smi.protege.model.*;

/**
 * Basic interface for all tab widgets.
 *
 * @author Ray Fergerson <fergerson@smi.stanford.edu>
 */
public interface TabWidget extends Widget {

    /**
     * Called when the user attempts to close a project.  Return 'true' you tab is in such a state that a close is 
     * possible.  If for some reason you must prevent a close then you must pop up a dialog letting the user know why
     * the close is not allowed.  You should then return 'false'.  Most tabs will always return true.
     */
    boolean canClose();

    /**
     * Called when the user attempts to save a project.  Return 'true' you tab is in such a state that a save is 
     * possible.  If for some reason you must prevent a save then you must pop up a dialog letting the user know why
     * the save is not allowed.  You should then return 'false'.  Most tabs will always return true.
     */
    boolean canSave();

    /**
     * Called when the user attempts to close a project and all tabs return 'true' from their #canClose() methods.  
     * Do any tab specific close operations in this method.  Most tabs will do nothing.
     */
    void close();

    Icon getIcon();

    String getShortDescription();

    /**
     * Called when the user attempts to save a project and all tabs return 'true' from their #canSave() methods.  
     * Do any tab specific save operations in this method.  Most tabs will do nothing.
     */
    void save();

    void setup(WidgetDescriptor descriptor, Project project);
}
