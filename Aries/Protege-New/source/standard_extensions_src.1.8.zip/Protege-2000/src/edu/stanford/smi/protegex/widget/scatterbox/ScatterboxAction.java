/*
 * The contents of this file are subject to the Mozilla Public License
 * Version 1.1 (the "License");  you may not use this file except in compliance
 * with the License.  You may obtain a copy of the License at
 * http://www.mozilla.org/MPL/
 *
 * Software distributed under the License is distributed on an "AS IS" basis,
 * WITHOUT WARRANTY OF ANY KIND, either express or implied. See the License for
 * the specific language governing rights and limitations under the License.
 *
 * The Original Code is Protege-2000.
 *
 * The Initial Developer of the Original Code is Stanford University. Portions
 * created by Stanford University are Copyright (C) 2001.  All Rights Reserved.
 *
 * Protege-2000 was developed by Stanford Medical Informatics
 * (http://www.smi.stanford.edu) at the Stanford University School of Medicine
 * with support from the National Library of Medicine, the National Science
 * Foundation, and the Defense Advanced Research Projects Agency.  Current
 * information about Protege can be obtained at http://protege.stanford.edu
 *
 * Contributor(s):
 */

package edu.stanford.smi.protegex.widget.scatterbox;

import java.awt.event.*;

import javax.swing.*;
import javax.swing.event.*;

import edu.stanford.smi.protege.model.*;

/**
 *  Description of the class
 *
 * @author    William Grosso <grosso@smi.stanford.edu>
 */
public abstract class ScatterboxAction extends AbstractAction implements ScatterboxWidgetListener {
    protected ScatterboxWidget _widget;
    protected Project _project;
    protected KnowledgeBase _kb;
    protected ScatterboxWidgetState _state;
    protected ScatterboxTable _table;
    protected ScatterboxTableModel _model;
    protected KBQueryUtils _queryUtilsObject;

    private class OurTableModelListener implements TableModelListener {
        public void tableChanged(TableModelEvent e) {
            setActivation();
        }
    }

    public ScatterboxAction(
        ScatterboxWidget widget,
        String tooltipString,
        Icon icon,
        ScatterboxTable table,
        ScatterboxTableModel model,
        KBQueryUtils queryUtilsObject) {
        super(tooltipString, icon);
        _queryUtilsObject = queryUtilsObject;
        _table = table;
        _model = model;
        _project = widget.getProject();
        _state = widget.getState();
        _kb = widget.getKnowledgeBase();
        _widget = widget;
        _widget.addSelectionObserver(this);
        _model.addTableModelListener(new OurTableModelListener());
        setActivation();
    }

    public void actionPerformed(ActionEvent e) {
        int selectedRow = _table.getSelectedRow();
        int selectedColumn = _table.getSelectedColumn();
        if ((selectedRow < 0) || (selectedColumn < 0)) {
            return;
        }
        performTask(selectedRow, selectedColumn);
        _table.repaint();
    }

    protected abstract void performTask(int row, int column);

    public void scatterboxWidgetSelectionChanged() {
        setActivation();
    }

    protected abstract void setActivation();
}
