/*
 * The contents of this file are subject to the Mozilla Public License
 * Version 1.1 (the "License");  you may not use this file except in compliance
 * with the License.  You may obtain a copy of the License at
 * http://www.mozilla.org/MPL/
 *
 * Software distributed under the License is distributed on an "AS IS" basis,
 * WITHOUT WARRANTY OF ANY KIND, either express or implied. See the License for
 * the specific language governing rights and limitations under the License.
 *
 * The Original Code is Protege-2000.
 *
 * The Initial Developer of the Original Code is Stanford University. Portions
 * created by Stanford University are Copyright (C) 2001.  All Rights Reserved.
 *
 * Protege-2000 was developed by Stanford Medical Informatics
 * (http://www.smi.stanford.edu) at the Stanford University School of Medicine
 * with support from the National Library of Medicine, the National Science
 * Foundation, and the Defense Advanced Research Projects Agency.  Current
 * information about Protege can be obtained at http://protege.stanford.edu
 *
 * Contributor(s):
 */

package edu.stanford.smi.protegex.widget.diagram;

import edu.stanford.smi.protege.model.*;
import edu.stanford.smi.protegex.layout.*;

import java.util.*;
import javax.swing.*;
import java.awt.*;
import java.awt.event.*;

/**
 *  Description of the class
 *
 * @author    William Grosso <grosso@smi.stanford.edu>
 */
public class MainWirebuilderPanel extends JPanel {
    private JLabel _firstObjectLabel;
    private JLabel _secondObjectLabel;
    private JButton _buildWire;

    private AnimationContext _widgetAnimationContext;
    private MainDrawingPanel _widgetDrawingPanel;
    private BuildWireButtonListener _buildWireButtonListener;
    private DiagramWidget _widget;

    private class ACSelectionListener implements AnimationContextSelectionListener {
        public void animationContextSelectionChanged(AnimationContextSelectionEvent event) {
            resetGUI();
        }
    }

    public MainWirebuilderPanel(DiagramWidget widget) {
        super(new BorderLayout());
        _widget = widget;
        _widgetAnimationContext = widget.getMainDrawingArea();
        _widgetAnimationContext.addAnimationContextSelectionListener(new ACSelectionListener());
        _widgetDrawingPanel = widget.getMainDrawingPanel();
        buildGUI();
        resetGUI();
    }

    private void buildGUI() {
        JPanel topPanel = new JPanel(new GridLayout(2, 2));
        topPanel.add(new JLabel("First object:"));
        topPanel.add(_firstObjectLabel = new JLabel());
        topPanel.add(new JLabel("Second object:"));
        topPanel.add(_secondObjectLabel = new JLabel());
        add(topPanel, BorderLayout.CENTER);
        _buildWire = new JButton("Build Wire");
        _buildWire.addActionListener(_buildWireButtonListener = new BuildWireButtonListener(null, this, _widget, _buildWire));
        add(_buildWire, BorderLayout.SOUTH);
    }

    private Instance findNodeInstance(Iterator i) {
        while (i.hasNext()) {
            Object nextObject = i.next();
            if (nextObject instanceof GlyphActorInstance) {
                GlyphActorInstance glyphActorInstance = (GlyphActorInstance) nextObject;
                return glyphActorInstance.getInstance();
            }
        }
        return null;
    }

    private void resetGUI() {
        Instance firstNode = null;
        Instance secondNode = null;
        Collection selectedActors = _widgetAnimationContext.getSelectedActors();
        Iterator i = selectedActors.iterator();
        firstNode = findNodeInstance(i);
        secondNode = findNodeInstance(i);
        _buildWireButtonListener.setFirstNode(firstNode);
        _buildWireButtonListener.setSecondNode(secondNode);
        if (null != firstNode) {
            _firstObjectLabel.setText(firstNode.getBrowserText());
        } else {
            _firstObjectLabel.setText("");
        }
        if (null != secondNode) {
            _secondObjectLabel.setText(secondNode.getBrowserText());
        } else {
            _secondObjectLabel.setText("");
        }
    }

    public void setDiagramsPanel(DiagramsPanel panel) {
        _buildWireButtonListener.setDiagramsPanel(panel);
    }
}
