/*
 * The contents of this file are subject to the Mozilla Public License
 * Version 1.1 (the "License");  you may not use this file except in compliance
 * with the License.  You may obtain a copy of the License at
 * http://www.mozilla.org/MPL/
 *
 * Software distributed under the License is distributed on an "AS IS" basis,
 * WITHOUT WARRANTY OF ANY KIND, either express or implied. See the License for
 * the specific language governing rights and limitations under the License.
 *
 * The Original Code is Protege-2000.
 *
 * The Initial Developer of the Original Code is Stanford University. Portions
 * created by Stanford University are Copyright (C) 2001.  All Rights Reserved.
 *
 * Protege-2000 was developed by Stanford Medical Informatics
 * (http://www.smi.stanford.edu) at the Stanford University School of Medicine
 * with support from the National Library of Medicine, the National Science
 * Foundation, and the Defense Advanced Research Projects Agency.  Current
 * information about Protege can be obtained at http://protege.stanford.edu
 *
 * Contributor(s):
 */

package edu.stanford.smi.protegex.widget.diagram;

import java.awt.*;
import java.beans.*;
import java.util.*;

import javax.swing.*;

import edu.stanford.smi.protege.model.*;
import edu.stanford.smi.protegex.layout.*;

/**
 *  Description of the Class
 *
 * @author    William Grosso <grosso@smi.stanford.edu>
 */
public class DiagramsPanelWithPalette extends DiagramsPanel {
    protected DiagramsAnimationContext _overlay;
    protected TilingAnimationFrame _palette;
    protected OuterPanel _mainPanel;

    private class SplitPaneListener implements PropertyChangeListener {
        public void propertyChange(PropertyChangeEvent evt) {
            if ((evt.getPropertyName()).equals(JSplitPane.LAST_DIVIDER_LOCATION_PROPERTY)) {
                _widget.setDividerLocation(_mainPanel.getWidth() - _mainPanel.getDividerSize() - _mainPanel.getDividerLocation());
            }
        }
    }

    public DiagramsPanelWithPalette(DiagramWidget widget) {
        super(widget);
    }

    private void buildPalette() {
        PalettePanel palettePanel = new PalettePanel(null);
        palettePanel.setPreferredSize(new Dimension(Constants.DEFAULT_NODE_WIDTH, _mainDrawingPanelMinimumSize.height));
        palettePanel.setBackground(Color.white);
        _palette =
            new TilingAnimationFrame(
                true,
                new NoCleanupBackgroundManager(),
                new Rectangle(0, 0, Constants.DEFAULT_NODE_WIDTH, _mainDrawingPanelMinimumSize.height),
                palettePanel);
        palettePanel.setAnimationContext(_palette);
        palettePanel.setMinimumSize(new Dimension(Constants.DEFAULT_NODE_WIDTH, _mainDrawingPanelMinimumSize.height));
        DiagramScrollPane rightScrollPane =
            new DiagramScrollPane(
                palettePanel,
                JScrollPane.VERTICAL_SCROLLBAR_AS_NEEDED,
                JScrollPane.HORIZONTAL_SCROLLBAR_AS_NEEDED);
        palettePanel.setScrollPane(rightScrollPane);
        _mainPanel.setRightHandSide(_palette, palettePanel, rightScrollPane);
    }

    private void createMainPanel() {
        _mainPanel = new OuterPanel();
        _overlay =
            new DiagramsAnimationContext(
                false,
                new NoCleanupBackgroundManager(),
                new Rectangle(
                    0,
                    0,
                    _mainDrawingPanelMinimumSize.width + Constants.DEFAULT_NODE_WIDTH,
                    _mainDrawingPanelMinimumSize.height),
                _mainPanel,
                new DiagramsAnimationContextMouseEventHandler());
        _mainPanel.setOverlay(_overlay);
        _mainPanel.setDividerLocation(_widget.getDividerLocation());
        _mainPanel.addPropertyChangeListener(new SplitPaneListener());
        this.add(_mainPanel, BorderLayout.CENTER);
    }

    private void drawClassConnectors() {
        Collection visibleClses = _widget.getVisibleConnectorClses();
        Iterator i = visibleClses.iterator();
        while (i.hasNext()) {
            Cls underlyingCls = (Cls) i.next();
            WireState wireState = _state.getStateForConnector(underlyingCls);
            WireActorInstance actor = ActorFactory.createWire(wireState, _palette, "", _widget);
            actor.setInstance(underlyingCls, false);
            new ListensToWirePrototypes(
                actor,
                _widget,
                _widget.getKnowledgeBase(),
                underlyingCls,
                _palette,
                _mainDrawingArea,
                _overlay,
                _palette,
                _mainDrawingArea,
                _mainPanel);
        }
    }

    private void drawClasses() {
        drawClassConnectors();
        drawClassNodes();
        _palette.retile();
    }

    private void drawClassNodes() {
        Collection visibleClses = _widget.getVisibleNodeClses();
        Iterator i = visibleClses.iterator();
        while (i.hasNext()) {
            Cls underlyingCls = (Cls) i.next();
            NodeState nodeState = _state.getStateForNode(underlyingCls);
            GlyphActorInstance actor = ActorFactory.createIcon(nodeState, _palette, "", _widget);
            actor.setInstance(underlyingCls);
            new ListensToNodePrototypes(
                actor,
                _widget,
                _widget.getKnowledgeBase(),
                underlyingCls,
                _palette,
                _mainDrawingArea,
                _overlay,
                _palette,
                _mainDrawingArea,
                _mainPanel);
        }
    }

    public void finishInitialization() {
        createMainPanel();
        buildPalette();
        insertMainDrawingArea();
        drawClasses();
    }

    private void insertMainDrawingArea() {
        _mainPanel.setLeftHandSide(_mainDrawingArea, _mainDrawingPanel, _mainDrawingAreaScrollPane);
    }

    public void resizeDiagram() {
        super.resizeDiagram();
        setDividerLocation(getWidth());
    }

    public void setBounds(int x, int y, int width, int height) {
        super.setBounds(x, y, width, height);
        _overlay.setCoordinateSystem(new Rectangle(x, y, width, height));
        setDividerLocation(width);
    }

    public void setBounds(Rectangle rectangle) {
        super.setBounds(rectangle);
        _overlay.setCoordinateSystem(new Rectangle(rectangle));
        setDividerLocation(rectangle.width);
    }

    private void setDividerLocation(int width) {
        _mainPanel.setDividerLocation(width - _mainPanel.getDividerSize() - _widget.getDividerLocation());
    }

    public void setSize(int width, int height) {
        super.setSize(width, height);
        _overlay.setCoordinateSystem(new Rectangle(0, 0, width, height));
        setDividerLocation(width);
    }

    public void setSize(Dimension size) {
        super.setSize(size);
        _overlay.setCoordinateSystem(new Rectangle(0, 0, size.width, size.height));
        setDividerLocation(size.width);
    }
}
