/*
 * The contents of this file are subject to the Mozilla Public License
 * Version 1.1 (the "License");  you may not use this file except in compliance
 * with the License.  You may obtain a copy of the License at
 * http://www.mozilla.org/MPL/
 *
 * Software distributed under the License is distributed on an "AS IS" basis,
 * WITHOUT WARRANTY OF ANY KIND, either express or implied. See the License for
 * the specific language governing rights and limitations under the License.
 *
 * The Original Code is Protege-2000.
 *
 * The Initial Developer of the Original Code is Stanford University. Portions
 * created by Stanford University are Copyright (C) 2001.  All Rights Reserved.
 *
 * Protege-2000 was developed by Stanford Medical Informatics
 * (http://www.smi.stanford.edu) at the Stanford University School of Medicine
 * with support from the National Library of Medicine, the National Science
 * Foundation, and the Defense Advanced Research Projects Agency.  Current
 * information about Protege can be obtained at http://protege.stanford.edu
 *
 * Contributor(s):
 */

package edu.stanford.smi.protegex.widget.diagram;

import edu.stanford.smi.protegex.layout.*;

import javax.swing.*;
import java.awt.*;
import java.awt.event.*;

/**
 *  Description of the Class
 *
 * @author    William Grosso <grosso@smi.stanford.edu>
 */
public abstract class InnerPanel extends JPanel {
    protected AnimationContext _animationContext;
    protected DiagramScrollPane _scrollPane;
    protected int _leftOffset;
    protected Rectangle _scratchRectangle;
    protected Rectangle _activeRectangle;
    protected Rectangle _oldActiveRectangle;

    public InnerPanel(AnimationContext animationContext) {
        super(false);
        _scratchRectangle = new Rectangle();
        _activeRectangle = new Rectangle();
        _oldActiveRectangle = new Rectangle();
        _animationContext = animationContext;
    }

    public void displayPoint(int x, int y) {
        JViewport viewport = _scrollPane.getViewport();
        _animationContext.getCoordinateSystem(_scratchRectangle);
        if (x > _scratchRectangle.x) {
            int maximumX = _scratchRectangle.x + _scratchRectangle.width;
            if (x < maximumX) {
                _scratchRectangle.x = x;
            } else {
                _scratchRectangle.x = maximumX;
            }
        }
        if (y > _scratchRectangle.y) {
            int maximumY = _scratchRectangle.y + _scratchRectangle.height;
            if (y < maximumY) {
                _scratchRectangle.y = y;
            } else {
                _scratchRectangle.y = maximumY;
            }
        }
        _scratchRectangle.width = _scratchRectangle.height = 1;
        _scratchRectangle.x += getX();
        _scratchRectangle.y += getY();
        viewport.scrollRectToVisible(_scratchRectangle);
    }

    public void displayPoint(Point point) {
        displayPoint(point.x, point.y);
    }

    /*
         * Next goal is to compute some sort of clipping region here.
         */

    public void forwardMouseEvent(MouseEvent e) {
        int deltaX = getHorizontalScrollbarValue() - _leftOffset;
        int deltaY = getVerticalScrollbarValue();
        e.translatePoint(deltaX, deltaY);
        _animationContext.processMouseEvent(e);
        repaint();
    }

    public void forwardMouseMotionEvent(MouseEvent e) {
        int deltaX = getHorizontalScrollbarValue() - _leftOffset;
        int deltaY = getVerticalScrollbarValue();
        e.translatePoint(deltaX, deltaY);
        _animationContext.processMouseMotionEvent(e);
        repaint();
    }

    private int getHorizontalScrollbarValue() {
        return (_scrollPane.getHorizontalScrollBar().getValue());
    }

    public Dimension getPreferredSize() {
        Rectangle actualSize = _animationContext.getCoordinateSystem();
        return new Dimension(actualSize.width, actualSize.height);
    }

    private int getVerticalScrollbarValue() {
        return (_scrollPane.getVerticalScrollBar().getValue());
    }

    public Rectangle getVisibleArea() {
        JViewport viewport = _scrollPane.getViewport();
        return viewport.getViewRect();
    }

    public void paint(Graphics g) {
        super.paint(g);
        if (null != _animationContext) {
            _animationContext.paint(g);
        }
    }

    public void setAnimationContext(AnimationContext animationContext) {
        _animationContext = animationContext;
    }

    public void setLeftOffset(int leftOffset) {
        _leftOffset = leftOffset;
    }

    public void setScrollPane(DiagramScrollPane scrollPane) {
        _scrollPane = scrollPane;
    }

    private Point translatePointFromOuterCoordinates(Point p) {
        Point returnValue = new Point(p);
        returnValue.x -= _leftOffset;
        return returnValue;
    }

    public boolean wantsEventAtLocation(Point p) {
        if (contains(translatePointFromOuterCoordinates(p))) {
            return _animationContext.getVisibleToEvents();
        }
        return false;
    }
}
