/*
 * The contents of this file are subject to the Mozilla Public License
 * Version 1.1 (the "License");  you may not use this file except in compliance
 * with the License.  You may obtain a copy of the License at
 * http://www.mozilla.org/MPL/
 *
 * Software distributed under the License is distributed on an "AS IS" basis,
 * WITHOUT WARRANTY OF ANY KIND, either express or implied. See the License for
 * the specific language governing rights and limitations under the License.
 *
 * The Original Code is Protege-2000.
 *
 * The Initial Developer of the Original Code is Stanford University. Portions
 * created by Stanford University are Copyright (C) 2001.  All Rights Reserved.
 *
 * Protege-2000 was developed by Stanford Medical Informatics
 * (http://www.smi.stanford.edu) at the Stanford University School of Medicine
 * with support from the National Library of Medicine, the National Science
 * Foundation, and the Defense Advanced Research Projects Agency.  Current
 * information about Protege can be obtained at http://protege.stanford.edu
 *
 * Contributor(s):
 */

package edu.stanford.smi.protegex.layout;

/**
 *  Description of the class
 *
 * @author    William Grosso <grosso@smi.stanford.edu>
 */
public final class StandardActorMovementHandler extends ActorDelegateImpl
         implements ActorMovementHandler {
    private int _lastTime;
    private boolean _bounces;
    private boolean _moving;
    protected double _xVelocity;
    protected double _yVelocity;

    public StandardActorMovementHandler(Actor actor) {
        super(actor);
        _xVelocity = ZERO_VELOCITY;
        _yVelocity = ZERO_VELOCITY;
        _moving = false;
    }

    protected void calculateNewPosition(int elapsedTime) {
        int deltaX = (int) _xVelocity * elapsedTime;
        int deltaY = (int) _yVelocity * elapsedTime;
        _actor.translate(deltaX, deltaY);
        if (_bounces) {
            if (!_location.isInsideCoordinateSystem()) {
                int x = _location.getBaseX();
                int y = _location.getBaseY();
                _location.reflectIntoCoordinateSystem();
                if (x != _location.getBaseX()) {
                    _xVelocity *= -1;
                }
                if (y != _location.getBaseY()) {
                    _yVelocity *= -1;
                }
            }
        } else {
            _location.wrapIntoCoordinateSystem();
        }
    }

    private void checkForMovement() {
        _moving = ((_xVelocity == ZERO_VELOCITY) && (_yVelocity == ZERO_VELOCITY)) ? false : true;
    }

    public boolean collidesWithActor(Actor actor) {
        return false;
    }

    public void collideWithActor(Actor actor) {

    }

    // The Copyable Interface
    public Object copy() {
        StandardActorMovementHandler returnValue = new StandardActorMovementHandler(_actor);
        returnValue.setBounces(getBounces());
        returnValue.setXVelocity(_xVelocity);
        returnValue.setYVelocity(_yVelocity);
        return returnValue;
    }

    public boolean getBounces() {
        return _bounces;
    }

    public double getXVelocity() {
        return _xVelocity;
    }

    public double getYVelocity() {
        return _yVelocity;
    }

    public void setBounces(boolean bounces) {
        _bounces = bounces;
    }

    public void setXVelocity(double xVelocity) {
        _xVelocity = xVelocity;
        checkForMovement();
    }

    public void setYVelocity(double yVelocity) {
        _yVelocity = yVelocity;
    }

    // The Movement Handler interface
    public void tick(int currentTime) {
        if ((_actor.getIsDragging()) || _actor.getIsResizing()) {
            _lastTime = currentTime;
            return;
        }
        if (_moving) {
            calculateNewPosition(currentTime - _lastTime);
        }
        _lastTime = currentTime;
    }
}
