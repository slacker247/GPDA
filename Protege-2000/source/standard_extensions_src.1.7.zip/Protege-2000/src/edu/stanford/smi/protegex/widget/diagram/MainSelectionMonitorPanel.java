/*
 * The contents of this file are subject to the Mozilla Public License
 * Version 1.1 (the "License");  you may not use this file except in compliance
 * with the License.  You may obtain a copy of the License at
 * http://www.mozilla.org/MPL/
 *
 * Software distributed under the License is distributed on an "AS IS" basis,
 * WITHOUT WARRANTY OF ANY KIND, either express or implied. See the License for
 * the specific language governing rights and limitations under the License.
 *
 * The Original Code is Protege-2000.
 *
 * The Initial Developer of the Original Code is Stanford University. Portions
 * created by Stanford University are Copyright (C) 2001.  All Rights Reserved.
 *
 * Protege-2000 was developed by Stanford Medical Informatics
 * (http://www.smi.stanford.edu) at the Stanford University School of Medicine
 * with support from the National Library of Medicine, the National Science
 * Foundation, and the Defense Advanced Research Projects Agency.  Current
 * information about Protege can be obtained at http://protege.stanford.edu
 *
 * Contributor(s):
 */

package edu.stanford.smi.protegex.widget.diagram;

import edu.stanford.smi.protege.model.*;
import edu.stanford.smi.protege.widget.*;
import edu.stanford.smi.protegex.layout.*;

import javax.swing.*;
import java.awt.*;
import java.awt.event.*;

/**
 *  Description of the class
 *
 * @author    William Grosso <grosso@smi.stanford.edu>
 */
public class MainSelectionMonitorPanel extends JPanel {
    private JPanel _nullPanel;
    private AnimationContext _widgetAnimationContext;
    private MainDrawingPanel _widgetDrawingPanel;
    private Project _project;
    private Instance _selectedInstance;
    private ClsWidget _currentForm;
    private JScrollPane _surroundingPane;
    private JViewport _viewport;

    private class OurAnimationContextSelectionListener implements AnimationContextSelectionListener {
        public void animationContextSelectionChanged(AnimationContextSelectionEvent event) {
            updateForm();
        }
    }

    public MainSelectionMonitorPanel(DiagramWidget widget) {
        super(new BorderLayout());
        _widgetAnimationContext = widget.getMainDrawingArea();
        _widgetAnimationContext.addAnimationContextSelectionListener(new OurAnimationContextSelectionListener());
        _widgetDrawingPanel = widget.getMainDrawingPanel();
        _project = widget.getProject();
        buildNullPanel();
    }

    private void buildNullPanel() {
        _nullPanel = new JPanel();
    }

    private void displayFormForInstance(Instance newlySelectedInstance) {
        if (_currentForm != null) {
            ((JComponent) _currentForm).grabFocus();
            _currentForm.dispose();
        }
        removeAll();
        _currentForm = _project.createRuntimeClsWidget(newlySelectedInstance);
        if (null == _surroundingPane) {
            _surroundingPane = new JScrollPane((JComponent) _currentForm);
            _viewport = _surroundingPane.getViewport();
        } else {
            _viewport.setView((JComponent) _currentForm);
        }
        add(_surroundingPane);
    }

    private boolean equal(Instance firstInstance, Instance secondInstance) {
        if (null != firstInstance) {
            if (null != secondInstance) {
                return firstInstance.equals(secondInstance);
            }
            return false;
        }
        return (null == secondInstance);
    }

    private Instance getSelectedInstance() {
        Actor selectedActor = _widgetAnimationContext.getLeadSelection();
        if (selectedActor instanceof ActorInstance) {
            ActorInstance selectedActorInstance = (ActorInstance) selectedActor;
            return selectedActorInstance.getInstance();
        }
        return null;
    }

    public void paint(Graphics g) {
        updateForm();
        super.paint(g);
    }

    private void updateForm() {
        Instance newlySelectedInstance = getSelectedInstance();
        if (equal(newlySelectedInstance, _selectedInstance)) {
            return;
        }
        if (null == newlySelectedInstance) {
            removeAll();
            add(_nullPanel);
        } else {
            if ((null == _selectedInstance) || (_selectedInstance.getDirectType() != newlySelectedInstance.getDirectType())) {
                displayFormForInstance(newlySelectedInstance);
            } else {
                ((JComponent) _currentForm).grabFocus();
                _currentForm.setInstance(newlySelectedInstance);
            }
        }
        _selectedInstance = newlySelectedInstance;
        validate();
        repaint();
    }
}
