/*
 * The contents of this file are subject to the Mozilla Public License
 * Version 1.1 (the "License");  you may not use this file except in compliance
 * with the License.  You may obtain a copy of the License at
 * http://www.mozilla.org/MPL/
 *
 * Software distributed under the License is distributed on an "AS IS" basis,
 * WITHOUT WARRANTY OF ANY KIND, either express or implied. See the License for
 * the specific language governing rights and limitations under the License.
 *
 * The Original Code is Protege-2000.
 *
 * The Initial Developer of the Original Code is Stanford University. Portions
 * created by Stanford University are Copyright (C) 2001.  All Rights Reserved.
 *
 * Protege-2000 was developed by Stanford Medical Informatics
 * (http://www.smi.stanford.edu) at the Stanford University School of Medicine
 * with support from the National Library of Medicine, the National Science
 * Foundation, and the Defense Advanced Research Projects Agency.  Current
 * information about Protege can be obtained at http://protege.stanford.edu
 *
 * Contributor(s):
 */

package edu.stanford.smi.protegex.widget.instancetable;

import edu.stanford.smi.protege.widget.*;
import edu.stanford.smi.protege.model.*;
import edu.stanford.smi.protege.ui.*;
import edu.stanford.smi.protege.util.*;
import edu.stanford.smi.protege.resource.*;
import java.awt.*;
import java.awt.event.*;
import javax.swing.*;
import javax.swing.event.*;
import java.util.*;

/**
 *  Visible slot descriptions
 *
 * @author    William Grosso <grosso@smi.stanford.edu>
 */
public class ColumnConfigurationPanel extends JPanel implements Validatable {
    private ConfigTable _underlyingTable;
    private InstanceTableWidgetState _state;
    private AddSlot _slotAdder;
    private RemoveSlot _slotRemover;

    private class AddSlot extends AbstractAction {
        public AddSlot() {
            super("Add one or more slots to the list of columns", Icons.getAddIcon());
        }

        public void actionPerformed(ActionEvent e) {
            Collection possibleSlots = _state.getRemainingSlots();
            if (!possibleSlots.isEmpty()) {
                Collection selection = DisplayUtilities.pickSlots(ColumnConfigurationPanel.this, possibleSlots);
                if (null != selection) {
                    Iterator i = selection.iterator();
                    while (i.hasNext()) {
                        _state.makeSlotVisible((Slot) i.next());
                    }
                }
            }
            setButtonState();
        }
    }

    private class RemoveSlot extends AbstractAction {
        public RemoveSlot() {
            super("Remove the currently selected column", Icons.getRemoveIcon());
        }

        public void actionPerformed(ActionEvent e) {
            int[] columnsToRemove = _underlyingTable.getSelectedColumns();
            if (_underlyingTable.isEditing()) {
                (_underlyingTable.getDefaultEditor(Object.class)).stopCellEditing();
            }
            _underlyingTable.clearSelection();
            int loopCounter;
            for (loopCounter = columnsToRemove.length - 1; loopCounter > -1; loopCounter--) {
                _state.removeVisibleSlotDescriptionAtIndex(columnsToRemove[loopCounter] - 1);
            }
            setButtonState();
            return;
        }
    }

    public ColumnConfigurationPanel(InstanceTableWidgetState state) {
        super(new BorderLayout());
        _state = state;
        _underlyingTable = new ConfigTable(_state);
        LabeledComponent center = new LabeledComponent("Selected Slots", new JScrollPane(_underlyingTable));
        _slotAdder = new AddSlot();
        _slotRemover = new RemoveSlot();
        setButtonState();
        center.addHeaderButton(_slotAdder);
        center.addHeaderButton(_slotRemover);
        add(center, BorderLayout.CENTER);
    }

    public void saveContents() {
        _state.save();
    }

    private void setButtonState() {
        Collection possibleSlots = _state.getRemainingSlots();
        int numberOfColumns = _state.getTotalNumberOfVisibleSlots();
        if (possibleSlots.isEmpty()) {
            _slotAdder.setEnabled(false);
        } else {
            _slotAdder.setEnabled(true);
        }
        if (0 == numberOfColumns) {
            _slotRemover.setEnabled(false);
        } else {
            _slotRemover.setEnabled(true);
        }
    }

    public boolean validateContents() {
        return true;
    }
}
