/*
 * The contents of this file are subject to the Mozilla Public License
 * Version 1.1 (the "License");  you may not use this file except in compliance
 * with the License.  You may obtain a copy of the License at
 * http://www.mozilla.org/MPL/
 *
 * Software distributed under the License is distributed on an "AS IS" basis,
 * WITHOUT WARRANTY OF ANY KIND, either express or implied. See the License for
 * the specific language governing rights and limitations under the License.
 *
 * The Original Code is Protege-2000.
 *
 * The Initial Developer of the Original Code is Stanford University. Portions
 * created by Stanford University are Copyright (C) 2001.  All Rights Reserved.
 *
 * Protege-2000 was developed by Stanford Medical Informatics
 * (http://www.smi.stanford.edu) at the Stanford University School of Medicine
 * with support from the National Library of Medicine, the National Science
 * Foundation, and the Defense Advanced Research Projects Agency.  Current
 * information about Protege can be obtained at http://protege.stanford.edu
 *
 * Contributor(s):
 */

package edu.stanford.smi.protegex.layout;

import java.util.*;
import java.awt.*;

/**
 *  Description of the Class Not used in diagrams because it is too expensive.
 *  Use clean sweep instead.
 *
 * @author    William Grosso <grosso@smi.stanford.edu>
 */
public class DirtyRectBackgroundManager implements BackgroundManager {
    private AnimationContext _animationContext;
    private Image _tile;
    private Image _background;
    private ArrayList _rects;
    private RectXComparator _rectXComparator;

    private Rectangle _bounds;

    int count = 0;
    private final static int GLUE = 64;

    private class RectXComparator implements Comparator {
        public int compare(Object o1, Object o2) {
            Rectangle r1 = (Rectangle) o1;
            Rectangle r2 = (Rectangle) o2;

            if (r1.x < r2.x) {
                return -1;
            } else {
                if (r1.x == r2.x) {
                    return 0;
                }
            }
            return 1;
        }
    }

    public DirtyRectBackgroundManager(AnimationContext animationContext, Image tile) {
        _animationContext = animationContext;
        _rects = new ArrayList();
        _rectXComparator = new RectXComparator();
        _tile = tile;
        _background = null;
    }

    // the BackgroundManager API
    public void addDirtyRect(Rectangle dirtyRect) {
        if (null != dirtyRect) {
            _rects.add(dirtyRect);
        }
    }

    public void backgroundHasChangedSize() {
        _background = null;
    }

    private final boolean closeEnough(Rectangle r1, Rectangle r2) {
        boolean result;

        r1.width += GLUE;
        r1.height += GLUE;
        r2.width += GLUE;
        r2.height += GLUE;

        result = r1.intersects(r2);

        r1.width -= GLUE;
        r1.height -= GLUE;
        r2.width -= GLUE;
        r2.height -= GLUE;

        return result;
    }

    private void collapse() {
        int index = 0;
        if (_rects.size() < 2) {
            return;
        }
        Collections.sort(_rects, _rectXComparator);
        Rectangle r1 = (Rectangle) _rects.get(index);
        Rectangle r2 = (Rectangle) _rects.get(index + 1);
        while (true) {
            if (closeEnough(r1, r2)) {
                r1 = r1.union(r2);
                _rects.set(index, r1);
                _rects.remove(index + 1);
                if (index + 1 < _rects.size()) {
                    r2 = (Rectangle) _rects.get(index + 1);
                } else {
                    return;
                }
            } else {
                if (index + 2 < _rects.size()) {
                    r1 = r2;
                    r2 = (Rectangle) _rects.get(index + 2);
                    index += 1;
                } else {
                    return;
                }
            }
        }
    }

    public void drawEntireBackground(Graphics g) {
        g.drawImage(_background, _bounds.x, _bounds.y, null);
    }

    public void refreshBackground(Graphics g) {
        collapse();
        if ((null == _background)) {
            retile();
            g.drawImage(_background, _bounds.x, _bounds.y, null);
        }

        Iterator i = _rects.iterator();
        while (i.hasNext()) {
            Rectangle r = (Rectangle) i.next();
            g.drawImage(
                _background,
                r.x,
                r.y,
                r.x + r.width,
                r.y + r.height,
                r.x - _bounds.x,
                r.y - _bounds.y,
                r.x + r.width - _bounds.x,
                r.y + r.height - _bounds.y,
                null);
        }
    }

    private void retile() {
        _bounds = _animationContext.getCoordinateSystem();
        _background = TiledImage.createTiledImage(_tile, _bounds, _animationContext.getOwner());
    }

    // And some extra special dirty rect stuff
    public void setBackgroundTile(Image tile) {
        /*
         * MediaTracker tracker= new java.awt.MediaTracker(_animationFrame);
         * tracker.addImage(tile, 0);
         * try
         * {
         * tracker.waitForID(0);
         * }
         * catch (InterruptedException e)
         * {
         * }
         */
        _tile = tile;
        _background = null;
    }
}
