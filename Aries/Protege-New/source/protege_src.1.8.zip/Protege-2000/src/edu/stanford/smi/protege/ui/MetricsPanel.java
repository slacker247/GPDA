/*
 * The contents of this file are subject to the Mozilla Public License
 * Version 1.1 (the "License");  you may not use this file except in compliance
 * with the License.  You may obtain a copy of the License at
 * http://www.mozilla.org/MPL/
 *
 * Software distributed under the License is distributed on an "AS IS" basis,
 * WITHOUT WARRANTY OF ANY KIND, either express or implied. See the License for
 * the specific language governing rights and limitations under the License.
 *
 * The Original Code is Protege-2000.
 *
 * The Initial Developer of the Original Code is Stanford University. Portions
 * created by Stanford University are Copyright (C) 2001.  All Rights Reserved.
 *
 * Protege-2000 was developed by Stanford Medical Informatics
 * (http://www.smi.stanford.edu) at the Stanford University School of Medicine
 * with support from the National Library of Medicine, the National Science
 * Foundation, and the Defense Advanced Research Projects Agency.  Current
 * information about Protege can be obtained at http://protege.stanford.edu
 *
 * Contributor(s):
 */

package edu.stanford.smi.protege.ui;

import java.awt.*;

import javax.swing.*;
import javax.swing.table.*;

import edu.stanford.smi.protege.model.*;
import edu.stanford.smi.protege.util.*;

/**
 * Panel to display a set of metrics that describe a project.
 *
 * @author    Ray Fergerson <fergerson@smi.stanford.edu>
 */
public class MetricsPanel extends JComponent {
    private KnowledgeBase _kb;
    private Statistics _statistics;
    private DefaultTableModel _clsesModel;
    private DefaultTableModel _slotsModel;
    private DefaultTableModel _facetsModel;
    private DefaultTableModel _instancesModel;
    private DefaultTableModel _summaryModel;

    public MetricsPanel(Project p) {
        _kb = p.getKnowledgeBase();
        setLayout(new BorderLayout(20, 20));
        add(createWaitPanel());
        calculateValues();
    }

    private JComponent createWaitPanel() {
        return new JLabel("Calculating Statistics, please wait...");
    }

    private void updatePanel() {
        remove(0);
        add(createSummaryPanel(), BorderLayout.NORTH);
        add(createDetailsPanel(), BorderLayout.CENTER);
        updateClsesModel();
        updateSlotsModel();
        updateFacetsModel();
        updateSummaryModel();
        updateInstancesModel();
        JDialog dialog = (JDialog) SwingUtilities.getRoot(this);
        dialog.pack();
        ComponentUtilities.center(dialog);
    }

    private void calculateValues() {
        Thread t = new Thread("Metrics") {
            public void run() {
                try {
                    Thread.sleep(2000);
                    calculateStatistics();
                    updatePanel();
                } catch (InterruptedException e) {
                }
            }
        };
        t.start();
    }

    private void calculateStatistics() {
        WaitCursor cursor = new WaitCursor(this);
        try {
            _statistics = new Statistics(_kb);
        } finally {
            cursor.hide();
        }
    }

    private Object[] createChildSummary() {
        return new Object[] {
            "Children",
            newDouble(_statistics.meanChildren),
            newDouble(_statistics.sdChildren),
            new Integer(_statistics.maxChildren),
            };
    }

    private JComponent createClsesPanel() {
        _clsesModel = new DefaultTableModel();
        _clsesModel.addColumn("");
        _clsesModel.addColumn("Mean");
        _clsesModel.addColumn("Std. Dev.");
        _clsesModel.addColumn("Max");
        return createTable(_clsesModel, "Classes");
    }

    private void updateClsesModel() {
        _clsesModel.addRow(createParentSummary());
        _clsesModel.addRow(createChildSummary());
        _clsesModel.addRow(createRelationsSummary());
        _clsesModel.addRow(createDirectSlotsSummary());
        _clsesModel.addRow(createSlotsSummary());
        _clsesModel.addRow(createInstancesSummary());
    }

    private Object[] createClsSummary() {
        return new Object[] {
            "Classes",
            new Integer(_statistics.nSystemClses),
            new Integer(_statistics.nIncludedClses),
            new Integer(_statistics.nDirectClses),
            new Integer(_statistics.nClses)};
    }

    private JComponent createDetailsPanel() {
        JComponent c = new JPanel();
        c.setLayout(new GridLayout(2, 2, 20, 20));
        c.add(createClsesPanel());
        c.add(createInstancesPanel());
        c.add(createSlotsPanel());
        c.add(createFacetsPanel());
        return c;
    }

    private Object[] createDirectSlotsSummary() {
        return new Object[] {
            "Direct Slots",
            newDouble(_statistics.meanDirectSlots),
            newDouble(_statistics.sdDirectSlots),
            new Integer(_statistics.maxDirectSlots),
            };
    }

    private Object[] createFacetDirectBindingsSummary() {
        return new Object[] {
            "Direct Bindings",
            newDouble(_statistics.meanDirectBindings),
            newDouble(_statistics.sdDirectBindings),
            new Integer(_statistics.maxDirectBindings),
            };
    }

    private JComponent createFacetsPanel() {
        _facetsModel = new DefaultTableModel();
        _facetsModel.addColumn("");
        _facetsModel.addColumn("Mean");
        _facetsModel.addColumn("Std. Dev.");
        _facetsModel.addColumn("Max");
        return createTable(_facetsModel, "Facets");
    }

    private void updateFacetsModel() {
        _facetsModel.addRow(createFacetDirectBindingsSummary());
    }

    private Object[] createFacetSummary() {
        return new Object[] {
            "Facets",
            new Integer(_statistics.nSystemFacets),
            new Integer(_statistics.nIncludedFacets),
            new Integer(_statistics.nDirectFacets),
            new Integer(_statistics.nFacets)};
    }

    private Object[] createFrameSummary() {
        return new Object[] {
            "Frames",
            new Integer(_statistics.nSystemFrames),
            new Integer(_statistics.nIncludedFrames),
            new Integer(_statistics.nDirectFrames),
            new Integer(_statistics.nFrames)};
    }

    private Object[] createInstanceReferencersSummary() {
        return new Object[] {
            "Referencers",
            newDouble(_statistics.meanInstanceReferencers),
            newDouble(_statistics.sdInstanceReferencers),
            new Integer(_statistics.maxInstanceReferencers)};
    }

    private Object[] createInstanceReferencesSummary() {
        return new Object[] {
            "References",
            newDouble(_statistics.meanInstanceReferences),
            newDouble(_statistics.sdInstanceReferences),
            new Integer(_statistics.maxInstanceReferences)};
    }

    private JComponent createInstancesPanel() {
        _instancesModel = new DefaultTableModel();
        _instancesModel.addColumn("");
        _instancesModel.addColumn("Mean");
        _instancesModel.addColumn("Std. Dev.");
        _instancesModel.addColumn("Max");
        return createTable(_instancesModel, "Instances");
    }

    private void updateInstancesModel() {
        _instancesModel.addRow(createInstanceReferencesSummary());
        _instancesModel.addRow(createInstanceReferencersSummary());
    }

    private Object[] createInstancesSummary() {
        return new Object[] {
            "Direct Instances",
            newDouble(_statistics.meanDirectInstances),
            newDouble(_statistics.sdDirectInstances),
            new Integer(_statistics.maxDirectInstances),
            };
    }

    private Object[] createInstanceSummary() {
        return new Object[] {
            "Instances",
            new Integer(_statistics.nSystemInstances),
            new Integer(_statistics.nIncludedInstances),
            new Integer(_statistics.nDirectInstances),
            new Integer(_statistics.nInstances)};
    }

    private Object[] createParentSummary() {
        return new Object[] {
            "Parents",
            newDouble(_statistics.meanParents),
            newDouble(_statistics.sdParents),
            new Integer(_statistics.maxParents),
            };
    }

    private Object[] createRelationsSummary() {
        return new Object[] {
            "Relations",
            newDouble(_statistics.meanClsRelations),
            newDouble(_statistics.sdClsRelations),
            new Integer(_statistics.maxClsRelations),
            };
    }

    private Object[] createSlotDirectClsesSummary() {
        return new Object[] {
            "Direct Classes",
            newDouble(_statistics.meanClsesDirectlyAttached),
            newDouble(_statistics.sdClsesDirectlyAttached),
            new Integer(_statistics.maxClsesDirectlyAttached),
            };
    }

    private JComponent createSlotsPanel() {
        _slotsModel = new DefaultTableModel();
        _slotsModel.addColumn("");
        _slotsModel.addColumn("Mean");
        _slotsModel.addColumn("Std. Dev.");
        _slotsModel.addColumn("Max");
        return createTable(_slotsModel, "Slots");
    }

    private void updateSlotsModel() {
        _slotsModel.addRow(createSlotDirectClsesSummary());
    }

    private Object[] createSlotsSummary() {
        return new Object[] {
            "Slots",
            newDouble(_statistics.meanSlots),
            newDouble(_statistics.sdSlots),
            new Integer(_statistics.maxSlots),
            };
    }

    private Object[] createSlotSummary() {
        return new Object[] {
            "Slots",
            new Integer(_statistics.nSystemSlots),
            new Integer(_statistics.nIncludedSlots),
            new Integer(_statistics.nDirectSlots),
            new Integer(_statistics.nSlots)};
    }

    private JComponent createSummaryPanel() {
        _summaryModel = new DefaultTableModel();
        _summaryModel.addColumn("");
        _summaryModel.addColumn("System");
        _summaryModel.addColumn("Included");
        _summaryModel.addColumn("Direct");
        _summaryModel.addColumn("Total");
        return createTable(_summaryModel, "Summary");
    }

    private void updateSummaryModel() {
        _summaryModel.addRow(createClsSummary());
        _summaryModel.addRow(createSlotSummary());
        _summaryModel.addRow(createFacetSummary());
        _summaryModel.addRow(createInstanceSummary());
        _summaryModel.addRow(createFrameSummary());
    }

    private JComponent createTable(DefaultTableModel model, String header) {
        JTable table = ComponentFactory.createTable(null);
        table.setModel(model);
        table.createDefaultColumnsFromModel();
        ((JLabel) table.getDefaultRenderer(Object.class)).setHorizontalAlignment(JLabel.RIGHT);
        TableColumn column = table.getColumnModel().getColumn(0);
        column.setPreferredWidth(95);

        DefaultTableCellRenderer renderer = new DefaultTableCellRenderer();
        renderer.setHorizontalAlignment(JLabel.LEFT);
        column.setCellRenderer(renderer);

        DefaultTableCellRenderer r = new DefaultTableCellRenderer();
        table.setDefaultRenderer(Double.class, r);

        table.setEnabled(false);

        JComponent c = new JPanel();
        c.setLayout(new BorderLayout());
        c.add(new JTableHeader(table.getColumnModel()), BorderLayout.NORTH);
        c.add(table, BorderLayout.CENTER);
        return new LabeledComponent(header, c);
    }

    private String newDouble(double d) {
        return String.valueOf(Math.round(d * 100) / 100.);
    }
}
