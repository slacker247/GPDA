package protegex.prologtab.gnuprolog;

import protegex.prologtab.*;
import java.io.*;
import edu.stanford.smi.protege.model.*;
/**
 * Insert the type's description here.
 * Creation date: (5/3/2002 10:10:12 AM)
 * @author: 
 */
public class GNUPrologShell extends protegex.prologtab.PrologShell {
/**
 * Insert the method's description here.
 * Creation date: (5/3/2002 10:13:30 AM)
 * @param console protegex.prologtab.PrologConsole
 * @param tab protegex.prologtab.PrologTab
 */
public GNUPrologShell(PrologConsole console, PrologTab tab) {
	super(console,tab);
}
/**
 * Create a GNUProlog Engine.
 * Creation date: (5/3/2002 10:10:12 AM)
 * @return protegex.prologtab.PrologEngine
 */
public protegex.prologtab.PrologEngine createPrologEngine() {
	return new GNUPrologEngine(_reader,_writer,_tab);
}
}
