package protegex.prologtab.gnuprolog;

import edu.stanford.smi.protege.model.*;
import edu.stanford.smi.protege.util.*;
import java.io.*;
import java.util.*;
import gnu.prolog.database.*;
import gnu.prolog.term.*;
import gnu.prolog.vm.*;
import gnu.prolog.io.*;
import protegex.prologtab.*;
/**
 * PrologEngine for GNU Prolog.
 * Creation date: (3/26/2002 9:55:25 AM)
 * @author: 
 */
public class GNUPrologEngine implements PrologEngine {
	protected PrologTab _tab;
	protected Environment _environment;
	protected Reader _reader;
	protected PrintWriter _writer;
    protected Interpreter _interpreter;
	protected Map _frame2term = new HashMap();
	
	public static final AtomTerm trueAtom = AtomTerm.get("true");
	public static final AtomTerm falseAtom = AtomTerm.get("false");
	public static final AtomTerm nullAtom = AtomTerm.get("null"); 
	public static final CompoundTermTag listTag = CompoundTermTag.get(".",2);
	public static final CompoundTermTag frameTag = CompoundTermTag.get("frame",1);
/**
 * PrologEngine constructor comment.
 */
public GNUPrologEngine(Reader reader, PrintWriter writer, PrologTab tab) {
	super();
	_reader = reader;
	_writer = writer;
	_tab = tab;
	_environment = new Environment(_reader,_writer,new OperatorSet(),true,this);
	_environment.getModule().addPredicateListener(_environment);
	_interpreter = _environment.createInterpreter();
	_environment.runIntialization(_interpreter);
	for (Iterator ierr = _environment.getLoadingErrors().iterator();ierr.hasNext();) {
		PrologTextLoaderError err = (PrologTextLoaderError)ierr.next();
		System.err.println(err);
        //err.printStackTrace();
	}
}
/**
 * 
 * @return java.lang.Object
 * @param frame edu.stanford.smi.protege.model.Frame
 * @param slot edu.stanford.smi.protege.model.Slot
 * @param value java.lang.Object
 */
public void assertSlotValueClause(Frame frame, String slotName, Object value) {
	CompoundTermTag slotTag = CompoundTermTag.get(slotName,2);
	Term frameTerm = getTerm(frame);
	Term valueTerm = getTerm(value);
	CompoundTerm clauseTerm = new CompoundTerm(slotTag,frameTerm,valueTerm);
    Predicate p = getModule().getDefinedPredicate(slotTag);
	if (p == null) {
		p = getModule().createDefinedPredicate(slotTag);
		p.setType(Predicate.USER_DEFINED);
		p.setDynamic();
    }
	p.addClauseLast(Predicate.prepareClause(clauseTerm));
	//System.out.println(TermWriter.toString(clauseTerm));
}
/**
 * 
 * @return gnu.prolog.term.Term
 * @param clauses java.util.List
 * @param frameTerm gnu.prolog.term.Term
 */
protected Term findSlotValueClause(List clauses, Term frameTerm) {
	Iterator iterator = clauses.iterator();
	while (iterator.hasNext()) {
		CompoundTerm clause = (CompoundTerm) iterator.next();
		//We'll make deep assumptions about structure of slot value clause
		Term head = clause.args[0];
		Term body = clause.args[1];
		if ((body == trueAtom) &&
			(head instanceof CompoundTerm) &&
			(((CompoundTerm) head).args[0] == frameTerm))
				return clause;
	}
	return null;
}
/**
 * Insert the method's description here.
 * Creation date: (4/29/2002 11:22:17 AM)
 * @return java.lang.Object[]
 * @param listTerm gnu.prolog.term.CompoundTerm
 */
public Object[] getArray(Term listTerm) {
	if (listTerm == AtomTerm.emptyList)
		return new Object[0];
	if (!isList(listTerm))
		listTerm = CompoundTerm.getList(listTerm, AtomTerm.emptyList);
	List javaList = getList(listTerm);
	return javaList.toArray();
}
/**
 * Insert the method's description here.
 * Creation date: (4/24/2002 12:21:03 PM)
 * @return java.lang.String
 */
public java.lang.String getBuiltIns() {
	try {
		Reader reader = new InputStreamReader(PrologTextLoaderState.class.getResourceAsStream("/gnu/prolog/vm/buildins/buildins.pro"));
		StringWriter writer = new StringWriter();
		while (reader.ready())
			writer.write(reader.read());
		reader.close();
		return writer.toString();
	} catch (IOException e) {
		System.out.println(e);
		return null;
	}
}
/**
 * Insert the method's description here.
 * Creation date: (4/29/2002 10:38:49 AM)
 * @return edu.stanford.smi.protege.model.Frame
 * @param frameTerm gnu.prolog.term.CompoundTerm
 */
public Frame getFrame(CompoundTerm frameTerm) {
	AtomTerm nameTerm = (AtomTerm) frameTerm.args[0];	
	return getKnowledgeBase().getFrame(nameTerm.value);
}
/**
 * Insert the method's description here.
 * Creation date: (4/29/2002 10:39:41 AM)
 * @return gnu.prolog.term.CompoundTerm
 * @param frame edu.stanford.smi.protege.model.Frame
 */
public CompoundTerm getFrameTerm(Frame frame) {
	CompoundTerm frameTerm = (CompoundTerm) _frame2term.get(frame);
	Term nameTerm = AtomTerm.get(frame.getName());
	if (frameTerm == null) {
		frameTerm = new CompoundTerm(frameTag,nameTerm);
		_frame2term.put(frame,frameTerm);
	}
	((CompoundTerm) frameTerm).args[0] = nameTerm;	
	return frameTerm;
}
/**
 * Convert a prolog object to the corresponding java object.
 * Creation date: (4/29/2002 10:23:07 AM)
 * @return java.lang.Object
 * @param prologObject java.lang.Object
 */
public Object getJavaObject(Object prologObject) {
	if (!(prologObject instanceof Term))
		return prologObject;
	if (prologObject == nullAtom)
		return null;
	if (prologObject == trueAtom)
		return Boolean.TRUE;
	if (prologObject == falseAtom)
		return Boolean.FALSE;
	if (prologObject instanceof IntegerTerm)
		return new Integer(((IntegerTerm) prologObject).value);
	if (prologObject instanceof FloatTerm)
		return new Double(((FloatTerm) prologObject).value);
	if (prologObject instanceof AtomTerm)
		return ((AtomTerm) prologObject).value;
	if (prologObject instanceof JavaObjectTerm)
		return ((JavaObjectTerm) prologObject).value;
	if (prologObject instanceof CompoundTerm) {
		CompoundTerm compoundTerm = (CompoundTerm) prologObject;
		if (compoundTerm.tag == listTag)
			return getList(compoundTerm);
		if (compoundTerm.tag == frameTag) 
			return getFrame(compoundTerm);
	}
	return prologObject;
}
/**
 * Insert the method's description here.
 * Creation date: (4/29/2002 10:16:19 AM)
 * @return edu.stanford.smi.protege.model.KnowledgeBase
 */
public KnowledgeBase getKnowledgeBase() {
	return _tab.getKnowledgeBase();
}
/**
 * Convert a Prolog list to a Java List.
 * Creation date: (4/29/2002 10:38:22 AM)
 * @return java.util.List
 * @param listTerm gnu.prolog.term.CompoundTerm
 */
public List getList(Term listTerm) {
	if (listTerm == AtomTerm.emptyList)
		return new ArrayList(0);
	if (!isList(listTerm))
		listTerm = CompoundTerm.getList(listTerm, AtomTerm.emptyList);
	List javaList = new ArrayList();
	Term currentListTerm = listTerm;
	while (currentListTerm != AtomTerm.emptyList) {
		Term currentHead = ((CompoundTerm) currentListTerm).args[0];
		javaList.add(getJavaObject(currentHead));
		currentListTerm = ((CompoundTerm) currentListTerm).args[1];
	}
	return javaList;
}
/**
 * Return the array as a list term.
 * Creation date: (5/7/2002 9:39:21 AM)
 * @return gnu.prolog.term.Term
 * @param array java.lang.Object[]
 */
public Term getListTerm(Object[] array) {
	return getListTerm(Arrays.asList(array));
}
/**
 * 
 * @return gnu.prolog.term.CompoundTerm
 * @param collection java.util.Collection
 */
public Term getListTerm(Collection collection) {
	Iterator iterator = collection.iterator();
	List list = new ArrayList(collection.size());
	while (iterator.hasNext())
		list.add(getTerm(iterator.next()));
	return CompoundTerm.getList(list);
}
/**
 * 
 * @return gnu.prolog.database.Module
 */
protected Module getModule() {
	return _environment.getModule();
}
/**
 * Insert the method's description here.
 * Creation date: (4/10/2002 10:36:56 AM)
 * @return gnu.prolog.term.Term[]
 * @param clause gnu.prolog.term.CompoundTerm
 */
protected Term[] getSlotValueTerms(CompoundTerm clause) {
	Term body = clause.args[1];
	if (body != trueAtom) //Not a fact
		return null;
	if (!(clause.args[0] instanceof CompoundTerm))
		return null;
	CompoundTerm head = (CompoundTerm) clause.args[0];
	Term[] args = head.args;
	if (!(args[0] instanceof CompoundTerm) || (((CompoundTerm) args[0]).tag != frameTag))
		return null;
	if (args[1] instanceof VariableTerm)
		return null;
	return args;
}
/**
 * Return the PrologTab.
 * Creation date: (5/6/2002 10:33:30 PM)
 * @return protegex.prologtab.PrologTab
 */
public PrologTab getTab() {
	return _tab;
}
/**
 * Convert a Java object to the corresponding Prolog Term.
 * @return gnu.prolog.term.Term
 * @param object java.lang.Object
 */
public Term getTerm(Object obj) {
	if (obj == null)
		return nullAtom;
	if (obj instanceof Term)
		return (Term) obj;
	if (obj instanceof Integer)
		return new IntegerTerm(((Integer) obj).intValue());
	if (obj instanceof Long)
		return new IntegerTerm(((Long) obj).intValue());
	if (obj instanceof Float)
		return new FloatTerm(((Float) obj).doubleValue());
	if (obj instanceof Double)
		return new FloatTerm(((Double) obj).doubleValue());
	if (obj instanceof String)
		return AtomTerm.get((String) obj);
	if (obj instanceof Collection)
		return getListTerm((Collection) obj);
	if (obj instanceof Object[])
		return getListTerm((Object[]) obj);
	if (obj instanceof Frame)
		return getFrameTerm((Frame) obj);
	return new JavaObjectTerm(obj);
}
/**
 * Return whether term is a list or not.
 * Creation date: (5/7/2002 9:19:48 AM)
 * @return boolean
 * @param term gnu.prolog.term.Term
 */
public static boolean isList(Term term) {
	return (term == AtomTerm.emptyList) || 
		((term instanceof CompoundTerm) && (((CompoundTerm) term).tag == listTag));
}
/**
 * Insert the method's description here.
 * Creation date: (4/16/2002 11:38:17 AM)
 * @param inputStream java.io.InputStream
 * @exception java.io.IOException The exception description.
 */
public void loadFrom(String moduleName, java.io.InputStream inputStream) throws java.io.IOException {
	OperatorSet opSet = (_environment == null) ? new OperatorSet() : _environment.getOperatorSet();
	_environment = new Environment(_reader,_writer,opSet,true,this);
	_environment.getModule().addPredicateListener(_environment);
	_environment.ensureLoaded(AtomTerm.get(moduleName),inputStream);
	_interpreter = _environment.createInterpreter();
	_environment.runIntialization(_interpreter);
	for (Iterator ierr = _environment.getLoadingErrors().iterator();ierr.hasNext();) {
		PrologTextLoaderError err = (PrologTextLoaderError)ierr.next();
		_writer.println(err);
		_writer.flush();
        //err.printStackTrace();
	}
}
/**
 * Insert the method's description here.
 * Creation date: (4/11/2002 6:20:12 PM)
 * @return protegex.gnuprolog.PrologGoal
 * @param reader java.io.Reader
 */
public PrologGoal readGoal(java.io.Reader reader) throws PrologTabException {
	ReadOptions readOptions = new ReadOptions();
	readOptions.operatorSet = _environment.getOperatorSet();
	TermReader trd = new TermReader(reader);
	try {
		Term goalTerm = trd.readTerm(readOptions);
		return new GNUPrologGoal(goalTerm,_interpreter,readOptions);
	} catch (Exception e) {
		throw new PrologTabException(e);
	}
}
/**
 * Insert the method's description here.
 * Creation date: (4/10/2002 9:55:40 AM)
 * @param oldName java.lang.String
 * @param newName java.lang.String
 */
public void renameSlotPredicate(java.lang.String oldName, java.lang.String newName) {
	CompoundTermTag oldSlotTag = CompoundTermTag.get(oldName,2);
    Predicate oldPredicate = getModule().getDefinedPredicate(oldSlotTag);
    List clauses;
    if ((oldPredicate == null) || ((clauses = new ArrayList(oldPredicate.getClauses())).size() == 0))
    	return;
 	CompoundTermTag newSlotTag = CompoundTermTag.get(newName,2);
    Predicate newPredicate = getModule().getDefinedPredicate(newSlotTag);
	if (newPredicate == null) {
		newPredicate = getModule().createDefinedPredicate(newSlotTag);
		newPredicate.setType(Predicate.USER_DEFINED);
		newPredicate.setDynamic();
    }
	Iterator iterator = clauses.iterator();
    while (iterator.hasNext()) {
	    Term[] args;
	    CompoundTerm oldClause = (CompoundTerm) iterator.next();
	    if ((args = getSlotValueTerms(oldClause)) != null) {
			CompoundTerm clauseTerm = new CompoundTerm(newSlotTag,args);
			newPredicate.addClauseLast(Predicate.prepareClause(clauseTerm));
			oldPredicate.removeClause(oldClause);
	    }
    }
    if (oldPredicate.getClauses().size() == 0)
		getModule().removeDefinedPredicate(oldSlotTag);
}
/**
 * Insert the method's description here.
 * Creation date: (4/9/2002 10:13:25 AM)
 * @param slotName java.lang.String
 */
public void retractSlotPredicate(java.lang.String slotName) {
	CompoundTermTag slotTag = CompoundTermTag.get(slotName,2);
    Predicate p = getModule().getDefinedPredicate(slotTag);
    if (p != null)
	    getModule().removeDefinedPredicate(slotTag);
}
/**
 * 
 * @param frame edu.stanford.smi.protege.model.Frame
 * @param slot edu.stanford.smi.protege.model.Slot
 */
public void retractSlotValueClause(Frame frame, String slotName) {
	CompoundTermTag slotTag = CompoundTermTag.get(slotName,2);
	Term frameTerm = getTerm(frame);
    Predicate p = getModule().getDefinedPredicate(slotTag);
    if (p != null) {
		Term clauseTerm = findSlotValueClause(p.getClauses(),frameTerm);
		p.removeClause(clauseTerm);
    }
}
}
