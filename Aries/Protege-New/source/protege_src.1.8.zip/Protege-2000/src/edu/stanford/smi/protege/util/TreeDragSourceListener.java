/*
 * The contents of this file are subject to the Mozilla Public License
 * Version 1.1 (the "License");  you may not use this file except in compliance
 * with the License.  You may obtain a copy of the License at
 * http://www.mozilla.org/MPL/
 *
 * Software distributed under the License is distributed on an "AS IS" basis,
 * WITHOUT WARRANTY OF ANY KIND, either express or implied. See the License for
 * the specific language governing rights and limitations under the License.
 *
 * The Original Code is Protege-2000.
 *
 * The Initial Developer of the Original Code is Stanford University. Portions
 * created by Stanford University are Copyright (C) 2001.  All Rights Reserved.
 *
 * Protege-2000 was developed by Stanford Medical Informatics
 * (http://www.smi.stanford.edu) at the Stanford University School of Medicine
 * with support from the National Library of Medicine, the National Science
 * Foundation, and the Defense Advanced Research Projects Agency.  Current
 * information about Protege can be obtained at http://protege.stanford.edu
 *
 * Contributor(s):
 */

package edu.stanford.smi.protege.util;


import java.awt.datatransfer.*;
import java.awt.dnd.*;
import java.util.*;

import javax.swing.*;

/**
 * Base class for a drag and drop source side listener on a JTree.  The actual move and copy operations are handled by
 * template methods.
 *
 * @author    Ray Fergerson <fergerson@smi.stanford.edu>
 */
public abstract class TreeDragSourceListener implements DragGestureListener, DragSourceListener {
    private Collection _paths;

    public abstract boolean canStartDrag(Collection objects);

    public abstract void doCopy(Collection paths);

    public abstract void doMove(Collection paths);

    public void dragDropEnd(DragSourceDropEvent e) {
        if (e.getDropSuccess()) {
            int action = e.getDropAction();
            if (action == DnDConstants.ACTION_MOVE) {
                doMove(_paths);
            } else if (action == DnDConstants.ACTION_COPY) {
                doCopy(_paths);
            } else {
                // do nothing
            }
        }
    }

    public void dragEnter(DragSourceDragEvent e) {
    }

    public void dragExit(DragSourceEvent e) {
    }

    public void dragGestureRecognized(DragGestureEvent e) {
        JTree tree = (JTree) e.getComponent();
        Object[] selectionPaths = tree.getSelectionPaths();
        _paths = (selectionPaths == null) ? Collections.EMPTY_LIST : Arrays.asList(selectionPaths);
        Collection objects = ComponentUtilities.getSelection(tree);
        if (objects != null && canStartDrag(objects)) {
            Transferable t = new TransferableCollection(objects);
            e.startDrag(DragSource.DefaultMoveDrop, t, this);
        }
    }

    public void dragOver(DragSourceDragEvent e) {
    }

    public void dropActionChanged(DragSourceDragEvent e) {
    }
}
