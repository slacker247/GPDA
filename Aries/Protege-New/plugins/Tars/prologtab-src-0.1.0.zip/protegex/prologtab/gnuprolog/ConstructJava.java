package protegex.prologtab.gnuprolog;

import gnu.prolog.term.*;
import gnu.prolog.vm.*;
import java.lang.reflect.*;
/**
 * Built-in for constructing Java objects.
 * Creation date: (5/7/2002 9:02:54 AM)
 * @author: 
 */
public class ConstructJava extends GNUPrologTabBuiltin {
	public static final AtomTerm constructAtom = AtomTerm.get("construct");
/**
 * ConstructJava constructor comment.
 */
public ConstructJava() {
	super();
}
 /** this method is used for execution of code
     * @param interpreter interpreter in which context code is executed 
     * @param backtrackMode true if predicate is called on backtracking and false otherwise
     * @param args arguments of code
     * @return either SUCCESS, SUCCESS_LAST, or FAIL.
     */
public int execute(gnu.prolog.vm.Interpreter interpreter, boolean backtrackMode, gnu.prolog.term.Term[] args) throws gnu.prolog.vm.PrologException {
	if (backtrackMode) return FAIL;
	Term classNameTerm = checkNonVar(args,0);
	Term parameterListTerm = checkList(args,1);
	Term resultTerm = checkVar(args,2);
	
	Object result = null;
	try {
		Object classRef = _engine.getJavaObject(classNameTerm);
		Class clss;
		if (classRef instanceof String)
			clss = Class.forName((String) classRef);
		else
			clss = (Class) classRef;
		Object[] parameters = _engine.getArray(parameterListTerm);
		Constructor constructor = getConstructor(clss,parameters);
		result = constructor.newInstance(parameters);
	} catch (InvocationTargetException ite) {
	} catch (Exception e) {
		PrologException.domainError(constructAtom,AtomTerm.get(e.getClass().getName()));
	}
	return interpreter.unify(resultTerm,_engine.getTerm(result));
}
/**
 * 
 * @return java.lang.reflect.Constructor
 * @param clss java.lang.Class
 * @param parameters java.lang.Object[]
 */
public static Constructor getConstructor(Class clss, Object[] parameters) {
	Constructor[] constructors = clss.getConstructors();
	for (int i=0; i<constructors.length; i++) {
		Class[] parameterTypes = constructors[i].getParameterTypes();
		if (parameterTypes.length == parameters.length) {
			int j=0;
			while(j<parameterTypes.length && (isInstance(parameterTypes[j],parameters[j])))
				j++;
			if (j == parameters.length)
				return constructors[i];
		}
	}
	return null;
}
/**
 * 
 * @return boolean
 * @param clss java.lang.Class
 * @param obj java.lang.Object
 */
public static boolean isInstance(Class clss, Object obj) {
	if (!clss.isPrimitive())
		return clss.isInstance(obj);
	String className = obj.getClass().getName();
	if("java.lang.Boolean".equals(className))
		return java.lang.Boolean.TYPE == clss;
	else if("java.lang.Character".equals(className))
		return java.lang.Character.TYPE == clss;
	else if("java.lang.Byte".equals(className))
		return java.lang.Byte.TYPE == clss;
	else if("java.lang.Short".equals(className))
		return java.lang.Short.TYPE == clss;
	else if("java.lang.Integer".equals(className))
		return java.lang.Integer.TYPE == clss;
	else if("java.lang.Long".equals(className))
		return java.lang.Long.TYPE == clss;
	else if("java.lang.Float".equals(className))
		return java.lang.Float.TYPE == clss;
	else if("java.lang.Double".equals(className))
		return java.lang.Double.TYPE == clss;
	else if("java.lang.Void".equals(className))
		return java.lang.Void.TYPE == clss;
	return false;
}
}
