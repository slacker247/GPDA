/*
 * The contents of this file are subject to the Mozilla Public License
 * Version 1.1 (the "License");  you may not use this file except in compliance
 * with the License.  You may obtain a copy of the License at
 * http://www.mozilla.org/MPL/
 *
 * Software distributed under the License is distributed on an "AS IS" basis,
 * WITHOUT WARRANTY OF ANY KIND, either express or implied. See the License for
 * the specific language governing rights and limitations under the License.
 *
 * The Original Code is Protege-2000.
 *
 * The Initial Developer of the Original Code is Stanford University. Portions
 * created by Stanford University are Copyright (C) 2001.  All Rights Reserved.
 *
 * Protege-2000 was developed by Stanford Medical Informatics
 * (http://www.smi.stanford.edu) at the Stanford University School of Medicine
 * with support from the National Library of Medicine, the National Science
 * Foundation, and the Defense Advanced Research Projects Agency.  Current
 * information about Protege can be obtained at http://protege.stanford.edu
 *
 * Contributor(s):
 */

package edu.stanford.smi.protegex.widget.instancetable;

import java.awt.*;

import javax.swing.*;

import edu.stanford.smi.protege.model.*;
import edu.stanford.smi.protege.util.*;
import edu.stanford.smi.protege.widget.*;

/**
 *  Description of the class
 *
 * @author    William Grosso <grosso@smi.stanford.edu>
 */
public class InstanceRowWidget extends InstanceTableWidget {

    public InstanceRowWidget() {
        setPreferredRows(1);
        setPreferredColumns(2);
    }

    protected void addActionButtonsToComponent(LabeledComponent centerPiece) {
        if (_state.isDisplayViewInstanceButton()) {
            centerPiece.addHeaderButton(new Action_ViewInstance(this, _displayTable));
        }
        if (_state.isDisplayCreateInstanceButton()) {
            centerPiece.addHeaderButton(new Action_CreateInstance(this));
        }
        if (_state.isDisplayAddInstanceButton()) {
            centerPiece.addHeaderButton(new Action_AddInstance(this));
        }
        if (_state.isDisplayRemoveInstanceButton()) {
            centerPiece.addHeaderButton(new Action_RemoveInstance(this, _displayTable));
        }
        if (_state.isDisplayDeleteInstanceButton()) {
            centerPiece.addHeaderButton(new Action_DeleteInstance(this, _displayTable));
        }
    }

    public WidgetConfigurationPanel createWidgetConfigurationPanel() {
        // hack to make sure our state is consistent with the plist.
        _state = new InstanceTableWidgetState(getPropertyList(), getAllowedClses(), getKnowledgeBase());
        return new InstanceRowConfigurationPanel(this);
    }

    public void initialize() {
        buildTableComponents();
        setTableColumnWidths();
        LabeledComponent centerPiece = new LabeledComponent(getLabel(), ComponentFactory.createScrollPane(_displayTable));
        addActionButtonsToComponent(centerPiece);
        JComponent warnings = InstanceRowConfigurationChecks.getShortWarning(getCls(), getSlot());
        if (null != warnings) {
            JPanel panelWithWarning = new JPanel(new BorderLayout());
            panelWithWarning.add(centerPiece, BorderLayout.CENTER);
            panelWithWarning.add(warnings, BorderLayout.SOUTH);
            add(panelWithWarning);
        } else {
            add(centerPiece);
        }
        if (!isRuntime()) {
            (_displayTable.getTableHeader()).setReorderingAllowed(false);
        }
        return;
    }

    public static boolean isSuitable(Cls cls, Slot slot, Facet facet) {
        return InstanceRowConfigurationChecks.checkValidity(cls, slot);
    }

    public static void main(String[] args) {
        edu.stanford.smi.protege.Application.main(args);
    }
}
