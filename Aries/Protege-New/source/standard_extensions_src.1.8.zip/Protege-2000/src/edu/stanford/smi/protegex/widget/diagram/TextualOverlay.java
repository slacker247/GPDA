/*
 * The contents of this file are subject to the Mozilla Public License
 * Version 1.1 (the "License");  you may not use this file except in compliance
 * with the License.  You may obtain a copy of the License at
 * http://www.mozilla.org/MPL/
 *
 * Software distributed under the License is distributed on an "AS IS" basis,
 * WITHOUT WARRANTY OF ANY KIND, either express or implied. See the License for
 * the specific language governing rights and limitations under the License.
 *
 * The Original Code is Protege-2000.
 *
 * The Initial Developer of the Original Code is Stanford University. Portions
 * created by Stanford University are Copyright (C) 2001.  All Rights Reserved.
 *
 * Protege-2000 was developed by Stanford Medical Informatics
 * (http://www.smi.stanford.edu) at the Stanford University School of Medicine
 * with support from the National Library of Medicine, the National Science
 * Foundation, and the Defense Advanced Research Projects Agency.  Current
 * information about Protege can be obtained at http://protege.stanford.edu
 *
 * Contributor(s):
 */

package edu.stanford.smi.protegex.widget.diagram;

import java.awt.*;
import java.util.*;
import java.util.List;

/**
 *  Handles layout of more than one line of text on an actor Known issues: this
 *  code assumes, more or less, a constant font. The only "change" currently
 *  recognized is a change to _string
 *
 * @author    William Grosso <grosso@smi.stanford.edu>
 */
public class TextualOverlay {
    protected StringDescription _descriptionOfASpace;
    protected StringDescription _descriptionOfThreeDots;

    protected DiagramObjectState _diagramObjectState;
    protected Font _fontObject;
    protected Font _modifiedFontObject;

    protected Rectangle _currentLocation;

    protected int _heightInCurrentFont;
    protected int _halfOfHeightInCurrentFont;
    protected boolean _stringChanged;
    protected String _string;
    protected ArrayList _listOfLineDescriptions;

    protected int _totalHeight;
    protected int _maximumLineWidth;
    protected int _widthOfASpace;
    protected Point _startingPoint;
    protected boolean _alwaysDisplayText;

    public TextualOverlay(DiagramObjectState diagramObjectState) {
        this(diagramObjectState, false);
    }

    public TextualOverlay(DiagramObjectState diagramObjectState, boolean alwaysDisplayText) {
        _descriptionOfASpace = new StringDescription(" ");
        _descriptionOfThreeDots = new StringDescription("<more>");
        _diagramObjectState = diagramObjectState;
        _startingPoint = new Point();
        _alwaysDisplayText = alwaysDisplayText;
    }

    protected void buildLines(Graphics g) {
        List stringDescriptions = createStringDescriptions(g);
        _maximumLineWidth = 0;
        _listOfLineDescriptions = new ArrayList();
        Iterator i = stringDescriptions.iterator();
        LineDescription currentLine = new LineDescription(_widthOfASpace);
        _listOfLineDescriptions.add(currentLine);
        while (i.hasNext()) {
            StringDescription nextDescription = (StringDescription) i.next();
            if ((0 != currentLine.getWidth()) && (currentLine.getWidth() + nextDescription.getWidth() > _currentLocation.width)) {
                currentLine.prepareToRender();
                currentLine = new LineDescription(_widthOfASpace);
                _listOfLineDescriptions.add(currentLine);
            }
            currentLine.add(nextDescription);
            if (currentLine.getWidth() > _maximumLineWidth) {
                _maximumLineWidth = currentLine.getWidth();
            }
        }
        if (0 == currentLine.getWidth()) {
            _listOfLineDescriptions.remove(currentLine);
        } else {
            currentLine.prepareToRender();
        }
        _totalHeight = _listOfLineDescriptions.size() * _heightInCurrentFont;
        _stringChanged = false;
        return;
    }

    protected boolean changed(Graphics g, Rectangle location) {
        if (_stringChanged) {
            return true;
        }
        if (location.width != _currentLocation.width) {
            return true;
        }
        if (location.height != _currentLocation.height) {
            return true;
        }
        if (!(_fontObject.equals(g.getFont()))) {
            return true;
        }
        return false;
    }

    protected Point computeStartingPoint(Rectangle location) {
        _startingPoint.x = location.x;
        _startingPoint.y = location.y;
        if (_totalHeight < location.height) {
            if (_diagramObjectState.isVerticallyCenteredText()) {
                _startingPoint.y += (int) ((location.height - _totalHeight) / 2);
            }
        }
        return _startingPoint;
    }

    protected int computeXForDescription(int startingX, ThingWithWidth thingWithWidth) {
        if (thingWithWidth.getWidth() < _currentLocation.width) {
            if (_diagramObjectState.isHorizontallyCenteredText()) {
                return startingX + (int) ((_currentLocation.width - thingWithWidth.getWidth()) / 2);
            }
        }
        return startingX;
    }

    protected List createStringDescriptions(Graphics g) {
        StringTokenizer tokenizer = new StringTokenizer(_string);
        int numberOfWords = tokenizer.countTokens();
        ArrayList returnValue = new ArrayList(numberOfWords);
        for (int loop = 0; loop < numberOfWords; loop++) {
            StringDescription stringDescription = new StringDescription(tokenizer.nextToken());
            returnValue.add(stringDescription);
            stringDescription.computeSize(g, _modifiedFontObject);
        }
        return returnValue;
    }

    public void draw(Graphics g, Rectangle location, boolean isSelected) {
        if ((_alwaysDisplayText) || (_diagramObjectState.isDisplayText())) {
            if (changed(g, location)) {
                rebuildMetricInformation(g, location);
            }
            renderText(g, location, isSelected);
        }
    }

    protected void getFontObject(Graphics g) {
        _fontObject = g.getFont();
        int modifiedStyle;
        if (_diagramObjectState.isItalicText()) {
            if (_diagramObjectState.isBoldText()) {
                modifiedStyle = Font.ITALIC + Font.BOLD;
            } else {
                modifiedStyle = Font.ITALIC;
            }
        } else {
            if (_diagramObjectState.isBoldText()) {
                modifiedStyle = Font.BOLD;
            } else {
                modifiedStyle = Font.PLAIN;
            }
        }
        _modifiedFontObject = _fontObject.deriveFont(modifiedStyle);
        _descriptionOfASpace.computeSize(g, _modifiedFontObject);
        _widthOfASpace = _descriptionOfASpace.getWidth();
        _descriptionOfThreeDots.computeSize(g, _modifiedFontObject);
        FontMetrics fontMetrics = g.getFontMetrics(_modifiedFontObject);
        _heightInCurrentFont = fontMetrics.getHeight();
        _halfOfHeightInCurrentFont = _heightInCurrentFont / 2;
    }

    public String getString() {
        return _string;
    }

    public boolean isAlwaysDisplayText() {
        return _alwaysDisplayText;
    }

    protected void rebuildMetricInformation(Graphics g, Rectangle location) {
        _currentLocation = new Rectangle(location);
        getFontObject(g);
        buildLines(g);
    }

    protected void renderText(Graphics g, Rectangle location, boolean isSelected) {
        Point startingPoint = computeStartingPoint(location);
        startingPoint.y += _halfOfHeightInCurrentFont;
        int maxY = location.y + location.height;
        int originalX = startingPoint.x;
        Iterator i = _listOfLineDescriptions.iterator();
        Color graphicsColor = g.getColor();
        Color textColor = _diagramObjectState.getTextColor();
        if (!graphicsColor.equals(textColor)) {
            g.setColor(textColor);
        }
        Font currentFont = g.getFont();
        g.setFont(_modifiedFontObject);
        while (i.hasNext()) {
            LineDescription nextDescription = (LineDescription) i.next();
            startingPoint.x = computeXForDescription(originalX, nextDescription);
            nextDescription.render(g, startingPoint);
            startingPoint.y += _heightInCurrentFont;
            if (startingPoint.y > maxY) {
                break;
            }
        }
        if (i.hasNext()) {
            g.drawString(
                _descriptionOfThreeDots.getString(),
                computeXForDescription(originalX, _descriptionOfThreeDots),
                startingPoint.y);
        }
        g.setFont(currentFont);
    }

    public void setAlwaysDisplayText(boolean alwaysDisplayText) {
        _alwaysDisplayText = alwaysDisplayText;
    }

    public void setString(String string) {
        _stringChanged = true;
        _string = string;
    }
}
