package dfki.protege.oil_tab;

public class FactBOTTOM extends FactConcept {

  public String toXML() {
    return "<BOTTOM/>";
  }

  public String toLaTeX() {
    return "\\bot";
  }

}

