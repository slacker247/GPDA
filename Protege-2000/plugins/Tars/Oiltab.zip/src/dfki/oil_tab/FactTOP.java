package dfki.protege.oil_tab;

public class FactTOP extends FactConcept {

  public String toXML() {
    return "<TOP/>";
  }

  public String toLaTeX() {
    return "\\top";
  }

}

