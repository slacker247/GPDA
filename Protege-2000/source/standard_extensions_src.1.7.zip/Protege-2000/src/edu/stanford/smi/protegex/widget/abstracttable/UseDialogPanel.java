/*
 * The contents of this file are subject to the Mozilla Public License
 * Version 1.1 (the "License");  you may not use this file except in compliance
 * with the License.  You may obtain a copy of the License at
 * http://www.mozilla.org/MPL/
 *
 * Software distributed under the License is distributed on an "AS IS" basis,
 * WITHOUT WARRANTY OF ANY KIND, either express or implied. See the License for
 * the specific language governing rights and limitations under the License.
 *
 * The Original Code is Protege-2000.
 *
 * The Initial Developer of the Original Code is Stanford University. Portions
 * created by Stanford University are Copyright (C) 2001.  All Rights Reserved.
 *
 * Protege-2000 was developed by Stanford Medical Informatics
 * (http://www.smi.stanford.edu) at the Stanford University School of Medicine
 * with support from the National Library of Medicine, the National Science
 * Foundation, and the Defense Advanced Research Projects Agency.  Current
 * information about Protege can be obtained at http://protege.stanford.edu
 *
 * Contributor(s):
 */

package edu.stanford.smi.protegex.widget.abstracttable;

import edu.stanford.smi.protege.util.*;
import javax.swing.event.*;
import javax.swing.*;
import java.awt.event.*;
import java.awt.*;
import java.util.*;

/**
 *  Description of the Class
 *
 * @author    William Grosso <grosso@smi.stanford.edu>
 */
public class UseDialogPanel extends LabeledComponent {
    private JTextField _dialogTitleTextField;
    private JCheckBox _useDialogCheckBox;
    private ArrayList _actionListeners;
    private boolean _notInSetMethod;

    private class CheckBoxListener implements ActionListener {
        public void actionPerformed(ActionEvent e) {
            announceChanges();
        }
    }

    private class TextFieldChanged implements DocumentListener {
        public void changedUpdate(DocumentEvent event) {
            announceChanges();
        }

        public void insertUpdate(DocumentEvent event) {
            announceChanges();
        }

        public void removeUpdate(DocumentEvent event) {
            announceChanges();
        }
    }

    public UseDialogPanel(String selectionType, String label, boolean useDialog, String dialogTitle) {
        super(label, (JComponent) null);
        setCenterComponent(createCenterPanel(selectionType, useDialog, dialogTitle));
        setBorder(BorderFactory.createEtchedBorder());
        _notInSetMethod = true;
    }

    public void addActionListener(ActionListener listener) {
        if (!_actionListeners.contains(listener)) {
            ArrayList newActionListeners = new ArrayList(_actionListeners);
            newActionListeners.add(listener);
            _actionListeners = newActionListeners;
        }
        return;
    }

    private void announceChanges() {
        if (_notInSetMethod) {
            Iterator i = _actionListeners.iterator();
            while (i.hasNext()) {
                ((ActionListener) i.next()).actionPerformed(null);
            }
        }
    }

    private JPanel createCenterPanel(String selectionType, boolean useDialog, String dialogTitle) {
        JPanel returnValue = new JPanel(new GridBagLayout());
        _useDialogCheckBox = new JCheckBox("Use a dialog panel to select " + selectionType);
        _dialogTitleTextField = new JTextField(30);
        _actionListeners = new ArrayList();

        GridBagConstraints gbc = new GridBagConstraints();
        gbc.gridwidth = 4;
        gbc.gridheight = 1;
        gbc.gridx = 0;
        gbc.gridy = 0;
        gbc.weightx = 1.0;
        gbc.weighty = 0.0;
        gbc.fill = GridBagConstraints.HORIZONTAL;
        returnValue.add(_useDialogCheckBox, gbc);

        gbc.weightx = 0.0;
        gbc.gridy = 1;
        gbc.gridwidth = 1;
        returnValue.add(new JLabel("Dialog Title  "), gbc);

        gbc.weightx = 1.0;
        gbc.gridy = 1;
        gbc.gridx = 1;
        gbc.gridwidth = 2;
        returnValue.add(_dialogTitleTextField, gbc);

        setUseDialog(useDialog);
        setDialogTitle(dialogTitle);
        (_dialogTitleTextField.getDocument()).addDocumentListener(new TextFieldChanged());
        _useDialogCheckBox.addActionListener(new CheckBoxListener());
        return returnValue;
    }

    public String getDialogTitle() {
        return _dialogTitleTextField.getText();
    }

    public boolean getUseDialog() {
        return _useDialogCheckBox.isSelected();
    }

    public boolean isUseDialog() {
        return _useDialogCheckBox.isSelected();
    }

    public void removeActionListener(ActionListener listener) {
        if (_actionListeners.contains(listener)) {
            ArrayList newActionListeners = new ArrayList(_actionListeners);
            newActionListeners.remove(listener);
            _actionListeners = newActionListeners;
        }
        return;
    }

    public void setDialogTitle(String dialogTitle) {
        _notInSetMethod = false;
        _dialogTitleTextField.setText(dialogTitle);
        _notInSetMethod = true;
    }

    public void setUseDialog(boolean useDialog) {
        _notInSetMethod = false;
        _useDialogCheckBox.setSelected(useDialog);
        _notInSetMethod = true;
    }
}
