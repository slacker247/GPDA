package dfki.protege.oil_tab;

public abstract class FactRole extends FactExpression {

}

