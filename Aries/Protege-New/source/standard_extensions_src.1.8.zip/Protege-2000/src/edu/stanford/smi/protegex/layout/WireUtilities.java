/*
 * The contents of this file are subject to the Mozilla Public License
 * Version 1.1 (the "License");  you may not use this file except in compliance
 * with the License.  You may obtain a copy of the License at
 * http://www.mozilla.org/MPL/
 *
 * Software distributed under the License is distributed on an "AS IS" basis,
 * WITHOUT WARRANTY OF ANY KIND, either express or implied. See the License for
 * the specific language governing rights and limitations under the License.
 *
 * The Original Code is Protege-2000.
 *
 * The Initial Developer of the Original Code is Stanford University. Portions
 * created by Stanford University are Copyright (C) 2001.  All Rights Reserved.
 *
 * Protege-2000 was developed by Stanford Medical Informatics
 * (http://www.smi.stanford.edu) at the Stanford University School of Medicine
 * with support from the National Library of Medicine, the National Science
 * Foundation, and the Defense Advanced Research Projects Agency.  Current
 * information about Protege can be obtained at http://protege.stanford.edu
 *
 * Contributor(s):
 */

package edu.stanford.smi.protegex.layout;

import java.awt.*;

/**
 *  Description of the class
 *
 * @author    William Grosso <grosso@smi.stanford.edu>
 */
public class WireUtilities {
    // wire types
    public final static String SOLID = "Solid Line";
    public final static String DOTTED = "Dotted Line";
    public final static String DASHED = "Dashed Line";
    public final static String SEMI_DASHED = "Dash-Dot Line";
    // dot-dash
    public final static String[] STYLE_NAMES = {SOLID, DOTTED, DASHED, SEMI_DASHED};

    /*
     * "arrowhead" types
     */
    public final static String ENDPOINT_SQUARE = "Square Endpoint";
    public final static String ENDPOINT_CIRCLE = "Circular Endpoint";
    public final static String ENDPOINT_ARROWHEAD = "Arrowhead Endpoint";
    public final static String ENDPOINT_NONE = "No Endpoint";
    public final static String ENDPOINT_NO_CONNECTION = "No Connection Endpoint";
    // Not used
    public final static String[] ARROW_NAMES = {ENDPOINT_SQUARE, ENDPOINT_CIRCLE, ENDPOINT_ARROWHEAD, ENDPOINT_NONE};

    public final static String DEFAULT_WIRE_TYPE = SOLID;
    public final static String DEFAULT_WIRE_STARTING_ARROW = ENDPOINT_SQUARE;
    public final static String DEFAULT_WIRE_ENDING_ARROW = ENDPOINT_ARROWHEAD;
    public final static Color DEFAULT_WIRE_COLOR = Color.red;
    public final static Color DEFAULT_TEXT_COLOR = Color.black;
    public final static boolean DEFAULT_DISPLAY_TEXT = false;
    public final static boolean DEFAULT_ANCHOR_TEXT_AT_UPPER_LEFT_CORNER = true;
    public final static int BIG_ENDPOINT_SIZE = 12;
    // used during selection
    public final static int SMALL_ENDPOINT_SIZE = 8;
    // used when not selected
    public final static int HOLLOW_ENDPOINT_REDUCTION = 4;
    // used for unconnected endpoint draws
    public final static int HOLLOW_ENDPOINT_OFFSET = 2;

    // arc angles for "arrow" arrowhead
    public final static int HALF_ARROW_ANGLE = 25;
    // degrees
    public final static int TOTAL_ARROW_ANGLE = 50;

    public final static int HOLLOW_HALF_ARROW_ANGLE = 17;
    public final static int HOLLOW_TOTAL_ARROW_ANGLE = 34;

    public final static double RADIAN_TO_ANGLE_CONVERSION_FACTOR = 180 / Math.PI;

    private static final float DASH_LENGTH = 10.0f;
    private static final float[] DASH_PATTERN = {DASH_LENGTH};
    private static final Stroke DASH_STROKE = new BasicStroke(1.0f,
            BasicStroke.CAP_BUTT, BasicStroke.JOIN_MITER, DASH_LENGTH, DASH_PATTERN, 0.0f);

    private static final float DOT_LENGTH = 3.0f;
    private static final float[] DOT_PATTERN = {DOT_LENGTH};
    private static final Stroke DOT_STROKE = new BasicStroke(1.0f,
            BasicStroke.CAP_BUTT, BasicStroke.JOIN_MITER, DOT_LENGTH, DOT_PATTERN, 0.0f);

    private static final float DASH_DOT_LENGTH = 3.0f;
    private static final float[] DASH_DOT_PATTERN = {DASH_LENGTH, DASH_LENGTH, DOT_LENGTH, DASH_LENGTH};
    private static final Stroke DASH_DOT_STROKE = new BasicStroke(1.0f,
            BasicStroke.CAP_BUTT, BasicStroke.JOIN_MITER, DASH_DOT_LENGTH, DASH_DOT_PATTERN, 0.0f);

    private static void _drawLine(Graphics g, int x1, int y1, int x2, int y2, Stroke s) {
        Graphics2D g2d = (Graphics2D) g;
        Stroke oldStroke = g2d.getStroke();
        g2d.setStroke(s);
        g2d.drawLine(x1, y1, x2, y2);
        g2d.setStroke(oldStroke);
    }

    private static int computeAngle(int xOrigin, int yOrigin, int xTarget, int yTarget) {
        double deltaX = xTarget - xOrigin;
        double deltaY = yTarget - yOrigin;
        double angleAtOrigin = Math.atan2(deltaX, deltaY) * RADIAN_TO_ANGLE_CONVERSION_FACTOR;
        return (int) angleAtOrigin + 90;
    }

    private static void drawArrowHeadEndpoint(
        Graphics g,
        int xOrigin,
        int yOrigin,
        int xTarget,
        int yTarget,
        int radius,
        boolean endpointIsConnected,
        Color wireColor) {
        int angleOfLine = computeAngle(xOrigin, yOrigin, xTarget, yTarget);
        int doubleRadius = 2 * radius;
        int xCoord = xTarget - radius;
        int yCoord = yTarget - radius;
        if (endpointIsConnected) {
            g.fillArc(xCoord, yCoord, doubleRadius, doubleRadius, (int) (angleOfLine - HALF_ARROW_ANGLE), TOTAL_ARROW_ANGLE);
        } else {
            g.fillArc(xCoord, yCoord, doubleRadius, doubleRadius, (int) (angleOfLine - HALF_ARROW_ANGLE), TOTAL_ARROW_ANGLE);
            g.setColor(Color.white);
            g.fillArc(xCoord, yCoord, doubleRadius, doubleRadius, (int)
                (angleOfLine - HOLLOW_HALF_ARROW_ANGLE),
                HOLLOW_TOTAL_ARROW_ANGLE);
            g.setColor(wireColor);
            g.drawArc(xCoord, yCoord, doubleRadius, doubleRadius, (int) (angleOfLine - HALF_ARROW_ANGLE), TOTAL_ARROW_ANGLE);
        }
    }

    private static void drawCircularEndpoint(
        Graphics g,
        int x,
        int y,
        int radius,
        boolean endpointIsConnected,
        Color wireColor) {
        int halfRadius = radius / 2;
        if (endpointIsConnected) {
            g.fillOval(x - halfRadius, y - halfRadius, radius, radius);
        } else {
            int xCoord = x - halfRadius;
            int yCoord = y - halfRadius;
            g.fillOval(xCoord, yCoord, radius, radius);
            g.setColor(Color.white);
            g.fillOval(
                xCoord + HOLLOW_ENDPOINT_OFFSET,
                yCoord + HOLLOW_ENDPOINT_OFFSET,
                radius - HOLLOW_ENDPOINT_REDUCTION,
                radius - HOLLOW_ENDPOINT_REDUCTION);
            g.setColor(wireColor);
        }
    }

    private static void drawDashedLine(Graphics g, int startX, int startY, int endX, int endY) {
        _drawLine(g, startX, startY, endX, endY, DASH_STROKE);
    }

    private static void drawDottedLine(Graphics g, int startX, int startY, int endX, int endY) {
        _drawLine(g, startX, startY, endX, endY, DOT_STROKE);
    }

    private static void drawEndingEndpoint(
        Graphics g,
        String endpointType,
        int startX,
        int startY,
        int endX,
        int endY,
        boolean isHighlighted,
        boolean endpointIsConnected,
        Color wireColor) {
        int radius = (isHighlighted) ? BIG_ENDPOINT_SIZE : SMALL_ENDPOINT_SIZE;
        if (endpointType.equals(ENDPOINT_CIRCLE)) {
            drawCircularEndpoint(g, endX, endY, radius, endpointIsConnected, wireColor);
        }
        if (endpointType.equals(ENDPOINT_SQUARE)) {
            drawCircularEndpoint(g, endX, endY, radius, endpointIsConnected, wireColor);
            return;
        }
        if (endpointType.equals(ENDPOINT_ARROWHEAD)) {
            drawArrowHeadEndpoint(g, startX, startY, endX, endY, radius, endpointIsConnected, wireColor);
        }
    }

    private static void drawEndpoints(
        Graphics g,
        String startingEndpointType,
        String endingEndpointType,
        int startX,
        int startY,
        int endX,
        int endY,
        boolean isHighlighted,
        boolean startingEndpointIsConnected,
        boolean endingEndpointIsConnected,
        Color wireColor) {
        drawStartingEndpoint(
            g,
            startingEndpointType,
            startX,
            startY,
            endX,
            endY,
            isHighlighted,
            startingEndpointIsConnected,
            wireColor);
        drawEndingEndpoint(
            g,
            endingEndpointType,
            startX,
            startY,
            endX,
            endY,
            isHighlighted,
            endingEndpointIsConnected,
            wireColor);
    }

    private static void drawSemiDashedLine(Graphics g, int startX, int startY, int endX, int endY) {
        _drawLine(g, startX, startY, endX, endY, DASH_DOT_STROKE);
    }

    private static void drawSolidLine(Graphics g, int startX, int startY, int endX, int endY) {
        g.drawLine(startX, startY, endX, endY);
    }

    private static void drawStartingEndpoint(
        Graphics g,
        String endpointType,
        int startX,
        int startY,
        int endX,
        int endY,
        boolean isHighlighted,
        boolean endpointIsConnected,
        Color wireColor) {
        int radius = (isHighlighted) ? BIG_ENDPOINT_SIZE : SMALL_ENDPOINT_SIZE;
        if (endpointType.equals(ENDPOINT_CIRCLE)) {
            drawCircularEndpoint(g, startX, startY, radius, endpointIsConnected, wireColor);
        }
        if (endpointType.equals(ENDPOINT_SQUARE)) {
            drawCircularEndpoint(g, startX, startY, radius, endpointIsConnected, wireColor);
            return;
        }
        if (endpointType.equals(ENDPOINT_ARROWHEAD)) {
            drawArrowHeadEndpoint(g, endX, endY, startX, startY, radius, endpointIsConnected, wireColor);
        }
    }

    public static void drawWire(
        Graphics g,
        String wireType,
        String startingEndpoint,
        String endingEndpoint,
        Color wireColor,
        int startX,
        int startY,
        int endX,
        int endY,
        boolean isHighlighted,
        boolean startingEndpointIsConnected,
        boolean endingEndpointIsConnected) {
        Color colorToUseWhenDrawing = isHighlighted ? Color.black : wireColor;
        g.setColor(colorToUseWhenDrawing);
        drawWireBody(g, colorToUseWhenDrawing, wireType, startX, startY, endX, endY);
        drawEndpoints(
            g,
            startingEndpoint,
            endingEndpoint,
            startX,
            startY,
            endX,
            endY,
            isHighlighted,
            startingEndpointIsConnected,
            endingEndpointIsConnected,
            colorToUseWhenDrawing);
        return;
    }

    private static void drawWireBody(
        Graphics g,
        Color wireColor,
        String wireType,
        int startX,
        int startY,
        int endX,
        int endY) {
        if (wireType.equals(SOLID)) {
            drawSolidLine(g, startX, startY, endX, endY);
            return;
        }
        if (wireType.equals(DOTTED)) {
            drawDottedLine(g, startX, startY, endX, endY);
            return;
        }
        if (wireType.equals(DASHED)) {
            drawDashedLine(g, startX, startY, endX, endY);
            return;
        }
        if (wireType.equals(SEMI_DASHED)) {
            drawSemiDashedLine(g, startX, startY, endX, endY);
            return;
        }
    }
}
