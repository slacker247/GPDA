/*
 * The contents of this file are subject to the Mozilla Public License
 * Version 1.1 (the "License");  you may not use this file except in compliance
 * with the License.  You may obtain a copy of the License at
 * http://www.mozilla.org/MPL/
 *
 * Software distributed under the License is distributed on an "AS IS" basis,
 * WITHOUT WARRANTY OF ANY KIND, either express or implied. See the License for
 * the specific language governing rights and limitations under the License.
 *
 * The Original Code is Protege-2000.
 *
 * The Initial Developer of the Original Code is Stanford University. Portions
 * created by Stanford University are Copyright (C) 2001.  All Rights Reserved.
 *
 * Protege-2000 was developed by Stanford Medical Informatics
 * (http://www.smi.stanford.edu) at the Stanford University School of Medicine
 * with support from the National Library of Medicine, the National Science
 * Foundation, and the Defense Advanced Research Projects Agency.  Current
 * information about Protege can be obtained at http://protege.stanford.edu
 *
 * Contributor(s):
 */

package edu.stanford.smi.protegex.layout;

import java.awt.event.*;
import java.awt.*;

/**
 *  The processDragging method makes a fairly huge assumption. Namely, that
 *  things have a ninimum size (and that it's not reasonable to move past them).
 *
 * @author    William Grosso <grosso@smi.stanford.edu>
 */
public class ResizingHandler extends AbstractDragHandler {
    // The minimum size is 5 control points wide
    private int _controlPointBeingDragged;
    private Point _scratchPoint;

    public ResizingHandler(Actor actor) {
        super(actor);
        _scratchPoint = new Point();
    }

    public Object copy() {
        return new ResizingHandler(_actor);
    }

    public void processDragging(MouseEvent e) {
        _actor.moveControlPoint(_controlPointBeingDragged, e.getPoint());
        return;
    }

    public void processIncrementalDrag(int deltaX, int deltaY) {

    }

    public boolean wantDrag(MouseEvent e) {
        _controlPointBeingDragged = _actor.getControlPointForPoint(e.getPoint());
        if ((_controlPointBeingDragged == ControlPoints.NOT_A_VALID_CONTROL_POINT)
            || (_controlPointBeingDragged == ControlPoints.MIDDLE)) {
            return false;
        }
        return true;
    }
}
