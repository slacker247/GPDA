/*
 * The contents of this file are subject to the Mozilla Public License
 * Version 1.1 (the "License");  you may not use this file except in compliance
 * with the License.  You may obtain a copy of the License at
 * http://www.mozilla.org/MPL/
 *
 * Software distributed under the License is distributed on an "AS IS" basis,
 * WITHOUT WARRANTY OF ANY KIND, either express or implied. See the License for
 * the specific language governing rights and limitations under the License.
 *
 * The Original Code is Protege-2000.
 *
 * The Initial Developer of the Original Code is Stanford University. Portions
 * created by Stanford University are Copyright (C) 2001.  All Rights Reserved.
 *
 * Protege-2000 was developed by Stanford Medical Informatics
 * (http://www.smi.stanford.edu) at the Stanford University School of Medicine
 * with support from the National Library of Medicine, the National Science
 * Foundation, and the Defense Advanced Research Projects Agency.  Current
 * information about Protege can be obtained at http://protege.stanford.edu
 *
 * Contributor(s):
 */

package edu.stanford.smi.protegex.storage.rdf;

import java.util.*;
import org.w3c.rdf.model.*;
import edu.stanford.smi.protegex.storage.walker.*;
import org.w3c.rdf.vocabulary.rdf_syntax_19990222.*;
import org.w3c.rdf.vocabulary.rdf_schema_19990303.*;


public class RDFFrame implements WalkerFrame {

  public Resource _resource;
  public String _namespace;
  public String _localName;
  public Collection _classes;
  public Collection _properties;

  static final String SYSTEMNAMESPACE = "http://protege.stanford.edu/system#";

  public RDFFrame(Resource resource, 
		  Collection classes, Collection properties) {
    _resource = resource;
    _classes = classes;
    _properties = properties;
    init();
  }

  public String getName() { // full unique name
    try { return _resource.getURI(); }
    catch (Exception e) { return _localName; }
  }

  public String getDisplayName() { // for GUIs/browsers etc.
    return _localName; // rdfs:label?
  }

  public String getNamespace() {
    return _namespace;
  }

  public String getLocalName() {
    return _localName;
  }

  public String toString() {
    return getName();
  }

  public boolean isClass() {
    return _classes.contains(_resource);
  }

  public boolean isSlot() {
    return _properties.contains(_resource);
  }

  public boolean isThing() {
    return _resource.equals(RDFS.Resource) ||
      _resource.equals(RDFS.ConstraintResource); 
      // ??? create or use :CONSTRAINT ??? !!!
  }

  public boolean isStandardClass() {
    return _resource.equals(RDFS.Class);
  }

  public boolean isStandardSlot() {
    return _resource.equals(RDF.Property) ||
      _resource.equals(RDFS.ConstraintProperty); // not supported!!!
  }


  public void init() {

    // try to figure out namespace and local name 

    try { 
      _namespace = _resource.getNamespace();
      _localName = _resource.getLocalName();
    } catch (Exception e) {
      _localName = "?";
    }

    if (_namespace == null) { // guess
      // System.out.println("no namespace: " + _resource);
      if (_localName.startsWith("http://")) { // or ftp ... !!!
	// this case should already be handled in the RDF API, but ....
	// find last # or /
	int p = _localName.lastIndexOf('#');
	if (p == -1)
	  p = _localName.lastIndexOf('/');
	if (p != -1) { // split
	  _namespace = _localName.substring(0, p+1);
	  _localName = _localName.substring(p+1);
	}
      } else if (_localName.startsWith("#")) {
	// should never happen
	// since source.setSystemId(_namespace) is used
	// in RDFFrameWalker.java, but ... !!!
	_localName = _localName.substring(1);
      } // else other strategies (split at first :)
    }

    if (_namespace != null) { // check correctness
      if (_namespace.indexOf(' ') != -1)
	// we should report this!
	_namespace = _namespace.replace(' ', '_');
      // other things?
    }

    // same for local name? is done anyway on export!

    // map system names starting with '_' to originial Protege names
    // this is more or less a hack !!!
    if (_namespace != null && _namespace.equals(SYSTEMNAMESPACE)
        && _localName.charAt(0) == '_') {
      _namespace = null; // default namespace
      int l = _localName.length();
      StringBuffer newName = new StringBuffer(); 
      newName.append(':');
      for (int i = 1; i < l; i++) { // skip leading _
        char c = _localName.charAt(i);
	if (c == '_')
	  newName.append('-');
	else
	  newName.append(Character.toUpperCase(c));
      }
      _localName = newName.toString();
    }

  }


}


