/*
 * The contents of this file are subject to the Mozilla Public License
 * Version 1.1 (the "License");  you may not use this file except in compliance
 * with the License.  You may obtain a copy of the License at
 * http://www.mozilla.org/MPL/
 *
 * Software distributed under the License is distributed on an "AS IS" basis,
 * WITHOUT WARRANTY OF ANY KIND, either express or implied. See the License for
 * the specific language governing rights and limitations under the License.
 *
 * The Original Code is Protege-2000.
 *
 * The Initial Developer of the Original Code is Stanford University. Portions
 * created by Stanford University are Copyright (C) 2001.  All Rights Reserved.
 *
 * Protege-2000 was developed by Stanford Medical Informatics
 * (http://www.smi.stanford.edu) at the Stanford University School of Medicine
 * with support from the National Library of Medicine, the National Science
 * Foundation, and the Defense Advanced Research Projects Agency.  Current
 * information about Protege can be obtained at http://protege.stanford.edu
 *
 * Contributor(s):
 */

package edu.stanford.smi.protegex.widget.diagram;

import java.util.*;

import javax.swing.*;

import edu.stanford.smi.protege.event.*;
import edu.stanford.smi.protege.model.*;
import edu.stanford.smi.protege.util.*;
import edu.stanford.smi.protege.widget.*;
import edu.stanford.smi.protegex.layout.*;
import edu.stanford.smi.protegex.util.*;

/**
 *  Description of the class
 *
 * @author    William Grosso <grosso@smi.stanford.edu>
 */
public class DiagramWidget extends AbstractSlotWidget implements Constants, VisibilityChecker {
    private Instance _actualNetworkInstance;
    private ArrayList _currentNodes;
    private ArrayList _currentConnectors;

    private LabeledComponent _labeledComponent;

    private DiagramWidgetState _state;
    private DiagramsPanel _mainDiagramArea = null;
    private Diagrams_AddInstance _addInstance = null;
    private Diagrams_CreateInstance _createInstance = null;

    private Slot _connectorsSlot;
    private Slot _nodesSlot;

    private ConnectorSlotChanged _connectorsSlotChanged;
    private VisibleFrameChanged _visibleFrameChanged;
    private LinkedList _internalFrames;
    private DrawingAreaDelegate _drawingAreaDelegate;
    private AggregatingVisibilityChecker _aggregatingVisibilityChecker;

    private OptionsFlowchartPanel _flowchartPanel;
    static int i = 0;

    private class ConnectorSlotChanged extends FrameAdapter {
        public void ownSlotValueChanged(FrameEvent event) {
            Slot slotThatChanged = event.getSlot();
            if (slotThatChanged.equals(_connectorsSlot)) {
                _currentConnectors = new ArrayList(_actualNetworkInstance.getOwnSlotValues(_connectorsSlot));
                _mainDiagramArea.refreshConnectors();
                DiagramUtilities.cleanupLayoutInformation(_actualNetworkInstance);
            }
        }
    }

    private class VisibleFrameChanged extends FrameAdapter {
        public void browserTextChanged(FrameEvent event) {
            repaint();
        }
    }

    private void addButtons() {
        AnimationContext mainDrawingArea = _mainDiagramArea.getMainDrawingArea();
        if (_state.isDisplayFlowchartButton()) {
            _labeledComponent.addHeaderButton(new Diagrams_DisplayFlowchart(this, _state, mainDrawingArea));
        }
        if (_state.isDisplayWirebuilderButton()) {
            _labeledComponent.addHeaderButton(new Diagrams_DisplayWireBuilder(_mainDiagramArea, this, mainDrawingArea));
        }
        if (_state.isDisplayClassBasedHiderButton()) {
            _labeledComponent.addHeaderButton(new Diagrams_DisplayTypeBasedFrameHider(this, _state, mainDrawingArea));
        }
        if (_state.isDisplayLegendButton()) {
            _labeledComponent.addHeaderButton(new Diagrams_DisplayLegend(this, _state, mainDrawingArea));
        }
        if (_state.isDisplayReusableFormButton()) {
            _labeledComponent.addHeaderButton(new Diagrams_MonitorSelection(this, _state, mainDrawingArea));
        }
        if (_state.isDisplayThumbnailButton()) {
            _labeledComponent.addHeaderButton(new Diagrams_DisplayThumbnail(this, _state, mainDrawingArea));
        }
        _labeledComponent.addHeaderButton(new SpacerButton());
        if (_state.isDisplayViewInstanceButton()) {
            _labeledComponent.addHeaderButton(new Diagrams_ViewAction(this, mainDrawingArea));
        }
        if (_state.isDisplayCreateInstanceButton()) {
            _createInstance = new Diagrams_CreateInstance(_mainDiagramArea, this, mainDrawingArea);
            _labeledComponent.addHeaderButton(_createInstance);
        }
        if (_state.isDisplayAddInstanceButton()) {
            _addInstance = new Diagrams_AddInstance(_mainDiagramArea, this, mainDrawingArea);
            _labeledComponent.addHeaderButton(_addInstance);
        }
        if (_state.isDisplayRemoveInstanceButton()) {
            _labeledComponent.addHeaderButton(new Diagrams_RemoveInstance(this, mainDrawingArea));
        }
        if (_state.isDisplayDeleteInstanceButton()) {
            _labeledComponent.addHeaderButton(new Diagrams_DeleteInstance(this, mainDrawingArea));
        }
        if (_state.isDisplayPrototypeButton()) {
            _labeledComponent.addHeaderButton(
                new Diagrams_PrototypeAction(_mainDiagramArea, this, mainDrawingArea, _state.getPrototypeDepth()));
        }
    }

    public void addInternalFrame(InternalFrame newFrame) {
        _internalFrames.remove(newFrame);
        _internalFrames.addFirst(newFrame);
        newFrame.setCurrentlyBeingDisplayed(true);
        rebuildFromScratch();
        return;
    }

    public void addVisibilityChecker(String name, VisibilityChecker newVisibilityChecker) {
        _aggregatingVisibilityChecker.addVisibilityChecker(name, newVisibilityChecker);
    }

    private void attachListeners() {
        if (null == _actualNetworkInstance) {
            return;
        }
        _actualNetworkInstance.addFrameListener(_connectorsSlotChanged);
        if (null != _currentNodes) {
            Iterator i = _currentNodes.iterator();
            while (i.hasNext()) {
                Frame nextFrame = (Frame) i.next();
                nextFrame.addFrameListener(_visibleFrameChanged);
            }
        }
        if (null != _currentConnectors) {
            Iterator i = _currentConnectors.iterator();
            while (i.hasNext()) {
                Frame nextFrame = (Frame) i.next();
                nextFrame.addFrameListener(_visibleFrameChanged);
            }
        }
    }

    private void buildGUI() {
        createWidgetBody();
        addButtons();
        add(_labeledComponent);
    }

    private void configureButtons() {
        Cls networkInstanceType = _actualNetworkInstance.getDirectType();
        Slot nodesSlot = DiagramUtilities.getNodeSlot(networkInstanceType);
        Slot connectorsSlot = getKnowledgeBase().getSlot(CONNECTORS_SLOT);
        if ((null != _addInstance) || (null != _createInstance)) {
            ArrayList allowedClses;
            allowedClses = new ArrayList(networkInstanceType.getTemplateSlotAllowedClses(nodesSlot));
            allowedClses.addAll(networkInstanceType.getTemplateSlotAllowedClses(connectorsSlot));
            if (null != _addInstance) {
                _addInstance.setAllowedClses(allowedClses);
            }
            if (null != _createInstance) {
                _createInstance.setAllowedClses(allowedClses);
            }
        }
    }

    private void createNetworkDescription() {
        Instance newInstance = getInstance();
        if (newInstance != _actualNetworkInstance) {
            detachListeners();
            _actualNetworkInstance = newInstance;
        }
        if (null == _actualNetworkInstance) {
            return;
        }
        _nodesSlot = DiagramUtilities.getNodeSlot(_actualNetworkInstance.getDirectType());
        _currentConnectors = new ArrayList(_actualNetworkInstance.getOwnSlotValues(_connectorsSlot));
        _currentNodes = new ArrayList(_actualNetworkInstance.getOwnSlotValues(_nodesSlot));
        attachListeners();
        _mainDiagramArea.refreshNodes();
        DiagramUtilities.cleanupLayoutInformation(_actualNetworkInstance);
        configureButtons();
    }

    private void createWidgetBody() {
        if (_state.isPaletteDisplayed()) {
            _mainDiagramArea = new DiagramsPanelWithPalette(this);
            _labeledComponent = new LabeledComponent(getLabel(), (JComponent) _mainDiagramArea, true);
        } else {
            _mainDiagramArea = new DiagramsPanelWithoutPalette(this);
            _labeledComponent = new LabeledComponent(getLabel(), (JComponent) _mainDiagramArea, true);
        }
    }

    public WidgetConfigurationPanel createWidgetConfigurationPanel() {
        return new DiagramWidgetConfigurationPanel(this);
    }

    private void detachListeners() {
        if (null == _actualNetworkInstance) {
            return;
        }
        _actualNetworkInstance.removeFrameListener(_connectorsSlotChanged);
        if (null != _currentNodes) {
            Iterator i = _currentNodes.iterator();
            while (i.hasNext()) {
                Frame nextFrame = (Frame) i.next();
                nextFrame.removeFrameListener(_visibleFrameChanged);
            }
        }
        if (null != _currentConnectors) {
            Iterator i = _currentConnectors.iterator();
            while (i.hasNext()) {
                Frame nextFrame = (Frame) i.next();
                nextFrame.removeFrameListener(_visibleFrameChanged);
            }
        }
    }

    public void dispose() {
        super.dispose();
        if (_flowchartPanel != null) {
            _flowchartPanel.dispose();
        }
        detachListeners();
    }

    public Collection getConnectorClses() {
        ArrayList returnValue = new ArrayList();
        Iterator i = (_state.getConnectorClses()).iterator();
        while (i.hasNext()) {
            Cls nextConnectorCls = (Cls) i.next();
            if (nextConnectorCls.isVisible()) {
                returnValue.add(nextConnectorCls);
            }
        }
        return returnValue;
    }

    public Collection getConnectors() {
        return _currentConnectors;
    }

    public DiagramsPanel getDiagramsPanel() {
        return _mainDiagramArea;
    }

    public int getDividerLocation() {
        return _drawingAreaDelegate.getDividerLocation();
    }

    public int getLogicalDrawingAreaHeight() {
        return _drawingAreaDelegate.getLogicalDrawingAreaHeight();
    }

    public int getLogicalDrawingAreaWidth() {
        return _drawingAreaDelegate.getLogicalDrawingAreaWidth();
    }

    public AnimationContext getMainDrawingArea() {
        return _mainDiagramArea.getMainDrawingArea();
    }

    public MainDrawingPanel getMainDrawingPanel() {
        return _mainDiagramArea.getMainDrawingPanel();
    }

    public int getMinimumPossibleLogicalDrawingAreaHeight() {
        return _drawingAreaDelegate.getMinimumPossibleLogicalDrawingAreaHeight();
    }

    public int getMinimumPossibleLogicalDrawingAreaWidth() {
        return _drawingAreaDelegate.getMinimumPossibleLogicalDrawingAreaWidth();
    }

    public Instance getNetworkInstance() {
        return _actualNetworkInstance;
    }

    public Collection getNodeClses() {
        ArrayList returnValue = new ArrayList();
        Iterator i = (_state.getNodeClses()).iterator();
        while (i.hasNext()) {
            Cls nextNodeCls = (Cls) i.next();
            if (nextNodeCls.isVisible()) {
                returnValue.add(nextNodeCls);
            }
        }
        return returnValue;
    }

    public Collection getNodes() {
        return _currentNodes;
    }

    public DiagramWidgetState getState() {
        return _state;
    }

    public VisibilityChecker getVisibilityChecker(String name) {
        return _aggregatingVisibilityChecker.getVisibilityChecker(name);
    }

    public Collection getVisibleConnectorClses() {
        ArrayList returnValue = new ArrayList();
        Iterator i = (_state.getConnectorClses()).iterator();
        while (i.hasNext()) {
            Cls nextConnectorCls = (Cls) i.next();
            if (isConnectorClsVisible(nextConnectorCls)) {
                returnValue.add(nextConnectorCls);
            }
        }
        return returnValue;
    }

    public Collection getVisibleNodeClses() {
        ArrayList returnValue = new ArrayList();
        Iterator i = (_state.getNodeClses()).iterator();
        while (i.hasNext()) {
            Cls nextNodeCls = (Cls) i.next();
            if (isNodeClsVisible(nextNodeCls)) {
                returnValue.add(nextNodeCls);
            }
        }
        return returnValue;
    }

    public void initialize() {
        _connectorsSlotChanged = new ConnectorSlotChanged();
        _visibleFrameChanged = new VisibleFrameChanged();
        _internalFrames = new LinkedList();
        _connectorsSlot = getKnowledgeBase().getSlot(CONNECTORS_SLOT);
        _state = new DiagramWidgetState(this, getPropertyList());
        _drawingAreaDelegate = new DrawingAreaDelegate(this);
        _aggregatingVisibilityChecker = new AggregatingVisibilityChecker();
        buildGUI();
    }

    public boolean isConnectorClsVisible(Cls connectorCls) {
        return _aggregatingVisibilityChecker.isConnectorClsVisible(connectorCls);
    }

    public boolean isConnectorVisible(Instance connectorInstance) {
        return _aggregatingVisibilityChecker.isConnectorVisible(connectorInstance);
    }

    public boolean isNodeClsVisible(Cls nodeCls) {
        return _aggregatingVisibilityChecker.isNodeClsVisible(nodeCls);
    }

    public boolean isNodeVisible(Instance nodeInstance) {
        return _aggregatingVisibilityChecker.isNodeVisible(nodeInstance);
    }

    public static boolean isSuitable(Cls cls, Slot slot, Facet facet) {
        return DiagramConfigurationChecks.isSuitable(cls, slot, facet);
    }

    public static void main(String[] args) {
        edu.stanford.smi.protege.Application.main(args);
    }

    public void moveInternalFrameToFront(InternalFrame frameToPromote) {
        if (_internalFrames.contains(frameToPromote)) {
            addInternalFrame(frameToPromote);
        }
        return;
    }

    private void rebuildFromScratch() {
        removeAll();
        Iterator i = _internalFrames.iterator();
        while (i.hasNext()) {
            JComponent nextComponent = (JComponent) i.next();
            add(nextComponent);
        }
        add(_labeledComponent);
        repaint();
        return;
    }

    public void rebuildVisualDiagram() {
        resetAggregatingVisibilityChecker();
        createNetworkDescription();
        if (_flowchartPanel != null) {
            _flowchartPanel.rebuild();
        }
    }

    public void removeInternalFrame(InternalFrame oldFrame) {
        if (_internalFrames.contains(oldFrame)) {
            _internalFrames.remove(oldFrame);
            oldFrame.setCurrentlyBeingDisplayed(false);
            rebuildFromScratch();
        }
        return;
    }

    public void removeVisibilityChecker(String name, VisibilityChecker oldVisibilityChecker) {
        _aggregatingVisibilityChecker.removeVisibilityChecker(name);
    }

    private void resetAggregatingVisibilityChecker() {
        _aggregatingVisibilityChecker.reset();
        _aggregatingVisibilityChecker.addVisibilityChecker(
            CONFIGURATION_BASED_VISIBILITY_CHECKER,
            _state.getDefaultVisibilityChecker());
        _aggregatingVisibilityChecker.addVisibilityChecker(PROJECT_VISIBILITY_CHECKER, new ProjectLevelVisibilityChecker());
    }

    public void setDividerLocation(int dividerLocation) {
        _drawingAreaDelegate.setDividerLocation(dividerLocation);
        return;
    }

    public void setFlowchartPanel(OptionsFlowchartPanel ofp) {
        _flowchartPanel = ofp;
    }

    public void setLogicalDrawingAreaHeight(int mainDrawingAreaHeight) {
        _drawingAreaDelegate.setLogicalDrawingAreaHeight(mainDrawingAreaHeight);
        return;
    }

    public void setLogicalDrawingAreaWidth(int mainDrawingAreaWidth) {
        _drawingAreaDelegate.setLogicalDrawingAreaWidth(mainDrawingAreaWidth);
        return;
    }

    public void setValues(java.util.Collection values) {
        rebuildVisualDiagram();
    }
}
