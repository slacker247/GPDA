/*
 * The contents of this file are subject to the Mozilla Public License
 * Version 1.1 (the "License");  you may not use this file except in compliance
 * with the License.  You may obtain a copy of the License at
 * http://www.mozilla.org/MPL/
 *
 * Software distributed under the License is distributed on an "AS IS" basis,
 * WITHOUT WARRANTY OF ANY KIND, either express or implied. See the License for
 * the specific language governing rights and limitations under the License.
 *
 * The Original Code is Protege-2000.
 *
 * The Initial Developer of the Original Code is Stanford University. Portions
 * created by Stanford University are Copyright (C) 2001.  All Rights Reserved.
 *
 * Protege-2000 was developed by Stanford Medical Informatics
 * (http://www.smi.stanford.edu) at the Stanford University School of Medicine
 * with support from the National Library of Medicine, the National Science
 * Foundation, and the Defense Advanced Research Projects Agency.  Current
 * information about Protege can be obtained at http://protege.stanford.edu
 *
 * Contributor(s):
 */

package edu.stanford.smi.protegex.widget.diagram;

import edu.stanford.smi.protegex.layout.*;

import javax.swing.*;
import java.awt.*;
import java.awt.event.*;

/**
 *  Description of the class
 *
 * @author    William Grosso <grosso@smi.stanford.edu>
 */
public class MainThumbnailPanel extends JPanel {
    private Image _offscreenImage;
    private Rectangle _animationContextBounds;
    private Rectangle _offscreenImageBounds;
    private Rectangle _ourBounds;
    private AnimationContext _widgetAnimationContext;
    private MainDrawingPanel _widgetDrawingPanel;
    private Color _visibleOverlayColor;
    private Color _backgroundColor;

    private class Navigator extends MouseAdapter {
        private Point _scratch = new Point();

        public void mouseClicked(MouseEvent e) {
            if (2 == e.getClickCount()) {
                float xRatio = ((float) (e.getX() - _ourBounds.x)) / ((float) (_ourBounds.width));
                float yRatio = ((float) (e.getY() - _ourBounds.y)) / ((float) (_ourBounds.height));
                _scratch.x = _offscreenImageBounds.x + ((int) (xRatio * _offscreenImageBounds.width));
                _scratch.y = _offscreenImageBounds.y + ((int) (yRatio * _offscreenImageBounds.height));
                _widgetDrawingPanel.displayPoint(_scratch);
            }
        }
    }

    public MainThumbnailPanel(DiagramWidget widget, Color backgroundColor) {
        _widgetAnimationContext = widget.getMainDrawingArea();
        _widgetDrawingPanel = widget.getMainDrawingPanel();
        _backgroundColor = backgroundColor;
        _animationContextBounds = new Rectangle();
        _offscreenImageBounds = new Rectangle();
        _ourBounds = new Rectangle();
        addMouseListener(new Navigator());
        _visibleOverlayColor = new Color(0, 0, 0, .15f);
    }

    private void buildAndResizeImage() {
        _widgetAnimationContext.getCoordinateSystem(_animationContextBounds);
        if ((null == _offscreenImage) || (!_animationContextBounds.equals(_offscreenImageBounds))) {
            _offscreenImage = createImage(_animationContextBounds.width, _animationContextBounds.height);
            _offscreenImageBounds.x = _animationContextBounds.x;
            _offscreenImageBounds.y = _animationContextBounds.y;
            _offscreenImageBounds.height = _animationContextBounds.height;
            _offscreenImageBounds.width = _animationContextBounds.width;
        }
        return;
    }

    private void drawBackground(Graphics g) {
        g.setColor(_backgroundColor);
        g.fillRect(_offscreenImageBounds.x, _offscreenImageBounds.y, _offscreenImageBounds.width, _offscreenImageBounds.height);
    }

    private void drawBoundingBox(Graphics g) {
        g.setColor(_visibleOverlayColor);
        Rectangle visibleRect = _widgetDrawingPanel.getVisibleArea();
        g.fillRect(visibleRect.x, visibleRect.y, visibleRect.width, visibleRect.height);
    }

    private void drawMainImage(Graphics g) {
        _widgetAnimationContext.takeSnapshot(g);
    }

    private void drawOffscreenImage() {
        Graphics imageGraphics = _offscreenImage.getGraphics();
        drawBackground(imageGraphics);
        drawMainImage(imageGraphics);
        drawBoundingBox(imageGraphics);
        imageGraphics.dispose();
    }

    public void paint(Graphics g) {
        super.paint(g);
        buildAndResizeImage();
        drawOffscreenImage();
        getBounds(_ourBounds);
        g.drawImage(
            _offscreenImage,
            _ourBounds.x,
            _ourBounds.y,
            _ourBounds.x + _ourBounds.width,
            _ourBounds.y + _ourBounds.height,
            _offscreenImageBounds.x,
            _offscreenImageBounds.y,
            _offscreenImageBounds.x + _offscreenImageBounds.width,
            _offscreenImageBounds.y + _offscreenImageBounds.height,
            null);
    }
}
