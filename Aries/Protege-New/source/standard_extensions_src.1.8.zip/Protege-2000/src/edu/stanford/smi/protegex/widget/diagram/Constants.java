/*
 * The contents of this file are subject to the Mozilla Public License
 * Version 1.1 (the "License");  you may not use this file except in compliance
 * with the License.  You may obtain a copy of the License at
 * http://www.mozilla.org/MPL/
 *
 * Software distributed under the License is distributed on an "AS IS" basis,
 * WITHOUT WARRANTY OF ANY KIND, either express or implied. See the License for
 * the specific language governing rights and limitations under the License.
 *
 * The Original Code is Protege-2000.
 *
 * The Initial Developer of the Original Code is Stanford University. Portions
 * created by Stanford University are Copyright (C) 2001.  All Rights Reserved.
 *
 * Protege-2000 was developed by Stanford Medical Informatics
 * (http://www.smi.stanford.edu) at the Stanford University School of Medicine
 * with support from the National Library of Medicine, the National Science
 * Foundation, and the Defense Advanced Research Projects Agency.  Current
 * information about Protege can be obtained at http://protege.stanford.edu
 *
 * Contributor(s):
 */

package edu.stanford.smi.protegex.widget.diagram;



/**
 *  Description of the Interface
 *
 * @author    William Grosso <grosso@smi.stanford.edu>
 */
public interface Constants {
    // Behavioral Constants
    public final static int WIRE_CONTROLPOINT_PRECISION = 6;
    public final static int WIRE_MINIMUM_SIZE = 10;
    public final static int IMAGE_CONTROLPOINT_PRECISION = 6;
    public final static int IMAGE_MINIMUM_SIZE = 10;

    public static int DEFAULT_NODE_HEIGHT = 60;
    public static int DEFAULT_NODE_WIDTH = 60;
    // ontological definitions
    public final static String FIRST_OBJECT_SLOT_NAME = "first_object";
    public final static String SECOND_OBJECT_SLOT_NAME = "second_object";
    public final static String FIRST_OBJECT_SLOT_POINTER_NAME = "first_object_slot_pointer";
    public final static String SECOND_OBJECT_SLOT_POINTER_NAME = "second_object_slot_pointer";

    public final static String CONNECTOR_CLASS = "Connector";
    public final static String CONNECTORS_SLOT = "connectors";
    public final static String LAYOUT_INFORMATION_SLOT = "layout_information";
    public final static String UPPER_LEFT_CORNER_SLOT = "upper_left_corner";
    public final static String LOWER_RIGHT_CORNER_SLOT = "lower_right_corner";
    public final static String LOCATION_SLOT = "location";
    public final static String OBJECT_SLOT = "object";
    public final static String OBJECT_LOCATION_CLASS = "ObjectLocation";
    public final static String RECTANGLE_CLASS = "Rectangle";
    public final static String POINT_CLASS = "Point";
    public final static String POINT_X_SLOT = "x";
    public final static String POINT_Y_SLOT = "y";

    public final static String NETWORK_CLASS = "Network";
    public final static String NETWORK_METACLASS = "Network_Metaclass";
    public final static String NODE_SLOT = "node_slot";

    public final static String MAIN_SIDE_RECTANGLE_HEIGHT = "main_panel_height";
    public final static String MAIN_SIDE_RECTANGLE_WIDTH = "main_panel_width";
    public final static String LAST_DIVIDER_LOCATION = "last_divider_location";

    public final static int DEFAULT_LOWER_BOUND_ON_DIAGRAM_LOGICAL_WIDTH = 600;
    public final static int DEFAULT_LOWER_BOUND_ON_DIAGRAM_LOGICAL_HEIGHT = 600;
    public final static int DEFAULT_LAST_DIVIDER_LOCATION = 600;

    public final static String CONFIGURATION_BASED_VISIBILITY_CHECKER = ":CONFIGURATION:BASED:VISIBILITY:CHECKER";
    public final static String PROJECT_VISIBILITY_CHECKER = ":PROJECT:VISIBILITY:CHECKER";
}
