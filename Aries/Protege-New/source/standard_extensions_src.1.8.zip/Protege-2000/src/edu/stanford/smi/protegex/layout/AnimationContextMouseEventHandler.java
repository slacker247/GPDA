/*
 * The contents of this file are subject to the Mozilla Public License
 * Version 1.1 (the "License");  you may not use this file except in compliance
 * with the License.  You may obtain a copy of the License at
 * http://www.mozilla.org/MPL/
 *
 * Software distributed under the License is distributed on an "AS IS" basis,
 * WITHOUT WARRANTY OF ANY KIND, either express or implied. See the License for
 * the specific language governing rights and limitations under the License.
 *
 * The Original Code is Protege-2000.
 *
 * The Initial Developer of the Original Code is Stanford University. Portions
 * created by Stanford University are Copyright (C) 2001.  All Rights Reserved.
 *
 * Protege-2000 was developed by Stanford Medical Informatics
 * (http://www.smi.stanford.edu) at the Stanford University School of Medicine
 * with support from the National Library of Medicine, the National Science
 * Foundation, and the Defense Advanced Research Projects Agency.  Current
 * information about Protege can be obtained at http://protege.stanford.edu
 *
 * Contributor(s):
 */

package edu.stanford.smi.protegex.layout;

import java.awt.*;
import java.awt.event.*;
import java.util.*;

/**
 *  Description of the Class
 *
 * @author    William Grosso <grosso@smi.stanford.edu>
 */
public class AnimationContextMouseEventHandler {
    protected AnimationContext _animationContext;
    protected boolean _visibleToEvents;
    protected boolean _firstTime = true;  // first time for this drag
    protected boolean _noneDragged = false;
    protected Actor _firstRecipient = null;
    protected EventOwnerTest _eventOwnerTest;
    protected DragOwnerTest _dragOwnerTest;
    protected Point _lastDragPoint;

    protected class EventOwnerTest implements ActorTest {
        private MouseEvent _event;

        public boolean performTest(Actor target) {
            return ((ActorEventHandler)target).wantEvent(_event);
        }

        public void setEvent(MouseEvent event) {
            _event = event;
        }
    }

    protected class DragOwnerTest implements ActorTest {
        private MouseEvent _event;

        public boolean performTest(Actor target) {
            return ((ActorEventHandler)target).wantEvent(_event);
        }

        public void setEvent(MouseEvent event) {
            _event = event;
        }
    }

    public AnimationContextMouseEventHandler() {
        this(null);
    }

    public AnimationContextMouseEventHandler(AnimationContext animationContext) {
        _animationContext = animationContext;
        _eventOwnerTest = new EventOwnerTest();
        _dragOwnerTest = new DragOwnerTest();
    }

    private boolean canPerformIncrementalDrag(int deltaX, int deltaY) {
        Iterator i = (_animationContext.getSelectedActors()).iterator();
        while (i.hasNext()) {
            Actor nextActor = (Actor) i.next();
            if (!nextActor.canPerformIncrementalDrag(deltaX, deltaY)) {
                return false;
            }
        }
        return true;
    }

    protected void dragEveryone(MouseEvent e) {
        if (_animationContext.isSingleSelection()) {
            _firstRecipient.processDrag(e);
            return;
        }
        int currentX = e.getX();
        int currentY = e.getY();
        int deltaX = currentX - _lastDragPoint.x;
        int deltaY = currentY - _lastDragPoint.y;
        _lastDragPoint.x = currentX;
        _lastDragPoint.y = currentY;
        if (canPerformIncrementalDrag(deltaX, deltaY)) {
            performIncrementalDrag(deltaX, deltaY);
        }
        return;
    }

    protected Actor findDragOwner(MouseEvent e) {
        _dragOwnerTest.setEvent(e);
        ZOrder zOrder = _animationContext.getZOrder();
        Actor returnValue = zOrder.performSingleTest(ZOrder.TOPDOWN, _dragOwnerTest);
        return returnValue;
    }

    protected Actor findEventOwner(MouseEvent e) {
        _eventOwnerTest.setEvent(e);
        ZOrder zOrder = _animationContext.getZOrder();
        return zOrder.performSingleTest(ZOrder.TOPDOWN, _eventOwnerTest);
    }

    public AnimationContext getAnimationContext() {
        return _animationContext;
    }

    public boolean getVisibleToEvents() {
        return _visibleToEvents;
    }

    protected void mouseClicked(MouseEvent e) {
        ActorEventHandler currentlySelectedActor = _animationContext.getLeadSelection();
        if (null != currentlySelectedActor) {
            if (!currentlySelectedActor.wantEvent(e)) {
                searchAndProcessMouseClick(e);
            } else {
                currentlySelectedActor.processClick(e);
            }
        } else {
            searchAndProcessMouseClick(e);
        }
    }

    // from here on, need changes to handle multiple selections
    protected void mouseDragged(MouseEvent e) {
        if (_firstTime) {
            _firstRecipient = findDragOwner(e);
            if (_firstRecipient == null) {
                _noneDragged = true;
            } else {
                _lastDragPoint = e.getPoint();
            }
            _firstTime = false;
            return;
        }
        if (_noneDragged) {
            return;
        }
        dragEveryone(e);
    }

    protected void mousePressed(MouseEvent e) {
        _firstTime = true;
        _noneDragged = false;
        _firstRecipient = null;

        ActorEventHandler currentlySelectedActor = _animationContext.getLeadSelection();
        if (null != currentlySelectedActor) {
            currentlySelectedActor.processMousePress(e);
            if (!currentlySelectedActor.wantEvent(e)) {
                searchAndProcessMousePress(e);
            }
        } else {
            searchAndProcessMousePress(e);
        }
    }

    protected void mouseReleased(MouseEvent e) {
        _firstTime = true;
        _noneDragged = false;
        _firstRecipient = null;
        Collection actors = _animationContext.getSelectedActors();
        if ((null != actors) && (0 != actors.size())) {
            Iterator i = actors.iterator();
            while (i.hasNext()) {
                Actor nextActor = (Actor) i.next();
                nextActor.processMouseRelease(e);
            }
        } else {
            searchAndProcessMouseRelease(e);
        }
    }

    private void performIncrementalDrag(int deltaX, int deltaY) {
        Iterator i = (_animationContext.getSelectedActors()).iterator();
        while (i.hasNext()) {
            Actor nextActor = (Actor) i.next();
            nextActor.processIncrementalDrag(deltaX, deltaY);
        }
        return;
    }

    public void processMouseEvent(MouseEvent e) {
        int id = e.getID();
        if (id == MouseEvent.MOUSE_CLICKED) {
            mouseClicked(e);
            return;
        }
        if (id == MouseEvent.MOUSE_PRESSED) {
            mousePressed(e);
            return;
        }
        if (id == MouseEvent.MOUSE_RELEASED) {
            mouseReleased(e);
        }
    }

    public void processMouseMotionEvent(MouseEvent e) {
        if (e.getID() == MouseEvent.MOUSE_DRAGGED) {
            mouseDragged(e);
        }
    }

    protected void searchAndProcessMouseClick(MouseEvent e) {
        Actor recipient = findEventOwner(e);
        if (null != recipient) {
            recipient.processClick(e);
        } else {
            _animationContext.setSelectedActor(null);
        }
        return;
    }

    protected void searchAndProcessMousePress(MouseEvent e) {
        Actor recipient = findEventOwner(e);
        if (null != recipient) {
            recipient.processMousePress(e);
        }
        return;
    }

    protected void searchAndProcessMouseRelease(MouseEvent e) {
        Actor recipient = findEventOwner(e);
        if (null != recipient) {
            recipient.processMouseRelease(e);
        }
        return;
    }

    public void setAnimationContext(AnimationContext animationContext) {
        _animationContext = animationContext;
    }

    public void setVisibleToEvents(boolean visibleToEvents) {
        _visibleToEvents = visibleToEvents;
    }

    public boolean wantEvent(MouseEvent e) {
        Rectangle coordinateSystem = _animationContext.getCoordinateSystem();
        if (_visibleToEvents) {
            if (coordinateSystem.contains(e.getPoint())) {
                return true;
            }
        }
        return false;
    }
}
