/*
 * The contents of this file are subject to the Mozilla Public License
 * Version 1.1 (the "License");  you may not use this file except in compliance
 * with the License.  You may obtain a copy of the License at
 * http://www.mozilla.org/MPL/
 *
 * Software distributed under the License is distributed on an "AS IS" basis,
 * WITHOUT WARRANTY OF ANY KIND, either express or implied. See the License for
 * the specific language governing rights and limitations under the License.
 *
 * The Original Code is Protege-2000.
 *
 * The Initial Developer of the Original Code is Stanford University. Portions
 * created by Stanford University are Copyright (C) 2001.  All Rights Reserved.
 *
 * Protege-2000 was developed by Stanford Medical Informatics
 * (http://www.smi.stanford.edu) at the Stanford University School of Medicine
 * with support from the National Library of Medicine, the National Science
 * Foundation, and the Defense Advanced Research Projects Agency.  Current
 * information about Protege can be obtained at http://protege.stanford.edu
 *
 * Contributor(s):
 */

package edu.stanford.smi.protegex.layout;

import java.awt.*;

/**
 *  Icon actor
 *
 * @author    William Grosso <grosso@smi.stanford.edu>
 */
public class StandardGlyphActor extends AbstractActor {
    protected Glyph _glyph;
    protected ActorAttachment _startingAttachment;
    // unused, should be like ImageActor
    protected ActorAttachment _endingAttachment;

    public StandardGlyphActor(
        Glyph glyph,
        AnimationContext animationContext,
        ActorLocation location,
        ActorEventHandler eventHandler,
        ActorMovementHandler movementHandler,
        ActorControlPointHandler controlPointHandler) {
        super(animationContext, location, eventHandler, movementHandler, controlPointHandler);
        _glyph = glyph;
    }

    public Object copy() {
        Glyph copyOfGlyph = (Glyph) _glyph.copy();
        ActorLocation copyOfLocation = (ActorLocation) _location.copy();
        ActorEventHandler copyOfEventHandler = (ActorEventHandler) _eventHandler.copy();
        ActorMovementHandler copyOfMovementHandler = (ActorMovementHandler) _movementHandler.copy();
        ActorControlPointHandler copyOfControlPointHandler = (ActorControlPointHandler) _controlPointHandler.copy();
        StandardGlyphActor returnValue =
            new StandardGlyphActor(
                copyOfGlyph,
                _animationContext,
                copyOfLocation,
                copyOfEventHandler,
                copyOfMovementHandler,
                copyOfControlPointHandler);
        returnValue.setStartingAttachment(_startingAttachment);
        returnValue.setEndingAttachment(_endingAttachment);
        return returnValue;
    }

    public Rectangle draw(Graphics g) {
        _location.moveInsideCoordinateSystem();
        _location.getBounds(_lastDrawingLocation);
        if ( _eventHandler.getIsSelected()) {
            _glyph.displaySelectedImage(_location, g);
        } else {
            _glyph.displayImage(_location, g);
        }
        return _lastDrawingLocation;
    }

    public Point getBoundaryPointForLine(Line line) {
        return _glyph.getBoundaryPointForLine(line);
    }

    public ActorAttachment getEndingAttachment() {
        return _endingAttachment;
    }

    public ActorAttachment getStartingAttachment() {
        return _startingAttachment;
    }

    public boolean isWire() {
        return false;
    }

    public void setEndingAttachment(ActorAttachment attachment) {
        _endingAttachment = attachment;
    }

    public void setStartingAttachment(ActorAttachment attachment) {
        _startingAttachment = attachment;
    }

    public void setTitle(String title) {
        _glyph.setTitle(title);
    }

    public void tick(int currentTime) {

        _movementHandler.tick(currentTime);

    }
}
