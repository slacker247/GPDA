/*
 * The contents of this file are subject to the Mozilla Public License
 * Version 1.1 (the "License");  you may not use this file except in compliance
 * with the License.  You may obtain a copy of the License at
 * http://www.mozilla.org/MPL/
 *
 * Software distributed under the License is distributed on an "AS IS" basis,
 * WITHOUT WARRANTY OF ANY KIND, either express or implied. See the License for
 * the specific language governing rights and limitations under the License.
 *
 * The Original Code is Protege-2000.
 *
 * The Initial Developer of the Original Code is Stanford University. Portions
 * created by Stanford University are Copyright (C) 2001.  All Rights Reserved.
 *
 * Protege-2000 was developed by Stanford Medical Informatics
 * (http://www.smi.stanford.edu) at the Stanford University School of Medicine
 * with support from the National Library of Medicine, the National Science
 * Foundation, and the Defense Advanced Research Projects Agency.  Current
 * information about Protege can be obtained at http://protege.stanford.edu
 *
 * Contributor(s):
 */

package edu.stanford.smi.protegex.widget.diagram;

import edu.stanford.smi.protegex.layout.*;

import java.awt.event.*;
import javax.swing.*;
import edu.stanford.smi.protege.model.*;
import java.util.*;
import edu.stanford.smi.protege.ui.*;

/**
 *  Description of the class
 *
 * @author    William Grosso <grosso@smi.stanford.edu>
 */
public class BuildWireButtonListener implements ActionListener {
    private MainWirebuilderPanel _mainWirebuilderPanel;
    private DiagramWidget _widget;
    private DiagramsPanel _panel;
    private Instance _firstNode;
    private Cls _firstNodeType;
    private Instance _secondNode;
    private Cls _secondNodeType;
    private JButton _owner;

    private ArrayList _validConnectorsBasedOnFirstNode;
    private ArrayList _validConnectorsBasedOnSecondNode;
    private ArrayList _validConnectors;
    private Slot _firstObjectSlot;
    private Slot _secondObjectSlot;
    private KnowledgeBase _kb;

    public BuildWireButtonListener(
        DiagramsPanel panel,
        MainWirebuilderPanel mainWirebuilderPanel,
        DiagramWidget widget,
        JButton owner) {
        _mainWirebuilderPanel = mainWirebuilderPanel;
        _widget = widget;
        _owner = owner;
        _validConnectorsBasedOnFirstNode = new ArrayList();
        _validConnectorsBasedOnSecondNode = new ArrayList();
        _validConnectors = new ArrayList();
        _kb = _widget.getKnowledgeBase();
        _panel = panel;
        _firstObjectSlot = _kb.getSlot(Constants.FIRST_OBJECT_SLOT_NAME);
        _secondObjectSlot = _kb.getSlot(Constants.SECOND_OBJECT_SLOT_NAME);
    }

    public void actionPerformed(ActionEvent e) {
        Cls connectorCls = DisplayUtilities.pickConcreteCls(_widget, _validConnectors, "Pick a Connector Type");
        if (null != connectorCls) {
            Instance newInstance = _kb.createInstance(null, connectorCls);
            newInstance.setOwnSlotValue(_firstObjectSlot, _firstNode);
            newInstance.setOwnSlotValue(_secondObjectSlot, _secondNode);
            DiagramUtilities.bindAlongConnection(newInstance);
            addConnector(newInstance);
        }
        return;
    }

    private void addConnector(Instance instance) {
        Collection currentConnectors = _widget.getConnectors();
        if (currentConnectors.contains(instance)) {
            return;
        }
        WireState wireState = _widget.getState().getStateForConnector(instance);
        StandardWireActor associatedActor = _panel.buildActorForConnector(instance, wireState);
        DiagramUtilities.addNewConnectorToNetwork(_widget.getNetworkInstance(), associatedActor);
        _panel.placeConnectorOnScreen(instance, associatedActor);
        _panel.computeAttachmentsForConnector(instance, associatedActor);
        return;
    }

    private void buildAllowedList(ArrayList storage, Slot slot, Cls nodeCls) {
        storage.clear();
        Collection possibleConnectors = _widget.getConnectorClses();
        Iterator i = possibleConnectors.iterator();
        while (i.hasNext()) {
            Cls connectorCls = (Cls) i.next();
            if (goodValueType(nodeCls, slot, connectorCls)) {
                storage.add(connectorCls);
            }
        }
        intersectLists();
    }

    private boolean goodValueType(Cls valueCls, Slot slot, Cls frameType) {
        Collection allowedClses = frameType.getTemplateSlotAllowedClses(slot);
        if ((null == allowedClses) || (0 == allowedClses.size())) {
            return false;
        }
        Iterator i = allowedClses.iterator();
        while (i.hasNext()) {
            Cls allowedCls = (Cls) i.next();
            if (valueCls.hasSuperclass(allowedCls)) {
                return true;
            }
            if (valueCls.equals(allowedCls)) {
                return true;
            }
        }
        return false;
    }

    private void intersectLists() {
        _validConnectors.clear();
        if ((null == _validConnectorsBasedOnFirstNode) || (null == _validConnectorsBasedOnSecondNode)) {
            return;
        }
        Iterator i = _validConnectorsBasedOnFirstNode.iterator();
        while (i.hasNext()) {
            Object nextObject = i.next();
            if (_validConnectorsBasedOnSecondNode.contains(nextObject)) {
                _validConnectors.add(nextObject);
            }
        }
        return;
    }

    private void setActivation() {
        if ((null != _firstNode) && (null != _secondNode) && (0 != _validConnectors.size())) {
            _owner.setEnabled(true);
        } else {
            _owner.setEnabled(false);
        }
    }

    public void setDiagramsPanel(DiagramsPanel panel) {
        _panel = panel;
    }

    public void setFirstNode(Instance firstNode) {
        _firstNode = firstNode;
        if (null != _firstNode) {
            Cls newType = _firstNode.getDirectType();
            if ((newType != null) && (newType != _firstNodeType)) {
                buildAllowedList(_validConnectorsBasedOnFirstNode, _firstObjectSlot, newType);
            }
            _firstNodeType = newType;
        }
        setActivation();
    }

    public void setSecondNode(Instance secondNode) {
        _secondNode = secondNode;
        if (null != _secondNode) {
            Cls newType = _secondNode.getDirectType();
            if ((null != newType) && (newType != _secondNodeType)) {
                buildAllowedList(_validConnectorsBasedOnSecondNode, _secondObjectSlot, newType);
            }
            _secondNodeType = newType;
        }
        setActivation();
    }
}
