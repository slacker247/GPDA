/*
 * The contents of this file are subject to the Mozilla Public License
 * Version 1.1 (the "License");  you may not use this file except in compliance
 * with the License.  You may obtain a copy of the License at
 * http://www.mozilla.org/MPL/
 *
 * Software distributed under the License is distributed on an "AS IS" basis,
 * WITHOUT WARRANTY OF ANY KIND, either express or implied. See the License for
 * the specific language governing rights and limitations under the License.
 *
 * The Original Code is Protege-2000.
 *
 * The Initial Developer of the Original Code is Stanford University. Portions
 * created by Stanford University are Copyright (C) 2001.  All Rights Reserved.
 *
 * Protege-2000 was developed by Stanford Medical Informatics
 * (http://www.smi.stanford.edu) at the Stanford University School of Medicine
 * with support from the National Library of Medicine, the National Science
 * Foundation, and the Defense Advanced Research Projects Agency.  Current
 * information about Protege can be obtained at http://protege.stanford.edu
 *
 * Contributor(s):
 */

package edu.stanford.smi.protegex.widget.diagram;

import java.awt.Point;
import java.util.*;

/**
 *  NOTE: The nodes are 1-indexed. 0 is the dummy root! Description of the class
 *
 * @author    William Grosso <grosso@smi.stanford.edu>
 */
public class FlowchartGraph {

    private int _realNodeCount, _dummyNodeCount;
    private LayoutNode[] _nodes;

    // Node 0 is always a dummy root, which points to the real root(s).
    // Nodes 1 through _realNodeCount are real nodes.
    // Nodes beyond _realNodeCount are dummy nodes.
    // There should always be _realNodeCount + _dummyNodeCount nodes.
    public FlowchartGraph(int numNodes) {
        _realNodeCount = numNodes;
        _dummyNodeCount = 1;
        _nodes = new LayoutNode[numNodes + 1];
        for (int i = 1; i <= numNodes; i++) {
            _nodes[i] = new LayoutNode(numNodes + 1);
        }
        _nodes[0] = new LayoutNode(numNodes + 1, true);
        _nodes[0].setDepth(LayoutNode.ROOT_DEPTH);
    }

    private int addDummyNodes() {
        _dummyNodeCount = countDummyNodesNeeded() + 1;
        reallocateNodes();
        populateDummyNodes();
        return 0;
    }

    private int addDummyNodes(int from, int to, int where) {
        int diff = _nodes[to].getDepth() - _nodes[from].getDepth() - 1;
        if (diff < 1) {
            System.err.println("Should not be adding dummy.");
        }
        _nodes[from].addEdgeTo(where);
        for (int i = 0; i < diff - 1; i++) {
            LayoutNode current = _nodes[where + i];
            current.setDepth(_nodes[from].getDepth() + i + 1);
            current.addEdgeTo(where + i + 1);
        }
        LayoutNode last = _nodes[where + diff - 1];
        last.setDepth(_nodes[to].getDepth() - 1);
        last.addEdgeTo(to);
        return diff;
    }

    public void addEdge(int from, int to) {
        if (from > 0) {
            _nodes[from].addEdgeTo(to);
        }
    }

    private void addLayer(int layer, AcyclicPath path) {
        int numNodes = getNumRealNodes();
        for (int i = 1; i <= numNodes; i++) {
            int current = path.getTail();
            if (_nodes[current].hasEdgeTo(i)) {
                if (newLayerAdded(layer, path, _nodes[i], i)) {
                    _nodes[i].setDepth(layer);
                    addLayer(layer + 1, path);
                    path.removeEdge();
                }
            }
        }
    }

    public void addRoot(int root) {
        _nodes[0].addEdgeTo(root);
    }

    private void assignDepth() {
        addLayer(1, new AcyclicPath(getNumAllNodes()));
    }

    private void assignLocation() {
        int[] nextUnusedLocation = new int[getDepth() + 1];
        int numNodes = getNumAllNodes();
        for (int i = 0; i < numNodes; i++) {
            _nodes[i].setLocation(nextUnusedLocation[_nodes[i].getDepth()]++);
        }
    }

    private void baryByCol(int[][] matrix) {
        int depth = getDepth();
        BaryElem[][] columns = new BaryElem[depth + 1][];
        for (int i = 1; i <= depth; i++) {
            columns[i] = new BaryElem[matrix[i].length];
            for (int j = 0; j < columns[i].length; j++) {
                columns[i][j] = new BaryElem(matrix[i][j], BaryElem.UP, this);
            }
            java.util.Arrays.sort(columns[i]);
            for (int j = 0; j < columns[i].length; j++) {
                matrix[i][j] = columns[i][j].getNode();
                _nodes[matrix[i][j]].setLocation(j);
            }
        }
    }

    private void baryByRow(int[][] matrix) {
        int depth = getDepth();
        BaryElem[][] rows = new BaryElem[depth + 1][];
        for (int i = depth - 1; i >= 0; i--) {
            rows[i] = new BaryElem[matrix[i].length];
            for (int j = 0; j < rows[i].length; j++) {
                rows[i][j] = new BaryElem(matrix[i][j], BaryElem.DOWN, this);
            }
            java.util.Arrays.sort(rows[i]);
            for (int j = 0; j < rows[i].length; j++) {
                matrix[i][j] = rows[i][j].getNode();
                _nodes[matrix[i][j]].setLocation(j);
            }
        }
        for (int i = depth - 1; i >= 0; i--) {
            java.util.Arrays.sort(rows[i], new BarySwap());
            for (int j = 0; j < rows[i].length; j++) {
                matrix[i][j] = rows[i][j].getNode();
                _nodes[matrix[i][j]].setLocation(j);
            }
        }
    }

    private void baryCenter(int numLoops) {
        int[][] realization;
        int depth = getDepth();
        realization = new int[depth + 1][];
        for (int i = 0; i <= depth; i++) {
            realization[i] = getRow(i);
            //      java.util.Arrays.sort(realization[i]);
        }
        for (int i = 0; i < numLoops; i++) {
            baryByRow(realization);
            baryByCol(realization);
        }
    }

    private void convertAllLocationsToIntegers() {
        int depth = getDepth();
        for (int i = 0; i <= depth; i++) {
            convertOneRow(i);
        }
    }

    private void convertOneRow(int depth) {
        int[] row = getUnsortedRow(depth);
        LayoutNode[] nodes = new LayoutNode[row.length];
        for (int i = 0; i < nodes.length; i++) {
            nodes[i] = _nodes[row[i]];
        }
        Arrays.sort(nodes);
        for (int i = 0; i < nodes.length; i++) {
            nodes[i].setLocation(i);
        }
    }

    private int countDummyNodesNeeded() {
        int result = 0;
        int numNodes = getNumRealNodes();
        for (int i = 1; i <= numNodes; i++) {
            for (int j = 1; j <= numNodes; j++) {
                if (_nodes[i].hasEdgeTo(j)) {
                    int diff = _nodes[i].getDepth() - _nodes[j].getDepth();
                    if (diff > 1) {
                        result += (diff - 1);
                    } else if (diff < -1) {
                        result -= (diff + 1);
                    }
                }
            }
        }
        return result;
    }

    private int countUnreachableNodes() {
        int result = 0;
        for (int i = 1; i <= getNumRealNodes(); i++) {
            if (_nodes[i].getDepth() == LayoutNode.UNASSIGNED_DEPTH) {
                result++;
            }
        }
        return result;
    }

    public void doLayout(int numLoops) throws UnreachableNodesExistException {
        assignDepth();
        if (unreachableNodesExist()) {
            throw new UnreachableNodesExistException(getUnreachableNodes());
        }
        addDummyNodes();
        assignLocation();
        baryCenter(numLoops);
        priorityLayout();
    }

    public int getDepth() {
        int result = 0;
        for (int i = 1; i <= getNumRealNodes(); i++) {
            if (_nodes[i].getDepth() > result) {
                result = _nodes[i].getDepth();
            }
        }
        return result;
    }

    public int getDepthOf(int x) {
        return _nodes[x].getDepth();
    }

    public double getLocationOf(int x) {
        return _nodes[x].getLocation();
    }

    public double getMaxWidth() {
        double result = 0.0;
        for (int i = 1; i <= getNumRealNodes(); i++) {
            if (_nodes[i].getLocation() > result) {
                result = _nodes[i].getLocation();
            }
        }
        return result - getMinX();
    }

    private double getMinX() {
        int numNodes = getNumRealNodes();
        double result = Double.MAX_VALUE;
        for (int i = 1; i <= numNodes; i++) {
            if (_nodes[i].getLocation() < result) {
                result = _nodes[i].getLocation();
            }
        }
        return result;
    }

    public int getNumAllNodes() {
        return (_realNodeCount + _dummyNodeCount);
    }

    public int getNumDummyNodes() {
        return _dummyNodeCount;
    }

    public int getNumRealNodes() {
        return _realNodeCount;
    }

    public Point[] getPositions(int xScale, int yScale) {
        int numNodes = getNumRealNodes();
        double minX = getMinX();
        Point[] result = new Point[numNodes];
        for (int i = 1; i <= numNodes; i++) {
            result[i - 1] = new Point((int) (xScale * (_nodes[i].getLocation() - minX)), yScale * (_nodes[i].getDepth() - 1));
        }
        return result;
    }

    public int[] getRow(int depth) {
        int numElems = getSizeOfRow(depth);
        int[] result = new int[numElems];
        for (int i = 0; i < getNumAllNodes(); i++) {
            if (_nodes[i].getDepth() == depth) {
                result[(int) (_nodes[i].getLocation())] = i;
            }
        }
        return result;
    }

    public int getSizeOfRow(int depth) {
        int result = 0;
        for (int i = 0; i < getNumAllNodes(); i++) {
            if (_nodes[i].getDepth() == depth) {
                result++;
            }
        }
        return result;
    }

    private int[] getUnreachableNodes() {
        int numUnreachable = countUnreachableNodes();
        int[] result = new int[numUnreachable];
        int next = 0;
        for (int i = 1; i <= getNumRealNodes(); i++) {
            if (_nodes[i].getDepth() == LayoutNode.UNASSIGNED_DEPTH) {
                result[next++] = i;
            }
        }
        return result;
    }

    public int[] getUnsortedRow(int depth) {
        int numElems = getSizeOfRow(depth);
        int[] result = new int[numElems];
        int next = 0;
        for (int i = 0; i < getNumAllNodes(); i++) {
            if (_nodes[i].getDepth() == depth) {
                result[next++] = i;
            }
        }
        return result;
    }

    public boolean hasEdgeBetween(int x, int y) {
        return ((_nodes[x].hasEdgeTo(y)) || (_nodes[y].hasEdgeTo(x)));
    }

    public boolean isDummyNode(int x) {
        return _nodes[x].isDummyNode();
    }

    private boolean isRootNode(int index) {
        return _nodes[0].hasEdgeTo(index);
    }

    public static void main(String[] args) {
        FlowchartGraph graph = new FlowchartGraph(12);
        graph.addRoot(1);
        //    graph.addRoot(7); //Multi-root
        graph.addEdge(1, 2);
        graph.addEdge(2, 3);
        graph.addEdge(2, 4);
        graph.addEdge(4, 5);
        graph.addEdge(5, 6);
        graph.addEdge(5, 7);
        //Single-root
        //    graph.addEdge(5, 10); //Multi-root
        graph.addEdge(6, 1);
        graph.addEdge(7, 8);
        graph.addEdge(7, 9);
        graph.addEdge(9, 8);
        graph.addEdge(9, 10);
        graph.addEdge(10, 11);
        graph.addEdge(10, 12);
        try {
            graph.doLayout(2);
        } catch (UnreachableNodesExistException unee) {
            System.err.println(unee.toString());
        }
        graph.printAllNodes();
        try {
            graph.doLayout(1);
        } catch (UnreachableNodesExistException unee) {
            System.err.println(unee.toString());
        }
        graph.reLayout(1);
        graph.printAllNodes();
        try {
            System.in.read();
        } catch (java.io.IOException ioe) {
        }
    }

    private boolean newLayerAdded(int layer, AcyclicPath path, LayoutNode node, int nodeID) {
        // Do not traverse paths through root nodes.
        if (isRootNode(nodeID) && (layer > 1)) {
            return false;
        }
        // This node has already been expanded => Do not continue.
        if (node.getDepth() >= layer) {
            return false;
        }
        // Try to add an edge.
        return path.addEdgeTo(nodeID);
    }

    private void populateDummyNodes() {
        int numNodes = getNumRealNodes();
        int nextDummyNode = numNodes + 1;
        for (int i = 1; i <= numNodes; i++) {
            for (int j = 1; j <= numNodes; j++) {
                if (_nodes[i].hasEdgeTo(j)) {
                    int diff = _nodes[i].getDepth() - _nodes[j].getDepth();
                    if (diff < -1) {
                        nextDummyNode += addDummyNodes(i, j, nextDummyNode);
                    } else if (diff > 1) {
                        nextDummyNode += addDummyNodes(j, i, nextDummyNode);
                    }
                }
            }
        }
    }

    public void printAllNodes() {
        printRange(0, getNumAllNodes() - 1);
    }

    public void printRange(int from, int to) {
        for (int i = from; i <= to; i++) {
            System.out.print(i + _nodes[i].toString() + "\n");
        }
    }

    public void printRealNodes() {
        printRange(1, getNumRealNodes());
    }

    private void priorityLayout() {
        int depth = getDepth();
        for (int i = 1; i <= depth; i++) {
            int[] row = getRow(i);
            PRElem[] prRow = new PRElem[row.length];
            for (int j = 0; j < row.length; j++) {
                prRow[j] = new PRElem(row[j], this);
            }
            java.util.Arrays.sort(prRow);
            assignAbs : for (int j = 0; j < row.length; j++) {
                for (int k = 0; k < j; k++) {
                    double absDiff = prRow[k].getPreferredPosition() - prRow[j].getPreferredPosition();
                    double relK = _nodes[prRow[k].getNode()].getLocation();
                    double relJ = _nodes[prRow[j].getNode()].getLocation();
                    double relDiff = relK - relJ;
                    if ((relDiff > 0 && absDiff < relDiff) || (relDiff < 0 && absDiff > relDiff)) {
                        prRow[j].setPosition(prRow[k].getPreferredPosition() - relDiff);
                        continue assignAbs;
                    }
                }
            }
            for (int j = 0; j < row.length; j++) {
                _nodes[prRow[j].getNode()].setLocation(prRow[j].getPreferredPosition());
            }
        }
    }

    private void reallocateNodes() {
        LayoutNode[] oldNodes = _nodes;
        int numNodes = getNumAllNodes();
        _nodes = new LayoutNode[numNodes];
        for (int i = 0; i < numNodes; i++) {
            _nodes[i] = (i < oldNodes.length) ? new LayoutNode(numNodes, oldNodes[i]) : new LayoutNode(numNodes, true);
        }
    }

    public void reLayout(int numLoops) {
        convertAllLocationsToIntegers();
        baryCenter(numLoops);
        priorityLayout();
    }

    private boolean unreachableNodesExist() {
        return (countUnreachableNodes() > 0);
    }
}
