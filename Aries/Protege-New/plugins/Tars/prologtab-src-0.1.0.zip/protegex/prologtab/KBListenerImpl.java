package protegex.prologtab;

import edu.stanford.smi.protege.event.*;
import edu.stanford.smi.protege.model.*;
import java.util.*;
/**
 * Implementation of KBListener interface.
 * Creation date: (3/20/2002 4:13:52 PM)
 * @author: 
 */
public class KBListenerImpl extends KBListenerAdapter implements KBListener {
	protected Set _frames = new HashSet();
	protected Set _clses = new HashSet();

/**
 * KBListener constructor comment.
 */
public KBListenerImpl(TripleDBAdapter prologEngineAdapter) {
	super(prologEngineAdapter);
}
/**
 * browserTextChanged method comment.
 */
public void browserTextChanged(edu.stanford.smi.protege.event.FrameEvent event) {}
/**
 * clsCreated method comment.
 */
public void clsCreated(edu.stanford.smi.protege.event.KnowledgeBaseEvent event) {
	Cls cls = event.getCls();
	cls.addClsListener(this);
	_clses.add(cls);
	clsCreated(cls);
}
/**
 * clsDeleted method comment.
 */
public void clsDeleted(edu.stanford.smi.protege.event.KnowledgeBaseEvent event) {
	Cls cls = event.getCls();
	_clses.remove(cls);
	clsDeleted(cls);
}
/**
 * defaultClsMetaClsChanged method comment.
 */
public void defaultClsMetaClsChanged(edu.stanford.smi.protege.event.KnowledgeBaseEvent event) {}
/**
 * defaultFacetMetaClsChanged method comment.
 */
public void defaultFacetMetaClsChanged(edu.stanford.smi.protege.event.KnowledgeBaseEvent event) {}
/**
 * defaultSlotMetaClsChanged method comment.
 */
public void defaultSlotMetaClsChanged(edu.stanford.smi.protege.event.KnowledgeBaseEvent event) {}
/**
 * deleted method comment.
 */
public void deleted(edu.stanford.smi.protege.event.FrameEvent event) {}
/**
 * directInstanceCreated method comment.
 */
public void directInstanceCreated(edu.stanford.smi.protege.event.ClsEvent event) {
	Cls cls = event.getCls();
	Instance instance = event.getInstance();
	directInstanceCreated(cls,instance);
}
/**
 * directInstanceDeleted method comment.
 */
public void directInstanceDeleted(edu.stanford.smi.protege.event.ClsEvent event) {
	Cls cls = event.getCls();
	Instance instance = event.getInstance();
	directInstanceDeleted(cls,instance);
}
/**
 * directSubclassAdded method comment.
 */
public void directSubclassAdded(edu.stanford.smi.protege.event.ClsEvent event) {
	Cls cls = event.getCls();
	directSubclassUpdated(cls);
}
/**
 * directSubclassMoved method comment.
 */
public void directSubclassMoved(edu.stanford.smi.protege.event.ClsEvent event) {
	Cls cls = event.getCls();
	directSubclassUpdated(cls);
}
/**
 * directSubclassRemoved method comment.
 */
public void directSubclassRemoved(edu.stanford.smi.protege.event.ClsEvent event) {
	Cls cls = event.getCls();
	directSubclassUpdated(cls);
}
/**
 * directSuperclassAdded method comment.
 */
public void directSuperclassAdded(edu.stanford.smi.protege.event.ClsEvent event) {
	Cls cls = event.getCls();
	directSuperclassUpdated(cls);
}
/**
 * directSuperclassRemoved method comment.
 */
public void directSuperclassRemoved(edu.stanford.smi.protege.event.ClsEvent event) {
	Cls cls = event.getCls();
	directSuperclassUpdated(cls);
}
/**
 * facetCreated method comment.
 */
public void facetCreated(edu.stanford.smi.protege.event.KnowledgeBaseEvent event) {}
/**
 * facetDeleted method comment.
 */
public void facetDeleted(edu.stanford.smi.protege.event.KnowledgeBaseEvent event) {}
/**
 * frameNameChanged method comment.
 */
public void frameNameChanged(edu.stanford.smi.protege.event.KnowledgeBaseEvent event) {
	Frame frame = event.getFrame();
	frameNameChanged(frame,event.getOldName());
}
/**
 * instanceCreated method comment.
 */
public void instanceCreated(edu.stanford.smi.protege.event.KnowledgeBaseEvent event) {
	Frame frame = event.getFrame();
	frame.addFrameListener(this);
	_frames.add(frame);
	instanceCreated(frame);
}
/**
 * instanceDeleted method comment.
 */
public void instanceDeleted(edu.stanford.smi.protege.event.KnowledgeBaseEvent event) {
	Frame frame = event.getFrame();
	_frames.remove(frame);
	instanceDeleted(frame,event.getOldName());
}
/**
 * nameChanged method comment.
 */
public void nameChanged(edu.stanford.smi.protege.event.FrameEvent event) {}
/**
 * ownFacetAdded method comment.
 */
public void ownFacetAdded(edu.stanford.smi.protege.event.FrameEvent event) {}
/**
 * ownFacetRemoved method comment.
 */
public void ownFacetRemoved(edu.stanford.smi.protege.event.FrameEvent event) {}
/**
 * ownFacetValueChanged method comment.
 */
public void ownFacetValueChanged(edu.stanford.smi.protege.event.FrameEvent event) {}
/**
 * ownSlotAdded method comment.
 */
public void ownSlotAdded(edu.stanford.smi.protege.event.FrameEvent event) {}
/**
 * ownSlotRemoved method comment.
 */
public void ownSlotRemoved(edu.stanford.smi.protege.event.FrameEvent event) {}
/**
 * ownSlotValueChanged method comment.
 */
public void ownSlotValueChanged(edu.stanford.smi.protege.event.FrameEvent event) {
	Frame frame = event.getFrame();
	Slot slot = event.getSlot();
	ownSlotValueChanged(frame,slot);
}
/**
 * slotCreated method comment.
 */
public void slotCreated(edu.stanford.smi.protege.event.KnowledgeBaseEvent event) {
	Slot slot = event.getSlot();
	slotCreated(slot);
}
/**
 * slotDeleted method comment.
 */
public void slotDeleted(edu.stanford.smi.protege.event.KnowledgeBaseEvent event) {
	Slot slot = event.getSlot();
	slotDeleted(slot);
}
/**
 * templateFacetAdded method comment.
 */
public void templateFacetAdded(edu.stanford.smi.protege.event.ClsEvent event) {}
/**
 * templateFacetRemoved method comment.
 */
public void templateFacetRemoved(edu.stanford.smi.protege.event.ClsEvent event) {}
/**
 * templateFacetValueChanged method comment.
 */
public void templateFacetValueChanged(edu.stanford.smi.protege.event.ClsEvent event) {}
/**
 * templateSlotAdded method comment.
 */
public void templateSlotAdded(edu.stanford.smi.protege.event.ClsEvent event) {}
/**
 * templateSlotRemoved method comment.
 */
public void templateSlotRemoved(edu.stanford.smi.protege.event.ClsEvent event) {}
/**
 * templateSlotValueChanged method comment.
 */
public void templateSlotValueChanged(edu.stanford.smi.protege.event.ClsEvent event) {}
/**
 * visibilityChanged method comment.
 */
public void visibilityChanged(edu.stanford.smi.protege.event.FrameEvent event) {}
}
