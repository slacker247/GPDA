/*
 * The contents of this file are subject to the Mozilla Public License
 * Version 1.1 (the "License");  you may not use this file except in compliance
 * with the License.  You may obtain a copy of the License at
 * http://www.mozilla.org/MPL/
 *
 * Software distributed under the License is distributed on an "AS IS" basis,
 * WITHOUT WARRANTY OF ANY KIND, either express or implied. See the License for
 * the specific language governing rights and limitations under the License.
 *
 * The Original Code is Protege-2000.
 *
 * The Initial Developer of the Original Code is Stanford University. Portions
 * created by Stanford University are Copyright (C) 2001.  All Rights Reserved.
 *
 * Protege-2000 was developed by Stanford Medical Informatics
 * (http://www.smi.stanford.edu) at the Stanford University School of Medicine
 * with support from the National Library of Medicine, the National Science
 * Foundation, and the Defense Advanced Research Projects Agency.  Current
 * information about Protege can be obtained at http://protege.stanford.edu
 *
 * Contributor(s):
 */

package edu.stanford.smi.protegex.widget.scatterbox;

import javax.swing.*;
import java.awt.*;
import java.awt.geom.*;

/**
 *  Description of the class
 *
 * @author    William Grosso <grosso@smi.stanford.edu>
 */
public class VerticalTextPanel extends AbstractTextPanel {
    private AffineTransform _rotation;
    private AffineTransform _rotationBack;
    private AffineTransform _translation;
    private AffineTransform _translationBack;

    private final static double PI_OVER_2 = Math.PI / 2;

    public VerticalTextPanel(String text) {
        super(text);
        _rotation = new AffineTransform();
        _rotation.rotate(-1 * PI_OVER_2);
        _rotationBack = new AffineTransform();
        _rotationBack.rotate(PI_OVER_2);
        _translation = new AffineTransform();
        _translationBack = new AffineTransform();
        setSize(100, 100);
    }

    private void drawRotatedString(Graphics2D g) {
        FontMetrics fontMetrics = g.getFontMetrics();
        int stringWidth = fontMetrics.stringWidth(_text);
        int stringHeight = fontMetrics.getDescent();
        g.transform(_rotation);
        g.drawString(_text, -stringWidth / 2, stringHeight);
        g.transform(_rotationBack);
    }

    protected void reallyPaint(Graphics2D g) {
        getBounds(_bounds);
        int halfWidth = _bounds.width / 2;
        int halfHeight = _bounds.height / 2;
        int negativeHalfWidth = -1 * halfWidth;
        int negativeHalfHeight = -1 * halfHeight;

        _translation.translate(halfWidth, halfHeight);
        _translationBack.translate(negativeHalfWidth, negativeHalfHeight);

        g.transform(_translation);
        drawRotatedString(g);
        g.transform(_translationBack);

        _translationBack.translate(halfWidth, halfHeight);
        _translation.translate(negativeHalfWidth, negativeHalfHeight);
    }
}
