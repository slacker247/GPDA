package protegex.prologtab;

import edu.stanford.smi.protege.model.*;
import java.util.*;
/**
 * TripleDBAdapter implementation.
 * Creation date: (4/2/2002 9:56:50 AM)
 * @author: 
 */
public class TripleDBAdapterImpl implements TripleDBAdapter {
	protected TripleDB _tripleDB;
    protected KBListener _kbListener;
    protected KnowledgeBase _kb;
/**
 * TripleDBAdapterImpl constructor comment.
 */
public TripleDBAdapterImpl(KnowledgeBase kb, TripleDB tripleDB) {
	super();
	_kb = kb;
	_tripleDB = tripleDB;
	_kbListener = new KBListenerImpl(this);
	_kb.addKnowledgeBaseListener(_kbListener);
}
/**
 * 
 * @param frame edu.stanford.smi.protege.model.Frame
 * @param slot edu.stanford.smi.protege.model.Slot
 * @param value java.lang.Object
 */
public void addSlotValue(Frame frame, String slotName, Object value) {
	_tripleDB.assertSlotValueClause(frame,slotName,value);
}
/**
 * 
 * @param frame edu.stanford.smi.protege.model.Frame
 * @param slot edu.stanford.smi.protege.model.Slot
 * @param value java.lang.Object
 */
public void addSlotValues(Frame frame, String slotName, Collection values) {
	_tripleDB.assertSlotValueClause(frame,slotName,values);
}
/**
 * Copy knowledgeBase slot values to tripleDB.
 * @param kb edu.stanford.smi.protege.model.KnowledgeBase
 */
public void copyKnowledgeBase() {
	Iterator instancesIterator = _kb.getInstances().iterator();
	while (instancesIterator.hasNext()) {
		Instance instance = (Instance) instancesIterator.next();
		Cls directType = instance.getDirectType();
		updateSlotValue(instance,NAME_SLOT_NAME,instance.getName());
		updateSlotValue(instance,DIRECT_TYPE_SLOT_NAME,directType);
		Iterator slotIterator = directType.getTemplateSlots().iterator();
		while (slotIterator.hasNext()) {
			Slot slot = (Slot) slotIterator.next();
			if (instance.getOwnSlotAllowsMultipleValues(slot))
				updateSlotValues(instance,slot.getName(),instance.getOwnSlotValues(slot));
			else
				updateSlotValue(instance,slot.getName(),instance.getOwnSlotValue(slot));
		}
	}
}
/**
 * 
 */
public void release() {
	if ((_kb != null) && (_kbListener != null))
		_kb.removeKnowledgeBaseListener(_kbListener);
}
/**
 * Insert the method's description here.
 * Creation date: (4/9/2002 10:18:23 AM)
 * @param slotName java.lang.String
 */
public void removeSlot(java.lang.String slotName) {
	_tripleDB.retractSlotPredicate(slotName);
}
/**
 * 
 * @param frame edu.stanford.smi.protege.model.Frame
 * @param slot edu.stanford.smi.protege.model.Slot
 * @param value java.lang.Object
 */
public void removeSlotValue(Frame frame, String slotName) {
	_tripleDB.retractSlotValueClause(frame,slotName);
}
/**
 * 
 * @param frame edu.stanford.smi.protege.model.Frame
 * @param slot edu.stanford.smi.protege.model.Slot
 * @param value java.lang.Object
 */
public void removeSlotValues(Frame frame, String slotName) {
	_tripleDB.retractSlotValueClause(frame,slotName);
}
/**
 * Insert the method's description here.
 * Creation date: (4/10/2002 10:50:49 AM)
 * @param slotName java.lang.String
 */
public void renameSlot(java.lang.String oldSlotName, java.lang.String newSlotName) {
	_tripleDB.renameSlotPredicate(oldSlotName,newSlotName);
}
/**
 * 
 * @param frame edu.stanford.smi.protege.model.Frame
 * @param slot edu.stanford.smi.protege.model.Slot
 * @param value java.lang.Object
 */
public void updateSlotValue(Frame frame, String slotName, Object value) {
	_tripleDB.retractSlotValueClause(frame,slotName);
	_tripleDB.assertSlotValueClause(frame,slotName,value);
}
/**
 * 
 * @param frame edu.stanford.smi.protege.model.Frame
 * @param slot edu.stanford.smi.protege.model.Slot
 * @param value java.lang.Object
 */
public void updateSlotValues(Frame frame, String slotName, Collection values) {
	_tripleDB.retractSlotValueClause(frame,slotName);
	_tripleDB.assertSlotValueClause(frame,slotName,values);
}
}
