/*
 * The contents of this file are subject to the Mozilla Public License
 * Version 1.1 (the "License");  you may not use this file except in compliance
 * with the License.  You may obtain a copy of the License at
 * http://www.mozilla.org/MPL/
 *
 * Software distributed under the License is distributed on an "AS IS" basis,
 * WITHOUT WARRANTY OF ANY KIND, either express or implied. See the License for
 * the specific language governing rights and limitations under the License.
 *
 * The Original Code is Protege-2000.
 *
 * The Initial Developer of the Original Code is Stanford University. Portions
 * created by Stanford University are Copyright (C) 2001.  All Rights Reserved.
 *
 * Protege-2000 was developed by Stanford Medical Informatics
 * (http://www.smi.stanford.edu) at the Stanford University School of Medicine
 * with support from the National Library of Medicine, the National Science
 * Foundation, and the Defense Advanced Research Projects Agency.  Current
 * information about Protege can be obtained at http://protege.stanford.edu
 *
 * Contributor(s):
 */

package edu.stanford.smi.protegex.widget.diagram;

import edu.stanford.smi.protegex.layout.*;
import edu.stanford.smi.protege.resource.*;
import edu.stanford.smi.protege.ui.*;
import edu.stanford.smi.protege.model.*;

import java.awt.*;
import java.awt.event.*;
import javax.swing.*;
import java.util.*;

/**
 *  Description of the class
 *
 * @author    William Grosso <grosso@smi.stanford.edu>
 */
public abstract class Diagrams_AddNode extends Diagrams_Action implements Constants {
    protected DiagramsPanel _panel;

    public Diagrams_AddNode(
        DiagramsPanel panel,
        DiagramWidget widget,
        AnimationContext mainDrawingArea,
        String toolTip,
        Icon icon) {
        super(widget, mainDrawingArea, toolTip, icon);
        _panel = panel;
    }

    public abstract void actionPerformed(ActionEvent event);

    protected void addConnector(Instance instance) {
        Collection currentConnectors = _widget.getConnectors();
        if (currentConnectors.contains(instance)) {
            return;
        }
        WireState wireState = _widget.getState().getStateForConnector(instance);
        StandardWireActor associatedActor = _panel.buildActorForConnector(instance, wireState);
        _panel.computeAttachmentsForConnector(instance, associatedActor);
        DiagramUtilities.addNewConnectorToNetwork(_widget.getNetworkInstance(), associatedActor);
        return;
    }

    protected void addInstance(Instance instance) {
        Cls connectorClass = (instance.getKnowledgeBase()).getCls(CONNECTOR_CLASS);
        if (instance.hasType(connectorClass)) {
            addConnector(instance);
        } else {
            addNode(instance);
        }
    }

    protected void addInstances(Collection newSelections) {
        Iterator iterator = newSelections.iterator();
        while (iterator.hasNext()) {
            Instance instance = (Instance) iterator.next();
            addInstance(instance);
        }
    }

    protected void addNode(Instance instance) {
        Collection currentNodes = _widget.getNodes();
        if (currentNodes.contains(instance)) {
            return;
        }
        NodeState nodeState = _widget.getState().getStateForNode(instance);
        Actor associatedActor = _panel.buildActorForNode(instance, nodeState);
        _panel.placeNodeOnScreen(instance, associatedActor);
        DiagramUtilities.addNewNodeToNetwork(_widget.getNetworkInstance(), associatedActor);
        return;
    }
}
